/**
 * Installation Component Tests
 *
 * Tests individual installation components in isolation:
 * - Agent YAML → XML compilation
 * - Manifest generation
 * - Path resolution
 * - Customization merging
 *
 * These are deterministic unit tests that don't require full installation.
 * Usage: node test/test-installation-components.js
 */

const path = require('node:path');
const os = require('node:os');
const { spawnSync } = require('node:child_process');
const fs = require('../tools/installer/fs-native');
const { Installer } = require('../tools/installer/core/installer');
const { ManifestGenerator } = require('../tools/installer/core/manifest-generator');
const { OfficialModules } = require('../tools/installer/modules/official-modules');
const { IdeManager } = require('../tools/installer/ide/manager');
const { clearCache, loadPlatformCodes } = require('../tools/installer/ide/platform-codes');

// ANSI colors
const colors = {
  reset: '\u001B[0m',
  green: '\u001B[32m',
  red: '\u001B[31m',
  yellow: '\u001B[33m',
  cyan: '\u001B[36m',
  dim: '\u001B[2m',
};

let passed = 0;
let failed = 0;

/**
 * Test helper: Assert condition
 */
function assert(condition, testName, errorMessage = '') {
  if (condition) {
    console.log(`${colors.green}✓${colors.reset} ${testName}`);
    passed++;
  } else {
    console.log(`${colors.red}✗${colors.reset} ${testName}`);
    if (errorMessage) {
      console.log(`  ${colors.dim}${errorMessage}${colors.reset}`);
    }
    failed++;
  }
}

async function createTestBmadFixture() {
  const fixtureRoot = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-fixture-'));
  const fixtureDir = path.join(fixtureRoot, '_bmad');
  await fs.ensureDir(fixtureDir);

  // Skill manifest CSV — the sole source of truth for IDE skill installation
  await fs.ensureDir(path.join(fixtureDir, '_config'));
  await fs.writeFile(
    path.join(fixtureDir, '_config', 'skill-manifest.csv'),
    [
      'canonicalId,name,description,module,path',
      '"bmad-master","bmad-master","Minimal test agent fixture","core","_bmad/core/bmad-master/SKILL.md"',
      '',
    ].join('\n'),
  );

  // Minimal SKILL.md for the skill entry
  const skillDir = path.join(fixtureDir, 'core', 'bmad-master');
  await fs.ensureDir(skillDir);
  await fs.writeFile(
    path.join(skillDir, 'SKILL.md'),
    [
      '---',
      'name: bmad-master',
      'description: Minimal test agent fixture',
      '---',
      '',
      '<!-- agent-activation -->',
      'You are a test agent.',
    ].join('\n'),
  );
  await fs.writeFile(path.join(skillDir, 'workflow.md'), '# Test Workflow\nStep 1: Do the thing.\n');

  return fixtureDir;
}

async function createSkillCollisionFixture() {
  const fixtureRoot = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-skill-collision-'));
  const fixtureDir = path.join(fixtureRoot, '_bmad');
  const configDir = path.join(fixtureDir, '_config');
  await fs.ensureDir(configDir);

  await fs.writeFile(
    path.join(configDir, 'skill-manifest.csv'),
    [
      'canonicalId,name,description,module,path',
      '"bmad-help","bmad-help","Native help skill","core","_bmad/core/tasks/bmad-help/SKILL.md"',
      '',
    ].join('\n'),
  );

  const skillDir = path.join(fixtureDir, 'core', 'tasks', 'bmad-help');
  await fs.ensureDir(skillDir);
  await fs.writeFile(
    path.join(skillDir, 'SKILL.md'),
    ['---', 'name: bmad-help', 'description: Native help skill', '---', '', 'Use this skill directly.'].join('\n'),
  );

  const agentDir = path.join(fixtureDir, 'core', 'agents');
  await fs.ensureDir(agentDir);
  await fs.writeFile(
    path.join(agentDir, 'bmad-master.md'),
    ['---', 'name: BMAD Master', 'description: Master agent', '---', '', '<agent name="BMAD Master" title="Master">', '</agent>'].join(
      '\n',
    ),
  );

  return { root: fixtureRoot, bmadDir: fixtureDir };
}

/**
 * Test Suite
 */
async function runTests() {
  console.log(`${colors.cyan}========================================`);
  console.log('Installation Component Tests');
  console.log(`========================================${colors.reset}\n`);

  const projectRoot = path.join(__dirname, '..');

  // ============================================================
  // Test 1: Windsurf Native Skills Install
  // ============================================================
  console.log(`${colors.yellow}Test Suite 1: Windsurf Native Skills${colors.reset}\n`);

  try {
    clearCache();
    const platformCodes = await loadPlatformCodes();
    const windsurfInstaller = platformCodes.platforms.windsurf?.installer;

    assert(windsurfInstaller?.target_dir === '.agents/skills', 'Windsurf target_dir uses native skills path');

    const tempProjectDir = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-windsurf-test-'));
    const installedBmadDir = await createTestBmadFixture();

    const ideManager = new IdeManager();
    await ideManager.ensureInitialized();
    const result = await ideManager.setup('windsurf', tempProjectDir, installedBmadDir, {
      silent: true,
      selectedModules: ['bmm'],
    });

    assert(result.success === true, 'Windsurf setup succeeds against temp project');

    const skillFile = path.join(tempProjectDir, '.agents', 'skills', 'bmad-master', 'SKILL.md');
    assert(await fs.pathExists(skillFile), 'Windsurf install writes SKILL.md directory output');

    await fs.remove(tempProjectDir);
    await fs.remove(path.dirname(installedBmadDir));
  } catch (error) {
    assert(false, 'Windsurf native skills migration test succeeds', error.message);
  }

  console.log('');

  // ============================================================
  // Test 5: Kiro Native Skills Install
  // ============================================================
  console.log(`${colors.yellow}Test Suite 5: Kiro Native Skills${colors.reset}\n`);

  try {
    clearCache();
    const platformCodes = await loadPlatformCodes();
    const kiroInstaller = platformCodes.platforms.kiro?.installer;

    assert(kiroInstaller?.target_dir === '.kiro/skills', 'Kiro target_dir uses native skills path');

    const tempProjectDir = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-kiro-test-'));
    const installedBmadDir = await createTestBmadFixture();

    const ideManager = new IdeManager();
    await ideManager.ensureInitialized();
    const result = await ideManager.setup('kiro', tempProjectDir, installedBmadDir, {
      silent: true,
      selectedModules: ['bmm'],
    });

    assert(result.success === true, 'Kiro setup succeeds against temp project');

    const skillFile = path.join(tempProjectDir, '.kiro', 'skills', 'bmad-master', 'SKILL.md');
    assert(await fs.pathExists(skillFile), 'Kiro install writes SKILL.md directory output');

    await fs.remove(tempProjectDir);
    await fs.remove(path.dirname(installedBmadDir));
  } catch (error) {
    assert(false, 'Kiro native skills migration test succeeds', error.message);
  }

  console.log('');

  // ============================================================
  // Test 6: Antigravity Native Skills Install
  // ============================================================
  console.log(`${colors.yellow}Test Suite 6: Antigravity Native Skills${colors.reset}\n`);

  try {
    clearCache();
    const platformCodes = await loadPlatformCodes();
    const antigravityInstaller = platformCodes.platforms.antigravity?.installer;

    assert(antigravityInstaller?.target_dir === '.agent/skills', 'Antigravity target_dir uses native skills path');

    const tempProjectDir = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-antigravity-test-'));
    const installedBmadDir = await createTestBmadFixture();

    const ideManager = new IdeManager();
    await ideManager.ensureInitialized();
    const result = await ideManager.setup('antigravity', tempProjectDir, installedBmadDir, {
      silent: true,
      selectedModules: ['bmm'],
    });

    assert(result.success === true, 'Antigravity setup succeeds against temp project');

    const skillFile = path.join(tempProjectDir, '.agent', 'skills', 'bmad-master', 'SKILL.md');
    assert(await fs.pathExists(skillFile), 'Antigravity install writes SKILL.md directory output');

    await fs.remove(tempProjectDir);
    await fs.remove(path.dirname(installedBmadDir));
  } catch (error) {
    assert(false, 'Antigravity native skills migration test succeeds', error.message);
  }

  console.log('');

  // ============================================================
  // Test 6b: Antigravity CLI Native Skills Install
  // ============================================================
  console.log(`${colors.yellow}Test Suite 6b: Antigravity CLI Native Skills${colors.reset}\n`);

  try {
    clearCache();
    const platformCodes6b = await loadPlatformCodes();
    const antigravityCliInstaller = platformCodes6b.platforms['antigravity-cli']?.installer;

    assert(antigravityCliInstaller?.target_dir === '.agents/skills', 'Antigravity CLI target_dir uses shared skills path');
    assert(
      antigravityCliInstaller?.global_target_dir === '~/.gemini/antigravity-cli/skills',
      'Antigravity CLI global_target_dir uses the CLI-specific skills path',
    );
    assert(
      antigravityCliInstaller?.global_target_dir !== platformCodes6b.platforms.antigravity?.installer?.global_target_dir,
      'Antigravity CLI global_target_dir differs from the Antigravity IDE so installs never collide',
    );

    const tempProjectDir6b = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-antigravity-cli-test-'));
    const installedBmadDir6b = await createTestBmadFixture();

    const ideManager6b = new IdeManager();
    await ideManager6b.ensureInitialized();
    const result6b = await ideManager6b.setup('antigravity-cli', tempProjectDir6b, installedBmadDir6b, {
      silent: true,
      selectedModules: ['bmm'],
    });

    assert(result6b.success === true, 'Antigravity CLI setup succeeds against temp project');

    const skillFile6b = path.join(tempProjectDir6b, '.agents', 'skills', 'bmad-master', 'SKILL.md');
    assert(await fs.pathExists(skillFile6b), 'Antigravity CLI install writes SKILL.md directory output');

    await fs.remove(tempProjectDir6b);
    await fs.remove(path.dirname(installedBmadDir6b));
  } catch (error) {
    assert(false, 'Antigravity CLI native skills migration test succeeds', error.message);
  }

  console.log('');

  // ============================================================
  // Test 6c: ZCode Native Skills Install
  // ============================================================
  console.log(`${colors.yellow}Test Suite 6c: ZCode Native Skills${colors.reset}\n`);

  let tempProjectDir6c;
  let installedBmadDir6c;
  try {
    clearCache();
    const platformCodes6c = await loadPlatformCodes();
    const zcodeInstaller = platformCodes6c.platforms['zcode']?.installer;

    assert(zcodeInstaller?.target_dir === '.zcode/skills', 'ZCode target_dir uses its own skills path');
    assert(zcodeInstaller?.global_target_dir === '~/.zcode/skills', 'ZCode global_target_dir uses its own global skills path');
    // ZCode keeps a private skills tree (not the shared .agents/skills standard),
    // so it must never collide with the cross-tool shared path.
    assert(zcodeInstaller?.target_dir !== '.agents/skills', 'ZCode target_dir is distinct from the shared .agents/skills standard');

    tempProjectDir6c = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-zcode-test-'));
    installedBmadDir6c = await createTestBmadFixture();

    const ideManager6c = new IdeManager();
    await ideManager6c.ensureInitialized();
    const result6c = await ideManager6c.setup('zcode', tempProjectDir6c, installedBmadDir6c, {
      silent: true,
      selectedModules: ['bmm'],
    });

    assert(result6c.success === true, 'ZCode setup succeeds against temp project');

    const skillFile6c = path.join(tempProjectDir6c, '.zcode', 'skills', 'bmad-master', 'SKILL.md');
    assert(await fs.pathExists(skillFile6c), 'ZCode install writes SKILL.md directory output');
  } catch (error) {
    assert(false, 'ZCode native skills install test succeeds', error.message);
  } finally {
    if (tempProjectDir6c) await fs.remove(tempProjectDir6c).catch(() => {});
    if (installedBmadDir6c) await fs.remove(path.dirname(installedBmadDir6c)).catch(() => {});
  }

  console.log('');

  // ============================================================
  // Test 7: Auggie Native Skills Install
  // ============================================================
  console.log(`${colors.yellow}Test Suite 7: Auggie Native Skills${colors.reset}\n`);

  try {
    clearCache();
    const platformCodes = await loadPlatformCodes();
    const auggieInstaller = platformCodes.platforms.auggie?.installer;

    assert(auggieInstaller?.target_dir === '.agents/skills', 'Auggie target_dir uses native skills path');

    assert(
      auggieInstaller?.ancestor_conflict_check !== true,
      'Auggie installer does not enable ancestor conflict checks without verified inheritance',
    );

    const tempProjectDir = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-auggie-test-'));
    const installedBmadDir = await createTestBmadFixture();

    const ideManager = new IdeManager();
    await ideManager.ensureInitialized();
    const result = await ideManager.setup('auggie', tempProjectDir, installedBmadDir, {
      silent: true,
      selectedModules: ['bmm'],
    });

    assert(result.success === true, 'Auggie setup succeeds against temp project');

    const skillFile = path.join(tempProjectDir, '.agents', 'skills', 'bmad-master', 'SKILL.md');
    assert(await fs.pathExists(skillFile), 'Auggie install writes SKILL.md directory output');

    await fs.remove(tempProjectDir);
    await fs.remove(path.dirname(installedBmadDir));
  } catch (error) {
    assert(false, 'Auggie native skills migration test succeeds', error.message);
  }

  console.log('');

  // ============================================================
  // Test 8: OpenCode Native Skills Install
  // ============================================================
  console.log(`${colors.yellow}Test Suite 8: OpenCode Native Skills${colors.reset}\n`);

  try {
    clearCache();
    const platformCodes = await loadPlatformCodes();
    const opencodeInstaller = platformCodes.platforms.opencode?.installer;

    assert(opencodeInstaller?.target_dir === '.agents/skills', 'OpenCode target_dir uses native skills path');
    assert(
      opencodeInstaller?.commands_target_dir === '.opencode/commands',
      'OpenCode commands_target_dir is configured for /<skill> slash commands',
    );

    const tempProjectDir = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-opencode-test-'));
    const installedBmadDir = await createTestBmadFixture();

    const ideManager = new IdeManager();
    await ideManager.ensureInitialized();
    const result = await ideManager.setup('opencode', tempProjectDir, installedBmadDir, {
      silent: true,
      selectedModules: ['bmm'],
    });

    assert(result.success === true, 'OpenCode setup succeeds against temp project');

    const skillFile = path.join(tempProjectDir, '.agents', 'skills', 'bmad-master', 'SKILL.md');
    assert(await fs.pathExists(skillFile), 'OpenCode install writes SKILL.md directory output');

    // Command pointer assertions: a /<canonicalId> slash command should exist
    // for each installed skill so users can invoke skills directly without
    // going through the /skills menu.
    const commandFile = path.join(tempProjectDir, '.opencode', 'commands', 'bmad-master.md');
    assert(await fs.pathExists(commandFile), 'OpenCode install writes per-skill command pointer file');

    const commandContent = await fs.readFile(commandFile, 'utf8');
    assert(commandContent.includes('@skills/bmad-master'), 'Command pointer body references the skill via @skills/<canonicalId>');
    assert(commandContent.includes('description:'), 'Command pointer carries a description in YAML frontmatter');

    // Idempotency: re-running install must not duplicate or rewrite pointers.
    const result2 = await ideManager.setup('opencode', tempProjectDir, installedBmadDir, {
      silent: true,
      selectedModules: ['bmm'],
    });
    assert(result2.success === true, 'Second OpenCode install succeeds (idempotent)');
    assert(await fs.pathExists(commandFile), 'Command pointer survives a second install pass');

    // Description-update propagation: when the manifest description changes
    // and the on-disk pointer still matches the generator pattern, refresh
    // the file so users see the updated description.
    const csvPath = path.join(installedBmadDir, '_config', 'skill-manifest.csv');
    const updatedCsv =
      'canonicalId,name,description,module,path\n' +
      '"bmad-master","bmad-master","UPDATED description for the test agent","core","_bmad/core/bmad-master/SKILL.md"\n';
    await fs.writeFile(csvPath, updatedCsv);
    const result3 = await ideManager.setup('opencode', tempProjectDir, installedBmadDir, {
      silent: true,
      selectedModules: ['bmm'],
    });
    assert(result3.success === true, 'Third OpenCode install succeeds after description update');
    const refreshed = await fs.readFile(commandFile, 'utf8');
    assert(refreshed.includes('UPDATED description'), 'Generator-shaped pointer is refreshed when manifest description changes');

    // Hand-edit preservation across the production install flow. The
    // installer passes previousSkillIds — without the cleanup-side spare,
    // hand edits would be wiped here.
    const SENTINEL = 'HAND_EDITED_BY_USER_SHOULD_SURVIVE';
    const handEditedBody = `---\ndescription: my custom description\n---\n\n${SENTINEL}\n`;
    await fs.writeFile(commandFile, handEditedBody);
    const result4 = await ideManager.setup('opencode', tempProjectDir, installedBmadDir, {
      silent: true,
      selectedModules: ['bmm'],
      previousSkillIds: new Set(['bmad-master']),
    });
    assert(result4.success === true, 'Fourth OpenCode install succeeds with hand-edited pointer present');
    const afterReinstall = await fs.readFile(commandFile, 'utf8');
    assert(afterReinstall.includes(SENTINEL), 'Hand-edited pointer survives a routine reinstall (cleanup spares active-manifest IDs)');

    await fs.remove(tempProjectDir);
    await fs.remove(path.dirname(installedBmadDir));
  } catch (error) {
    assert(false, 'OpenCode native skills migration test succeeds', error.message);
  }

  console.log('');

  // ============================================================
  // Test 9: Claude Code Native Skills Install
  // ============================================================
  console.log(`${colors.yellow}Test Suite 9: Claude Code Native Skills${colors.reset}\n`);

  try {
    clearCache();
    const platformCodes9 = await loadPlatformCodes();
    const claudeInstaller = platformCodes9.platforms['claude-code']?.installer;

    assert(claudeInstaller?.target_dir === '.claude/skills', 'Claude Code target_dir uses native skills path');

    const tempProjectDir9 = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-claude-code-test-'));
    const installedBmadDir9 = await createTestBmadFixture();
    const sourceSkillDir9 = path.join(installedBmadDir9, 'core', 'bmad-master');
    await fs.ensureDir(path.join(sourceSkillDir9, '__pycache__'));
    await fs.writeFile(path.join(sourceSkillDir9, '__pycache__', 'cached.pyc'), 'bytecode');
    await fs.writeFile(path.join(sourceSkillDir9, 'cached.pyc'), 'bytecode');
    await fs.writeFile(path.join(sourceSkillDir9, 'cached.pyo'), 'bytecode');

    const ideManager9 = new IdeManager();
    await ideManager9.ensureInitialized();
    const result9 = await ideManager9.setup('claude-code', tempProjectDir9, installedBmadDir9, {
      silent: true,
      selectedModules: ['bmm'],
    });

    assert(result9.success === true, 'Claude Code setup succeeds against temp project');

    const skillFile9 = path.join(tempProjectDir9, '.claude', 'skills', 'bmad-master', 'SKILL.md');
    assert(await fs.pathExists(skillFile9), 'Claude Code install writes SKILL.md directory output');
    const installedSkillDir9 = path.dirname(skillFile9);
    assert(
      !(await fs.pathExists(path.join(installedSkillDir9, '__pycache__'))),
      'Claude Code skill install excludes Python cache directories',
    );
    assert(
      !(await fs.pathExists(path.join(installedSkillDir9, 'cached.pyc'))) &&
        !(await fs.pathExists(path.join(installedSkillDir9, 'cached.pyo'))),
      'Claude Code skill install excludes Python bytecode',
    );

    // Verify name frontmatter matches directory name
    const skillContent9 = await fs.readFile(skillFile9, 'utf8');
    const nameMatch9 = skillContent9.match(/^name:\s*(.+)$/m);
    assert(nameMatch9 && nameMatch9[1].trim() === 'bmad-master', 'Claude Code skill name frontmatter matches directory name exactly');

    await fs.remove(tempProjectDir9);
    await fs.remove(path.dirname(installedBmadDir9));
  } catch (error) {
    assert(false, 'Claude Code native skills migration test succeeds', error.message);
  }

  console.log('');

  // Test 10: Removed — ancestor conflict check no longer applies (no IDE inherits skills from parent dirs)

  // ============================================================
  // Test 11: Codex Native Skills Install
  // ============================================================
  console.log(`${colors.yellow}Test Suite 11: Codex Native Skills${colors.reset}\n`);

  try {
    clearCache();
    const platformCodes11 = await loadPlatformCodes();
    const codexInstaller = platformCodes11.platforms.codex?.installer;

    assert(codexInstaller?.target_dir === '.agents/skills', 'Codex target_dir uses native skills path');

    const tempProjectDir11 = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-codex-test-'));
    const installedBmadDir11 = await createTestBmadFixture();

    const ideManager11 = new IdeManager();
    await ideManager11.ensureInitialized();
    const result11 = await ideManager11.setup('codex', tempProjectDir11, installedBmadDir11, {
      silent: true,
      selectedModules: ['bmm'],
    });

    assert(result11.success === true, 'Codex setup succeeds against temp project');

    const skillFile11 = path.join(tempProjectDir11, '.agents', 'skills', 'bmad-master', 'SKILL.md');
    assert(await fs.pathExists(skillFile11), 'Codex install writes SKILL.md directory output');

    // Verify name frontmatter matches directory name
    const skillContent11 = await fs.readFile(skillFile11, 'utf8');
    const nameMatch11 = skillContent11.match(/^name:\s*(.+)$/m);
    assert(nameMatch11 && nameMatch11[1].trim() === 'bmad-master', 'Codex skill name frontmatter matches directory name exactly');

    await fs.remove(tempProjectDir11);
    await fs.remove(path.dirname(installedBmadDir11));
  } catch (error) {
    assert(false, 'Codex native skills migration test succeeds', error.message);
  }

  console.log('');

  // ============================================================
  // Test 11c: Grok Native Skills Install
  // ============================================================
  console.log(`${colors.yellow}Test Suite 11c: Grok Native Skills${colors.reset}\n`);

  try {
    clearCache();
    const platformCodes11c = await loadPlatformCodes();
    const grokInstaller = platformCodes11c.platforms.grok?.installer;

    assert(grokInstaller?.target_dir === '.agents/skills', 'Grok target_dir uses native skills path');

    const tempProjectDir11c = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-grok-test-'));
    const installedBmadDir11c = await createTestBmadFixture();

    const ideManager11c = new IdeManager();
    await ideManager11c.ensureInitialized();
    const result11c = await ideManager11c.setup('grok', tempProjectDir11c, installedBmadDir11c, {
      silent: true,
      selectedModules: ['bmm'],
    });

    assert(result11c.success === true, 'Grok setup succeeds against temp project');

    const skillFile11c = path.join(tempProjectDir11c, '.agents', 'skills', 'bmad-master', 'SKILL.md');
    assert(await fs.pathExists(skillFile11c), 'Grok install writes SKILL.md directory output');

    const skillContent11c = await fs.readFile(skillFile11c, 'utf8');
    const nameMatch11c = skillContent11c.match(/^name:\s*(.+)$/m);
    assert(nameMatch11c && nameMatch11c[1].trim() === 'bmad-master', 'Grok skill name frontmatter matches directory name exactly');

    await fs.remove(tempProjectDir11c);
    await fs.remove(path.dirname(installedBmadDir11c));
  } catch (error) {
    assert(false, 'Grok native skills install test succeeds', error.message);
  }

  console.log('');

  // Test 12: Removed — ancestor conflict check no longer applies (no IDE inherits skills from parent dirs)

  // ============================================================
  // Test 12b: CodeWhale Native Skills Install
  // ============================================================
  console.log(`${colors.yellow}Test Suite 12b: CodeWhale Native Skills${colors.reset}\n`);

  try {
    clearCache();
    const platformCodes12b = await loadPlatformCodes();
    const codewhaleInstaller = platformCodes12b.platforms.codewhale?.installer;

    assert(codewhaleInstaller?.target_dir === '.codewhale/skills', 'CodeWhale target_dir uses native skills path');

    const tempProjectDir12b = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-codewhale-test-'));
    const installedBmadDir12b = await createTestBmadFixture();

    const ideManager12b = new IdeManager();
    await ideManager12b.ensureInitialized();
    const result12b = await ideManager12b.setup('codewhale', tempProjectDir12b, installedBmadDir12b, {
      silent: true,
      selectedModules: ['bmm'],
    });

    assert(result12b.success === true, 'CodeWhale setup succeeds against temp project');

    const skillFile12b = path.join(tempProjectDir12b, '.codewhale', 'skills', 'bmad-master', 'SKILL.md');
    assert(await fs.pathExists(skillFile12b), 'CodeWhale install writes SKILL.md directory output');

    await fs.remove(tempProjectDir12b);
    await fs.remove(path.dirname(installedBmadDir12b));
  } catch (error) {
    assert(false, 'CodeWhale native skills migration test succeeds', error.message);
  }

  console.log('');

  // ============================================================
  // Test 13: Cursor Native Skills Install
  // ============================================================
  console.log(`${colors.yellow}Test Suite 13: Cursor Native Skills${colors.reset}\n`);

  try {
    clearCache();
    const platformCodes13 = await loadPlatformCodes();
    const cursorInstaller = platformCodes13.platforms.cursor?.installer;

    assert(cursorInstaller?.target_dir === '.agents/skills', 'Cursor target_dir uses native skills path');

    assert(!cursorInstaller?.ancestor_conflict_check, 'Cursor installer does not enable ancestor conflict checks');

    const tempProjectDir13c = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-cursor-test-'));
    const installedBmadDir13c = await createTestBmadFixture();

    const ideManager13c = new IdeManager();
    await ideManager13c.ensureInitialized();
    const result13c = await ideManager13c.setup('cursor', tempProjectDir13c, installedBmadDir13c, {
      silent: true,
      selectedModules: ['bmm'],
    });

    assert(result13c.success === true, 'Cursor setup succeeds against temp project');

    const skillFile13c = path.join(tempProjectDir13c, '.agents', 'skills', 'bmad-master', 'SKILL.md');
    assert(await fs.pathExists(skillFile13c), 'Cursor install writes SKILL.md directory output');

    // Verify name frontmatter matches directory name
    const skillContent13c = await fs.readFile(skillFile13c, 'utf8');
    const nameMatch13c = skillContent13c.match(/^name:\s*(.+)$/m);
    assert(nameMatch13c && nameMatch13c[1].trim() === 'bmad-master', 'Cursor skill name frontmatter matches directory name exactly');

    await fs.remove(tempProjectDir13c);
    await fs.remove(path.dirname(installedBmadDir13c));
  } catch (error) {
    assert(false, 'Cursor native skills migration test succeeds', error.message);
  }

  console.log('');

  // ============================================================
  // Test 14: Roo Code Native Skills Install
  // ============================================================
  console.log(`${colors.yellow}Test Suite 14: Roo Code Native Skills${colors.reset}\n`);

  try {
    clearCache();
    const platformCodes13 = await loadPlatformCodes();
    const rooInstaller = platformCodes13.platforms.roo?.installer;

    assert(rooInstaller?.target_dir === '.agents/skills', 'Roo target_dir uses native skills path');

    const tempProjectDir13 = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-roo-test-'));
    const installedBmadDir13 = await createTestBmadFixture();

    const ideManager13 = new IdeManager();
    await ideManager13.ensureInitialized();
    const result13 = await ideManager13.setup('roo', tempProjectDir13, installedBmadDir13, {
      silent: true,
      selectedModules: ['bmm'],
    });

    assert(result13.success === true, 'Roo setup succeeds against temp project');

    const skillFile13 = path.join(tempProjectDir13, '.agents', 'skills', 'bmad-master', 'SKILL.md');
    assert(await fs.pathExists(skillFile13), 'Roo install writes SKILL.md directory output');

    // Verify name frontmatter matches directory name (Roo constraint: lowercase alphanumeric + hyphens)
    const skillContent13 = await fs.readFile(skillFile13, 'utf8');
    const nameMatch13 = skillContent13.match(/^name:\s*(.+)$/m);
    assert(
      nameMatch13 && nameMatch13[1].trim() === 'bmad-master',
      'Roo skill name frontmatter matches directory name exactly (lowercase alphanumeric + hyphens)',
    );

    // Reinstall/upgrade: run setup again over existing skills output
    const result13b = await ideManager13.setup('roo', tempProjectDir13, installedBmadDir13, {
      silent: true,
      selectedModules: ['bmm'],
    });

    assert(result13b.success === true, 'Roo reinstall/upgrade succeeds over existing skills');
    assert(await fs.pathExists(skillFile13), 'Roo reinstall preserves SKILL.md output');

    await fs.remove(tempProjectDir13);
    await fs.remove(path.dirname(installedBmadDir13));
  } catch (error) {
    assert(false, 'Roo native skills migration test succeeds', error.message);
  }

  console.log('');

  // Test 15: Removed — ancestor conflict check no longer applies (no IDE inherits skills from parent dirs)

  // Test 16: Removed — old YAML→XML QA agent compilation no longer applies (agents now use SKILL.md format)

  console.log('');

  // ============================================================
  // Test 17: GitHub Copilot Native Skills Install
  // ============================================================
  console.log(`${colors.yellow}Test Suite 17: GitHub Copilot Native Skills${colors.reset}\n`);

  try {
    clearCache();
    const platformCodes17 = await loadPlatformCodes();
    const copilotInstaller = platformCodes17.platforms['github-copilot']?.installer;

    assert(copilotInstaller?.target_dir === '.agents/skills', 'GitHub Copilot target_dir uses native skills path');
    assert(
      copilotInstaller?.commands_target_dir === '.github/agents',
      'GitHub Copilot commands_target_dir is configured for the Custom Agents picker',
    );
    assert(copilotInstaller?.commands_extension === '.agent.md', 'GitHub Copilot uses .agent.md extension for Custom Agents files');
    assert(
      typeof copilotInstaller?.commands_body_template === 'string' && copilotInstaller.commands_body_template.includes('{canonicalId}'),
      'GitHub Copilot defines a commands_body_template with {canonicalId} placeholder',
    );
    assert(
      copilotInstaller?.commands_filter === 'agents-only',
      'GitHub Copilot filters Custom Agents picker to persona agents only (agents-only)',
    );

    const tempProjectDir17 = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-copilot-test-'));
    const installedBmadDir17 = await createTestBmadFixture();

    // Extend the fixture to exercise the agents-only filter, which detects
    // persona agents by the `[agent]` section in each skill's source
    // customize.toml. Five skill types covered:
    //
    //   1. Persona agent — has customize.toml with [agent]      → INCLUDED
    //   2. Persona with non-conventional id — also has [agent]   → INCLUDED
    //      (verifies the filter doesn't depend on `-agent-` naming)
    //   3. Meta-skill whose id contains `-agent-` but isn't a
    //      persona — has customize.toml with [workflow]          → EXCLUDED
    //      (mirrors `bmad-agent-builder` in the real manifest)
    //   4. Workflow skill — no customize.toml at all             → EXCLUDED
    //   5. `bmad-help` — meta-help skill with no customize.toml;
    //      every persona agent's activation already advertises it,
    //      so it's correctly excluded from the picker as redundant    → EXCLUDED
    const fixtureCsvPath17 = path.join(installedBmadDir17, '_config', 'skill-manifest.csv');
    await fs.writeFile(
      fixtureCsvPath17,
      [
        'canonicalId,name,description,module,path',
        '"bmad-master","bmad-master","Workflow with no customize.toml — should NOT appear in Copilot agents picker","core","_bmad/core/bmad-master/SKILL.md"',
        '"bmad-agent-fixture","bmad-agent-fixture","Persona agent — customize.toml has [agent], SHOULD appear","core","_bmad/core/bmad-agent-fixture/SKILL.md"',
        '"bmad-tea","bmad-tea","Non-conventional id but [agent] in customize.toml — SHOULD appear","core","_bmad/core/bmad-tea/SKILL.md"',
        '"bmad-agent-builder","bmad-agent-builder","Skill-builder workflow — id contains -agent- but customize.toml has [workflow] — should NOT appear","core","_bmad/core/bmad-agent-builder/SKILL.md"',
        '"bmad-help","bmad-help","Meta-help skill — no customize.toml; SHOULD NOT appear in agents picker (toml-driven filter)","core","_bmad/core/bmad-help/SKILL.md"',
        '',
      ].join('\n'),
    );

    // Materialise the source skill directories so the agents-only filter
    // can read their customize.toml. The bmad-master and bmad-agent-builder
    // SKILL.md files were already populated by createTestBmadFixture (they
    // share the bmad-master target_dir layout); only the customize.toml
    // and the new agent fixtures need to be created here.
    for (const id of ['bmad-agent-fixture', 'bmad-tea', 'bmad-agent-builder', 'bmad-help']) {
      const dir17 = path.join(installedBmadDir17, 'core', id);
      await fs.ensureDir(dir17);
      await fs.writeFile(
        path.join(dir17, 'SKILL.md'),
        ['---', `name: ${id}`, `description: fixture for ${id}`, '---', '', `Body of ${id}.`].join('\n'),
      );
    }
    // Note: bmad-help intentionally has NO customize.toml — it exercises
    // the toml-driven filter's exclusion path (a skill with no
    // customize.toml is correctly kept out of the Copilot agents picker).
    // [agent] customize.toml for the two persona fixtures.
    await fs.writeFile(
      path.join(installedBmadDir17, 'core', 'bmad-agent-fixture', 'customize.toml'),
      ['[agent]', 'name = "Fixture Agent"', 'title = "Test Persona"', ''].join('\n'),
    );
    await fs.writeFile(
      path.join(installedBmadDir17, 'core', 'bmad-tea', 'customize.toml'),
      ['[agent]', 'name = "Murat"', 'title = "Test Architect"', ''].join('\n'),
    );
    // [workflow] customize.toml for the meta-skill — its id contains `-agent-`
    // but it is NOT a persona (mirrors bmad-agent-builder in production).
    await fs.writeFile(
      path.join(installedBmadDir17, 'core', 'bmad-agent-builder', 'customize.toml'),
      ['[workflow]', '', '# Meta-skill that builds agents but is not itself a persona.', ''].join('\n'),
    );

    const copilotInstructionsPath17 = path.join(tempProjectDir17, '.github', 'copilot-instructions.md');
    await fs.ensureDir(path.dirname(copilotInstructionsPath17));
    await fs.writeFile(
      copilotInstructionsPath17,
      'User content before\n<!-- BMAD:START -->\nBMAD generated content\n<!-- BMAD:END -->\nUser content after\n',
    );

    const ideManager17 = new IdeManager();
    await ideManager17.ensureInitialized();
    const result17 = await ideManager17.setup('github-copilot', tempProjectDir17, installedBmadDir17, {
      silent: true,
      selectedModules: ['bmm'],
    });

    assert(result17.success === true, 'GitHub Copilot setup succeeds against temp project');

    const skillFile17 = path.join(tempProjectDir17, '.agents', 'skills', 'bmad-master', 'SKILL.md');
    assert(await fs.pathExists(skillFile17), 'GitHub Copilot install writes SKILL.md directory output');

    // Verify name frontmatter matches directory name
    const skillContent17 = await fs.readFile(skillFile17, 'utf8');
    const nameMatch17 = skillContent17.match(/^name:\s*(.+)$/m);
    assert(nameMatch17 && nameMatch17[1].trim() === 'bmad-master', 'GitHub Copilot skill name frontmatter matches directory name exactly');

    // Verify copilot-instructions.md BMAD markers were stripped but user content preserved
    const cleanedInstructions17 = await fs.readFile(copilotInstructionsPath17, 'utf8');
    assert(
      !cleanedInstructions17.includes('BMAD:START') && !cleanedInstructions17.includes('BMAD generated content'),
      'GitHub Copilot setup strips BMAD markers from copilot-instructions.md',
    );
    assert(
      cleanedInstructions17.includes('User content before') && cleanedInstructions17.includes('User content after'),
      'GitHub Copilot setup preserves user content in copilot-instructions.md',
    );

    // Custom Agents picker integration: persona agents (those with [agent]
    // in their source customize.toml) get .agent.md files in
    // .github/agents/. Workflows and meta-skills with [workflow] (or no
    // customize.toml at all) do NOT — the agents-only filter keeps the
    // picker uncluttered and the signal is naming-independent.
    const agentsDir17 = path.join(tempProjectDir17, '.github', 'agents');
    const agentFileForPersona17 = path.join(agentsDir17, 'bmad-agent-fixture.agent.md');
    const agentFileForTea17 = path.join(agentsDir17, 'bmad-tea.agent.md');
    const agentFileForWorkflow17 = path.join(agentsDir17, 'bmad-master.agent.md');
    const agentFileForMetaSkill17 = path.join(agentsDir17, 'bmad-agent-builder.agent.md');
    const agentFileForBmadHelp17 = path.join(agentsDir17, 'bmad-help.agent.md');

    assert(
      await fs.pathExists(agentFileForPersona17),
      'Persona agent ([agent] in customize.toml) gets a .agent.md file in .github/agents/',
    );
    assert(await fs.pathExists(agentFileForTea17), 'Non-conventional id with [agent] in customize.toml is included (no allowlist needed)');
    assert(!(await fs.pathExists(agentFileForWorkflow17)), 'Workflow skill (no customize.toml) is FILTERED OUT of .github/agents/');
    assert(
      !(await fs.pathExists(agentFileForBmadHelp17)),
      'bmad-help is excluded from Copilot agents picker (no customize.toml; allowlist removed per maintainer feedback)',
    );
    assert(
      !(await fs.pathExists(agentFileForMetaSkill17)),
      'Meta-skill with -agent- in id but [workflow] in customize.toml is FILTERED OUT (signal is behavior, not naming)',
    );

    // Body content of the persona agent file: frontmatter description +
    // LOAD pattern referencing the skill's SKILL.md path under target_dir.
    const personaAgentContent17 = await fs.readFile(agentFileForPersona17, 'utf8');
    assert(
      personaAgentContent17.includes('description:'),
      'Copilot agent pointer carries a description in YAML frontmatter (drives the agents picker label)',
    );
    assert(
      personaAgentContent17.includes('{project-root}/.agents/skills/bmad-agent-fixture/SKILL.md'),
      'Copilot agent pointer body resolves to the skill via LOAD {project-root}/<target_dir>/<id>/SKILL.md',
    );

    // Idempotency: re-running setup must not duplicate or rewrite the agent
    // pointer when the source manifest is unchanged, AND must not start
    // emitting workflow-skill agent files.
    const result17b = await ideManager17.setup('github-copilot', tempProjectDir17, installedBmadDir17, {
      silent: true,
      selectedModules: ['bmm'],
    });
    assert(result17b.success === true, 'Second GitHub Copilot install succeeds (idempotent)');
    assert(await fs.pathExists(agentFileForPersona17), 'Persona agent pointer survives a second install pass');
    assert(!(await fs.pathExists(agentFileForWorkflow17)), 'Workflow skill remains filtered out of agents picker on second install');

    await fs.remove(tempProjectDir17);
    await fs.remove(path.dirname(installedBmadDir17));
  } catch (error) {
    assert(false, 'GitHub Copilot native skills migration test succeeds', error.message);
  }

  console.log('');

  // ============================================================
  // Test 18: Cline Native Skills Install
  // ============================================================
  console.log(`${colors.yellow}Test Suite 18: Cline Native Skills${colors.reset}\n`);

  try {
    clearCache();
    const platformCodes18 = await loadPlatformCodes();
    const clineInstaller = platformCodes18.platforms.cline?.installer;

    assert(clineInstaller?.target_dir === '.cline/skills', 'Cline target_dir uses native skills path');

    const tempProjectDir18 = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-cline-test-'));
    const installedBmadDir18 = await createTestBmadFixture();

    const ideManager18 = new IdeManager();
    await ideManager18.ensureInitialized();
    const result18 = await ideManager18.setup('cline', tempProjectDir18, installedBmadDir18, {
      silent: true,
      selectedModules: ['bmm'],
    });

    assert(result18.success === true, 'Cline setup succeeds against temp project');

    const skillFile18 = path.join(tempProjectDir18, '.cline', 'skills', 'bmad-master', 'SKILL.md');
    assert(await fs.pathExists(skillFile18), 'Cline install writes SKILL.md directory output');

    // Verify name frontmatter matches directory name
    const skillContent18 = await fs.readFile(skillFile18, 'utf8');
    const nameMatch18 = skillContent18.match(/^name:\s*(.+)$/m);
    assert(nameMatch18 && nameMatch18[1].trim() === 'bmad-master', 'Cline skill name frontmatter matches directory name exactly');

    // Reinstall/upgrade: run setup again over existing skills output
    const result18b = await ideManager18.setup('cline', tempProjectDir18, installedBmadDir18, {
      silent: true,
      selectedModules: ['bmm'],
    });

    assert(result18b.success === true, 'Cline reinstall/upgrade succeeds over existing skills');
    assert(await fs.pathExists(skillFile18), 'Cline reinstall preserves SKILL.md output');

    await fs.remove(tempProjectDir18);
    await fs.remove(path.dirname(installedBmadDir18));
  } catch (error) {
    assert(false, 'Cline native skills migration test succeeds', error.message);
  }

  console.log('');

  // ============================================================
  // Test 19: CodeBuddy Native Skills Install
  // ============================================================
  console.log(`${colors.yellow}Test Suite 19: CodeBuddy Native Skills${colors.reset}\n`);

  try {
    clearCache();
    const platformCodes19 = await loadPlatformCodes();
    const codebuddyInstaller = platformCodes19.platforms.codebuddy?.installer;

    assert(codebuddyInstaller?.target_dir === '.codebuddy/skills', 'CodeBuddy target_dir uses native skills path');

    const tempProjectDir19 = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-codebuddy-test-'));
    const installedBmadDir19 = await createTestBmadFixture();

    const ideManager19 = new IdeManager();
    await ideManager19.ensureInitialized();
    const result19 = await ideManager19.setup('codebuddy', tempProjectDir19, installedBmadDir19, {
      silent: true,
      selectedModules: ['bmm'],
    });

    assert(result19.success === true, 'CodeBuddy setup succeeds against temp project');

    const skillFile19 = path.join(tempProjectDir19, '.codebuddy', 'skills', 'bmad-master', 'SKILL.md');
    assert(await fs.pathExists(skillFile19), 'CodeBuddy install writes SKILL.md directory output');

    const skillContent19 = await fs.readFile(skillFile19, 'utf8');
    const nameMatch19 = skillContent19.match(/^name:\s*(.+)$/m);
    assert(nameMatch19 && nameMatch19[1].trim() === 'bmad-master', 'CodeBuddy skill name frontmatter matches directory name exactly');

    const result19b = await ideManager19.setup('codebuddy', tempProjectDir19, installedBmadDir19, {
      silent: true,
      selectedModules: ['bmm'],
    });

    assert(result19b.success === true, 'CodeBuddy reinstall/upgrade succeeds over existing skills');
    assert(await fs.pathExists(skillFile19), 'CodeBuddy reinstall preserves SKILL.md output');

    await fs.remove(tempProjectDir19);
    await fs.remove(path.dirname(installedBmadDir19));
  } catch (error) {
    assert(false, 'CodeBuddy native skills migration test succeeds', error.message);
  }

  console.log('');

  // ============================================================
  // Test 20: Crush Native Skills Install
  // ============================================================
  console.log(`${colors.yellow}Test Suite 20: Crush Native Skills${colors.reset}\n`);

  try {
    clearCache();
    const platformCodes20 = await loadPlatformCodes();
    const crushInstaller = platformCodes20.platforms.crush?.installer;

    assert(crushInstaller?.target_dir === '.agents/skills', 'Crush target_dir uses native skills path');

    const tempProjectDir20 = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-crush-test-'));
    const installedBmadDir20 = await createTestBmadFixture();

    const ideManager20 = new IdeManager();
    await ideManager20.ensureInitialized();
    const result20 = await ideManager20.setup('crush', tempProjectDir20, installedBmadDir20, {
      silent: true,
      selectedModules: ['bmm'],
    });

    assert(result20.success === true, 'Crush setup succeeds against temp project');

    const skillFile20 = path.join(tempProjectDir20, '.agents', 'skills', 'bmad-master', 'SKILL.md');
    assert(await fs.pathExists(skillFile20), 'Crush install writes SKILL.md directory output');

    const skillContent20 = await fs.readFile(skillFile20, 'utf8');
    const nameMatch20 = skillContent20.match(/^name:\s*(.+)$/m);
    assert(nameMatch20 && nameMatch20[1].trim() === 'bmad-master', 'Crush skill name frontmatter matches directory name exactly');

    const result20b = await ideManager20.setup('crush', tempProjectDir20, installedBmadDir20, {
      silent: true,
      selectedModules: ['bmm'],
    });

    assert(result20b.success === true, 'Crush reinstall/upgrade succeeds over existing skills');
    assert(await fs.pathExists(skillFile20), 'Crush reinstall preserves SKILL.md output');

    await fs.remove(tempProjectDir20);
    await fs.remove(path.dirname(installedBmadDir20));
  } catch (error) {
    assert(false, 'Crush native skills migration test succeeds', error.message);
  }

  console.log('');

  // ============================================================
  // Test 21: Trae Native Skills Install
  // ============================================================
  console.log(`${colors.yellow}Test Suite 21: Trae Native Skills${colors.reset}\n`);

  try {
    clearCache();
    const platformCodes21 = await loadPlatformCodes();
    const traeInstaller = platformCodes21.platforms.trae?.installer;

    assert(traeInstaller?.target_dir === '.trae/skills', 'Trae target_dir uses native skills path');

    const tempProjectDir21 = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-trae-test-'));
    const installedBmadDir21 = await createTestBmadFixture();

    const ideManager21 = new IdeManager();
    await ideManager21.ensureInitialized();
    const result21 = await ideManager21.setup('trae', tempProjectDir21, installedBmadDir21, {
      silent: true,
      selectedModules: ['bmm'],
    });

    assert(result21.success === true, 'Trae setup succeeds against temp project');

    const skillFile21 = path.join(tempProjectDir21, '.trae', 'skills', 'bmad-master', 'SKILL.md');
    assert(await fs.pathExists(skillFile21), 'Trae install writes SKILL.md directory output');

    const skillContent21 = await fs.readFile(skillFile21, 'utf8');
    const nameMatch21 = skillContent21.match(/^name:\s*(.+)$/m);
    assert(nameMatch21 && nameMatch21[1].trim() === 'bmad-master', 'Trae skill name frontmatter matches directory name exactly');

    const result21b = await ideManager21.setup('trae', tempProjectDir21, installedBmadDir21, {
      silent: true,
      selectedModules: ['bmm'],
    });

    assert(result21b.success === true, 'Trae reinstall/upgrade succeeds over existing skills');
    assert(await fs.pathExists(skillFile21), 'Trae reinstall preserves SKILL.md output');

    await fs.remove(tempProjectDir21);
    await fs.remove(path.dirname(installedBmadDir21));
  } catch (error) {
    assert(false, 'Trae native skills migration test succeeds', error.message);
  }

  console.log('');

  // ============================================================
  // Suite 22: KiloCoder Native Skills
  // ============================================================
  console.log(`${colors.yellow}Test Suite 22: KiloCoder Native Skills${colors.reset}\n`);

  try {
    clearCache();
    const platformCodes22 = await loadPlatformCodes();
    const kiloConfig22 = platformCodes22.platforms.kilo;

    assert(!kiloConfig22?.suspended, 'KiloCoder is not suspended');

    assert(kiloConfig22?.installer?.target_dir === '.agents/skills', 'KiloCoder target_dir uses native skills path');

    const ideManager22 = new IdeManager();
    await ideManager22.ensureInitialized();

    // Should appear in available IDEs
    const availableIdes22 = ideManager22.getAvailableIdes();
    assert(
      availableIdes22.some((ide) => ide.value === 'kilo'),
      'KiloCoder appears in IDE selection',
    );

    const tempProjectDir22 = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-kilo-test-'));
    const installedBmadDir22 = await createTestBmadFixture();

    const result22 = await ideManager22.setup('kilo', tempProjectDir22, installedBmadDir22, {
      silent: true,
      selectedModules: ['bmm'],
    });

    assert(result22.success === true, 'KiloCoder setup succeeds against temp project');

    const skillFile22 = path.join(tempProjectDir22, '.agents', 'skills', 'bmad-master', 'SKILL.md');
    assert(await fs.pathExists(skillFile22), 'KiloCoder install writes SKILL.md directory output');

    const skillContent22 = await fs.readFile(skillFile22, 'utf8');
    const nameMatch22 = skillContent22.match(/^name:\s*(.+)$/m);
    assert(nameMatch22 && nameMatch22[1].trim() === 'bmad-master', 'KiloCoder skill name frontmatter matches directory name exactly');

    const result22b = await ideManager22.setup('kilo', tempProjectDir22, installedBmadDir22, {
      silent: true,
      selectedModules: ['bmm'],
    });

    assert(result22b.success === true, 'KiloCoder reinstall/upgrade succeeds over existing skills');
    assert(await fs.pathExists(skillFile22), 'KiloCoder reinstall preserves SKILL.md output');

    await fs.remove(tempProjectDir22);
    await fs.remove(path.dirname(installedBmadDir22));
  } catch (error) {
    assert(false, 'KiloCoder native skills test succeeds', error.message);
  }

  console.log('');

  // ============================================================
  // Suite 23: Gemini CLI Native Skills
  // ============================================================
  console.log(`${colors.yellow}Test Suite 23: Gemini CLI Native Skills${colors.reset}\n`);

  try {
    clearCache();
    const platformCodes23 = await loadPlatformCodes();
    const geminiInstaller = platformCodes23.platforms.gemini?.installer;

    assert(geminiInstaller?.target_dir === '.agents/skills', 'Gemini target_dir uses native skills path');

    const tempProjectDir23 = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-gemini-test-'));
    const installedBmadDir23 = await createTestBmadFixture();

    const ideManager23 = new IdeManager();
    await ideManager23.ensureInitialized();
    const result23 = await ideManager23.setup('gemini', tempProjectDir23, installedBmadDir23, {
      silent: true,
      selectedModules: ['bmm'],
    });

    assert(result23.success === true, 'Gemini setup succeeds against temp project');

    const skillFile23 = path.join(tempProjectDir23, '.agents', 'skills', 'bmad-master', 'SKILL.md');
    assert(await fs.pathExists(skillFile23), 'Gemini install writes SKILL.md directory output');

    const skillContent23 = await fs.readFile(skillFile23, 'utf8');
    const nameMatch23 = skillContent23.match(/^name:\s*(.+)$/m);
    assert(nameMatch23 && nameMatch23[1].trim() === 'bmad-master', 'Gemini skill name frontmatter matches directory name exactly');

    const result23b = await ideManager23.setup('gemini', tempProjectDir23, installedBmadDir23, {
      silent: true,
      selectedModules: ['bmm'],
    });

    assert(result23b.success === true, 'Gemini reinstall/upgrade succeeds over existing skills');
    assert(await fs.pathExists(skillFile23), 'Gemini reinstall preserves SKILL.md output');

    await fs.remove(tempProjectDir23);
    await fs.remove(path.dirname(installedBmadDir23));
  } catch (error) {
    assert(false, 'Gemini native skills migration test succeeds', error.message);
  }

  console.log('');

  // ============================================================
  // Suite 24: iFlow Native Skills
  // ============================================================
  console.log(`${colors.yellow}Test Suite 24: iFlow Native Skills${colors.reset}\n`);

  try {
    clearCache();
    const platformCodes24 = await loadPlatformCodes();
    const iflowInstaller = platformCodes24.platforms.iflow?.installer;

    assert(iflowInstaller?.target_dir === '.iflow/skills', 'iFlow target_dir uses native skills path');

    const tempProjectDir24 = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-iflow-test-'));
    const installedBmadDir24 = await createTestBmadFixture();

    const ideManager24 = new IdeManager();
    await ideManager24.ensureInitialized();
    const result24 = await ideManager24.setup('iflow', tempProjectDir24, installedBmadDir24, {
      silent: true,
      selectedModules: ['bmm'],
    });

    assert(result24.success === true, 'iFlow setup succeeds against temp project');

    const skillFile24 = path.join(tempProjectDir24, '.iflow', 'skills', 'bmad-master', 'SKILL.md');
    assert(await fs.pathExists(skillFile24), 'iFlow install writes SKILL.md directory output');

    // Verify name frontmatter matches directory name
    const skillContent24 = await fs.readFile(skillFile24, 'utf8');
    const nameMatch24 = skillContent24.match(/^name:\s*(.+)$/m);
    assert(nameMatch24 && nameMatch24[1].trim() === 'bmad-master', 'iFlow skill name frontmatter matches directory name exactly');

    await fs.remove(tempProjectDir24);
    await fs.remove(path.dirname(installedBmadDir24));
  } catch (error) {
    assert(false, 'iFlow native skills migration test succeeds', error.message);
  }

  console.log('');

  // ============================================================
  // Suite 25: QwenCoder Native Skills
  // ============================================================
  console.log(`${colors.yellow}Test Suite 25: QwenCoder Native Skills${colors.reset}\n`);

  try {
    clearCache();
    const platformCodes25 = await loadPlatformCodes();
    const qwenInstaller = platformCodes25.platforms.qwen?.installer;

    assert(qwenInstaller?.target_dir === '.qwen/skills', 'QwenCoder target_dir uses native skills path');

    const tempProjectDir25 = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-qwen-test-'));
    const installedBmadDir25 = await createTestBmadFixture();

    const ideManager25 = new IdeManager();
    await ideManager25.ensureInitialized();
    const result25 = await ideManager25.setup('qwen', tempProjectDir25, installedBmadDir25, {
      silent: true,
      selectedModules: ['bmm'],
    });

    assert(result25.success === true, 'QwenCoder setup succeeds against temp project');

    const skillFile25 = path.join(tempProjectDir25, '.qwen', 'skills', 'bmad-master', 'SKILL.md');
    assert(await fs.pathExists(skillFile25), 'QwenCoder install writes SKILL.md directory output');

    // Verify name frontmatter matches directory name
    const skillContent25 = await fs.readFile(skillFile25, 'utf8');
    const nameMatch25 = skillContent25.match(/^name:\s*(.+)$/m);
    assert(nameMatch25 && nameMatch25[1].trim() === 'bmad-master', 'QwenCoder skill name frontmatter matches directory name exactly');

    await fs.remove(tempProjectDir25);
    await fs.remove(path.dirname(installedBmadDir25));
  } catch (error) {
    assert(false, 'QwenCoder native skills migration test succeeds', error.message);
  }

  console.log('');

  // ============================================================
  // Suite 26: Rovo Dev Native Skills
  // ============================================================
  console.log(`${colors.yellow}Test Suite 26: Rovo Dev Native Skills${colors.reset}\n`);

  try {
    clearCache();
    const platformCodes26 = await loadPlatformCodes();
    const rovoInstaller = platformCodes26.platforms['rovo-dev']?.installer;

    assert(rovoInstaller?.target_dir === '.agents/skills', 'Rovo Dev target_dir uses native skills path');

    const tempProjectDir26 = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-rovodev-test-'));
    const installedBmadDir26 = await createTestBmadFixture();

    // Create a prompts.yml with BMAD entries and a user entry
    const yaml26 = require('yaml');
    const promptsPath26 = path.join(tempProjectDir26, '.rovodev', 'prompts.yml');
    const promptsContent26 = yaml26.stringify({
      prompts: [
        { name: 'bmad-bmm-create-prd', description: 'BMAD workflow', content_file: 'workflows/bmad-bmm-create-prd.md' },
        { name: 'my-custom-prompt', description: 'User prompt', content_file: 'custom.md' },
      ],
    });
    await fs.ensureDir(path.dirname(promptsPath26));
    await fs.writeFile(promptsPath26, promptsContent26);

    const ideManager26 = new IdeManager();
    await ideManager26.ensureInitialized();
    const result26 = await ideManager26.setup('rovo-dev', tempProjectDir26, installedBmadDir26, {
      silent: true,
      selectedModules: ['bmm'],
    });

    assert(result26.success === true, 'Rovo Dev setup succeeds against temp project');

    const skillFile26 = path.join(tempProjectDir26, '.agents', 'skills', 'bmad-master', 'SKILL.md');
    assert(await fs.pathExists(skillFile26), 'Rovo Dev install writes SKILL.md directory output');

    // Verify name frontmatter matches directory name
    const skillContent26 = await fs.readFile(skillFile26, 'utf8');
    const nameMatch26 = skillContent26.match(/^name:\s*(.+)$/m);
    assert(nameMatch26 && nameMatch26[1].trim() === 'bmad-master', 'Rovo Dev skill name frontmatter matches directory name exactly');

    // Verify prompts.yml cleanup: BMAD entries removed, user entry preserved
    const cleanedPrompts26 = yaml26.parse(await fs.readFile(promptsPath26, 'utf8'));
    assert(
      Array.isArray(cleanedPrompts26.prompts) && cleanedPrompts26.prompts.length === 1,
      'Rovo Dev cleanup removes BMAD entries from prompts.yml',
    );
    assert(cleanedPrompts26.prompts[0].name === 'my-custom-prompt', 'Rovo Dev cleanup preserves non-BMAD entries in prompts.yml');

    await fs.remove(tempProjectDir26);
    await fs.remove(path.dirname(installedBmadDir26));
  } catch (error) {
    assert(false, 'Rovo Dev native skills migration test succeeds', error.message);
  }

  console.log('');

  // ============================================================
  // Suite 27: Cleanup preserves bmad-os-* skills
  // ============================================================
  console.log(`${colors.yellow}Test Suite 27: Cleanup preserves bmad-os-* skills${colors.reset}\n`);

  try {
    const tempProjectDir27 = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-os-preserve-test-'));
    const installedBmadDir27 = await createTestBmadFixture();

    // Pre-populate .claude/skills with bmad-os-* skills (version-controlled repo skills)
    const osSkillDir27 = path.join(tempProjectDir27, '.claude', 'skills', 'bmad-os-review-pr');
    await fs.ensureDir(osSkillDir27);
    await fs.writeFile(
      path.join(osSkillDir27, 'SKILL.md'),
      '---\nname: bmad-os-review-pr\ndescription: Review PRs\n---\nOS skill content\n',
    );

    const osSkillDir27b = path.join(tempProjectDir27, '.claude', 'skills', 'bmad-os-release-module');
    await fs.ensureDir(osSkillDir27b);
    await fs.writeFile(
      path.join(osSkillDir27b, 'SKILL.md'),
      '---\nname: bmad-os-release-module\ndescription: Release module\n---\nOS skill content\n',
    );

    // Also add a regular bmad skill that SHOULD be cleaned up
    const regularSkillDir27 = path.join(tempProjectDir27, '.claude', 'skills', 'bmad-architect');
    await fs.ensureDir(regularSkillDir27);
    await fs.writeFile(
      path.join(regularSkillDir27, 'SKILL.md'),
      '---\nname: bmad-architect\ndescription: Architect\n---\nOld skill content\n',
    );

    // Add bmad-architect to the existing skill-manifest.csv so cleanup knows it was previously installed
    const configDir27 = path.join(installedBmadDir27, '_config');
    const existingCsv27 = await fs.readFile(path.join(configDir27, 'skill-manifest.csv'), 'utf8');
    await fs.writeFile(
      path.join(configDir27, 'skill-manifest.csv'),
      existingCsv27.trimEnd() + '\n"bmad-architect","bmad-architect","Architect","bmm","_bmad/bmm/agents/bmad-architect/SKILL.md"\n',
    );

    // Run Claude Code setup (which triggers cleanup then install)
    const ideManager27 = new IdeManager();
    await ideManager27.ensureInitialized();
    const result27 = await ideManager27.setup('claude-code', tempProjectDir27, installedBmadDir27, {
      silent: true,
      selectedModules: ['bmm'],
    });

    assert(result27.success === true, 'Claude Code setup succeeds with bmad-os-* skills present');

    // bmad-os-* skills must survive
    assert(await fs.pathExists(osSkillDir27), 'Cleanup preserves bmad-os-review-pr skill');
    assert(await fs.pathExists(osSkillDir27b), 'Cleanup preserves bmad-os-release-module skill');

    // bmad-os skill content must be untouched
    const osContent27 = await fs.readFile(path.join(osSkillDir27, 'SKILL.md'), 'utf8');
    assert(osContent27.includes('OS skill content'), 'bmad-os-review-pr skill content is unchanged');

    // Regular bmad skill should have been replaced by fresh install
    const newSkillFile27 = path.join(tempProjectDir27, '.claude', 'skills', 'bmad-master', 'SKILL.md');
    assert(await fs.pathExists(newSkillFile27), 'Fresh bmad skills are installed alongside preserved bmad-os-* skills');

    // Stale non-bmad-os skill must have been removed by cleanup
    assert(!(await fs.pathExists(regularSkillDir27)), 'Cleanup removes stale non-bmad-os skills');

    await fs.remove(tempProjectDir27);
    await fs.remove(path.dirname(installedBmadDir27));
  } catch (error) {
    assert(false, 'bmad-os-* skill preservation test succeeds', error.message);
  }

  console.log('');

  // ============================================================
  // Suite 28: Pi Native Skills
  // ============================================================
  console.log(`${colors.yellow}Test Suite 28: Pi Native Skills${colors.reset}\n`);

  let tempProjectDir28;
  let installedBmadDir28;
  try {
    clearCache();
    const platformCodes28 = await loadPlatformCodes();
    const piInstaller = platformCodes28.platforms.pi?.installer;

    assert(piInstaller?.target_dir === '.agents/skills', 'Pi target_dir uses native skills path');

    tempProjectDir28 = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-pi-test-'));
    installedBmadDir28 = await createTestBmadFixture();

    const ideManager28 = new IdeManager();
    await ideManager28.ensureInitialized();

    // Verify Pi is selectable in available IDEs list
    const availableIdes28 = ideManager28.getAvailableIdes();
    assert(
      availableIdes28.some((ide) => ide.value === 'pi'),
      'Pi appears in available IDEs list',
    );

    // Verify Pi is NOT detected before install
    const detectedBefore28 = await ideManager28.detectInstalledIdes(tempProjectDir28);
    assert(!detectedBefore28.includes('pi'), 'Pi is not detected before install');

    const result28 = await ideManager28.setup('pi', tempProjectDir28, installedBmadDir28, {
      silent: true,
      selectedModules: ['bmm'],
    });

    assert(result28.success === true, 'Pi setup succeeds against temp project');

    // Verify Pi IS detected after install
    const detectedAfter28 = await ideManager28.detectInstalledIdes(tempProjectDir28);
    assert(detectedAfter28.includes('pi'), 'Pi is detected after install');

    const skillFile28 = path.join(tempProjectDir28, '.agents', 'skills', 'bmad-master', 'SKILL.md');
    assert(await fs.pathExists(skillFile28), 'Pi install writes SKILL.md directory output');

    // Parse YAML frontmatter between --- markers
    const skillContent28 = await fs.readFile(skillFile28, 'utf8');
    const fmMatch28 = skillContent28.match(/^---\n([\s\S]*?)\n---\n?([\s\S]*)$/);
    assert(fmMatch28, 'Pi SKILL.md contains valid frontmatter delimiters');

    const frontmatter28 = fmMatch28[1];
    const body28 = fmMatch28[2];

    // Verify name in frontmatter matches directory name
    const fmName28 = frontmatter28.match(/^name:\s*(.+)$/m);
    assert(fmName28 && fmName28[1].trim() === 'bmad-master', 'Pi skill name frontmatter matches directory name exactly');

    // Verify description exists and is non-empty
    const fmDesc28 = frontmatter28.match(/^description:\s*(.+)$/m);
    assert(fmDesc28 && fmDesc28[1].trim().length > 0, 'Pi skill description frontmatter is present and non-empty');

    // Verify frontmatter contains only name and description keys
    const fmKeys28 = [...frontmatter28.matchAll(/^([a-zA-Z0-9_-]+):/gm)].map((m) => m[1]);
    assert(
      fmKeys28.length === 2 && fmKeys28.includes('name') && fmKeys28.includes('description'),
      'Pi skill frontmatter contains only name and description keys',
    );

    // Verify body content is non-empty and contains expected activation instructions
    assert(body28.trim().length > 0, 'Pi skill body content is non-empty');
    assert(body28.includes('agent-activation'), 'Pi skill body contains expected agent activation instructions');

    // Reinstall/upgrade: run setup again over existing output
    const result28b = await ideManager28.setup('pi', tempProjectDir28, installedBmadDir28, {
      silent: true,
      selectedModules: ['bmm'],
    });
    assert(result28b.success === true, 'Pi reinstall/upgrade succeeds over existing skills');
    assert(await fs.pathExists(skillFile28), 'Pi reinstall preserves SKILL.md output');
  } catch (error) {
    assert(false, 'Pi native skills test succeeds', error.message);
  } finally {
    if (tempProjectDir28) await fs.remove(tempProjectDir28).catch(() => {});
    if (installedBmadDir28) await fs.remove(path.dirname(installedBmadDir28)).catch(() => {});
  }

  console.log('');

  // ============================================================
  // Suite 28b: Polytoken Native Skills
  // ============================================================
  console.log(`${colors.yellow}Test Suite 28b: Polytoken Native Skills${colors.reset}\n`);

  let tempProjectDir28b;
  let installedBmadDir28b;
  try {
    clearCache();
    const platformCodes28b = await loadPlatformCodes();
    const polytokenInstaller = platformCodes28b.platforms.polytoken?.installer;

    assert(polytokenInstaller?.target_dir === '.agents/skills', 'Polytoken target_dir uses the shared project-local skills path');
    assert(!polytokenInstaller?.global_target_dir, 'Polytoken does not claim an undocumented global skills path');

    tempProjectDir28b = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-polytoken-test-'));
    installedBmadDir28b = await createTestBmadFixture();

    const ideManager28b = new IdeManager();
    await ideManager28b.ensureInitialized();

    assert(
      ideManager28b.getAvailableIdes().some((ide) => ide.value === 'polytoken'),
      'Polytoken appears in available IDEs list',
    );

    const detectedBefore28b = await ideManager28b.detectInstalledIdes(tempProjectDir28b);
    assert(!detectedBefore28b.includes('polytoken'), 'Polytoken is not detected before install');

    const result28b = await ideManager28b.setup('polytoken', tempProjectDir28b, installedBmadDir28b, {
      silent: true,
      selectedModules: ['bmm'],
    });
    assert(result28b.success === true, 'Polytoken setup succeeds against temp project');

    const detectedAfter28b = await ideManager28b.detectInstalledIdes(tempProjectDir28b);
    assert(detectedAfter28b.includes('polytoken'), 'Polytoken is detected after install');

    const skillFile28b = path.join(tempProjectDir28b, '.agents', 'skills', 'bmad-master', 'SKILL.md');
    assert(await fs.pathExists(skillFile28b), 'Polytoken install writes SKILL.md directory output');

    const skillContent28b = await fs.readFile(skillFile28b, 'utf8');
    const frontmatter28b = skillContent28b.match(/^---\n([\s\S]*?)\n---\n?/);
    assert(frontmatter28b, 'Polytoken SKILL.md contains valid frontmatter delimiters');
    assert(/^description:\s*\S.+$/m.test(frontmatter28b?.[1] || ''), 'Polytoken skill has a non-empty description');
    assert(skillContent28b.includes('agent-activation'), 'Polytoken skill preserves its activation instructions');

    const reinstall28b = await ideManager28b.setup('polytoken', tempProjectDir28b, installedBmadDir28b, {
      silent: true,
      selectedModules: ['bmm'],
    });
    assert(reinstall28b.success === true, 'Polytoken reinstall succeeds over existing skills');
  } catch (error) {
    assert(false, 'Polytoken native skills test succeeds', error.message);
  } finally {
    if (tempProjectDir28b) await fs.remove(tempProjectDir28b).catch(() => {});
    if (installedBmadDir28b) await fs.remove(path.dirname(installedBmadDir28b)).catch(() => {});
  }

  console.log('');

  // ============================================================
  // Suite 29: Unified Skill Scanner — collectSkills
  // ============================================================
  console.log(`${colors.yellow}Test Suite 29: Unified Skill Scanner${colors.reset}\n`);

  let tempFixture29;
  try {
    tempFixture29 = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-skill-scanner-'));

    // Create _config dir (required by manifest generator)
    await fs.ensureDir(path.join(tempFixture29, '_config'));

    // --- Skill at unusual path: core/custom-area/my-skill/ ---
    const skillDir29 = path.join(tempFixture29, 'core', 'custom-area', 'my-skill');
    await fs.ensureDir(skillDir29);
    await fs.writeFile(
      path.join(skillDir29, 'SKILL.md'),
      '---\nname: my-skill\ndescription: A skill at an unusual path\n---\n\nFollow the instructions in [workflow.md](workflow.md).\n',
    );
    await fs.writeFile(path.join(skillDir29, 'workflow.md'), '# My Custom Skill\n\nSkill body content\n');

    // --- Regular workflow dir: core/workflows/regular-wf/ (type: workflow) ---
    const wfDir29 = path.join(tempFixture29, 'core', 'workflows', 'regular-wf');
    await fs.ensureDir(wfDir29);
    await fs.writeFile(path.join(wfDir29, 'bmad-skill-manifest.yaml'), 'type: workflow\ncanonicalId: regular-wf\n');
    await fs.writeFile(
      path.join(wfDir29, 'workflow.md'),
      '---\nname: Regular Workflow\ndescription: A regular workflow not a skill\n---\n\nWorkflow body\n',
    );

    // --- Skill inside workflows/ dir: core/workflows/wf-skill/ ---
    const wfSkillDir29 = path.join(tempFixture29, 'core', 'workflows', 'wf-skill');
    await fs.ensureDir(wfSkillDir29);
    await fs.writeFile(
      path.join(wfSkillDir29, 'SKILL.md'),
      '---\nname: wf-skill\ndescription: A skill inside workflows dir\n---\n\nFollow the instructions in [workflow.md](workflow.md).\n',
    );
    await fs.writeFile(path.join(wfSkillDir29, 'workflow.md'), '# Workflow Skill\n\nSkill in workflows\n');

    // --- Skill inside tasks/ dir: core/tasks/task-skill/ ---
    const taskSkillDir29 = path.join(tempFixture29, 'core', 'tasks', 'task-skill');
    await fs.ensureDir(taskSkillDir29);
    await fs.writeFile(
      path.join(taskSkillDir29, 'SKILL.md'),
      '---\nname: task-skill\ndescription: A skill inside tasks dir\n---\n\nFollow the instructions in [workflow.md](workflow.md).\n',
    );
    await fs.writeFile(path.join(taskSkillDir29, 'workflow.md'), '# Task Skill\n\nSkill in tasks\n');

    // --- Native agent entrypoint inside agents/: core/agents/bmad-tea/ ---
    const nativeAgentDir29 = path.join(tempFixture29, 'core', 'agents', 'bmad-tea');
    await fs.ensureDir(nativeAgentDir29);
    await fs.writeFile(path.join(nativeAgentDir29, 'bmad-skill-manifest.yaml'), 'type: agent\ncanonicalId: bmad-tea\n');
    await fs.writeFile(
      path.join(nativeAgentDir29, 'SKILL.md'),
      '---\nname: bmad-tea\ndescription: Native agent entrypoint\n---\n\nPresent a capability menu.\n',
    );

    // Minimal agent so core module is detected
    await fs.ensureDir(path.join(tempFixture29, 'core', 'agents'));
    const minimalAgent29 = '<agent name="Test" title="T"><persona>p</persona></agent>';
    await fs.writeFile(path.join(tempFixture29, 'core', 'agents', 'test.md'), minimalAgent29);

    const generator29 = new ManifestGenerator();
    await generator29.generateManifests(tempFixture29, ['core'], [], { ides: [] });

    // Skill at unusual path should be in skills
    const skillEntry29 = generator29.skills.find((s) => s.canonicalId === 'my-skill');
    assert(skillEntry29 !== undefined, 'Skill at unusual path appears in skills[]');
    assert(skillEntry29 && skillEntry29.name === 'my-skill', 'Skill has correct name from frontmatter');
    assert(
      skillEntry29 && skillEntry29.path.includes('custom-area/my-skill/SKILL.md'),
      'Skill path includes relative path from module root',
    );

    // Skill in tasks/ dir should be in skills
    const taskSkillEntry29 = generator29.skills.find((s) => s.canonicalId === 'task-skill');
    assert(taskSkillEntry29 !== undefined, 'Skill in tasks/ dir appears in skills[]');

    // Native agent entrypoint should be installed as a verbatim skill.
    // (Agent roster is now sourced from module.yaml's `agents:` block, not
    // from per-skill bmad-skill-manifest.yaml sidecars, so this test no longer
    // verifies agents[] membership — see collectAgentsFromModuleYaml tests.)
    const nativeAgentEntry29 = generator29.skills.find((s) => s.canonicalId === 'bmad-tea');
    assert(nativeAgentEntry29 !== undefined, 'Native type:agent SKILL.md dir appears in skills[]');
    assert(
      nativeAgentEntry29 && nativeAgentEntry29.path.includes('agents/bmad-tea/SKILL.md'),
      'Native type:agent SKILL.md path points to the agent directory entrypoint',
    );

    // Regular type:workflow should NOT appear in skills[]
    const regularInSkills29 = generator29.skills.find((s) => s.canonicalId === 'regular-wf');
    assert(regularInSkills29 === undefined, 'Regular type:workflow does NOT appear in skills[]');

    // Skill inside workflows/ should be in skills[]
    const wfSkill29 = generator29.skills.find((s) => s.canonicalId === 'wf-skill');
    assert(wfSkill29 !== undefined, 'Skill in workflows/ dir appears in skills[]');

    // Test scanInstalledModules recognizes skill-only modules
    const skillOnlyModDir29 = path.join(tempFixture29, 'skill-only-mod');
    await fs.ensureDir(path.join(skillOnlyModDir29, 'deep', 'nested', 'my-skill'));
    await fs.writeFile(
      path.join(skillOnlyModDir29, 'deep', 'nested', 'my-skill', 'SKILL.md'),
      '---\nname: my-skill\ndescription: desc\n---\n\nFollow the instructions in [workflow.md](workflow.md).\n',
    );
    await fs.writeFile(path.join(skillOnlyModDir29, 'deep', 'nested', 'my-skill', 'workflow.md'), '# Nested Skill\n\nbody\n');

    const scannedModules29 = await generator29.scanInstalledModules(tempFixture29);
    assert(scannedModules29.includes('skill-only-mod'), 'scanInstalledModules recognizes skill-only module');

    // Test scanInstalledModules recognizes native-agent-only modules too
    const agentOnlyModDir29 = path.join(tempFixture29, 'agent-only-mod');
    await fs.ensureDir(path.join(agentOnlyModDir29, 'deep', 'nested', 'bmad-tea'));
    await fs.writeFile(path.join(agentOnlyModDir29, 'deep', 'nested', 'bmad-tea', 'bmad-skill-manifest.yaml'), 'type: agent\n');
    await fs.writeFile(
      path.join(agentOnlyModDir29, 'deep', 'nested', 'bmad-tea', 'SKILL.md'),
      '---\nname: bmad-tea\ndescription: desc\n---\n\nAgent menu.\n',
    );

    const rescannedModules29 = await generator29.scanInstalledModules(tempFixture29);
    assert(rescannedModules29.includes('agent-only-mod'), 'scanInstalledModules recognizes native-agent-only module');

    // Test scanInstalledModules recognizes multi-entry manifests keyed under SKILL.md
    const multiEntryModDir29 = path.join(tempFixture29, 'multi-entry-mod');
    await fs.ensureDir(path.join(multiEntryModDir29, 'deep', 'nested', 'bmad-tea'));
    await fs.writeFile(
      path.join(multiEntryModDir29, 'deep', 'nested', 'bmad-tea', 'bmad-skill-manifest.yaml'),
      'SKILL.md:\n  type: agent\n  canonicalId: bmad-tea\n',
    );
    await fs.writeFile(
      path.join(multiEntryModDir29, 'deep', 'nested', 'bmad-tea', 'SKILL.md'),
      '---\nname: bmad-tea\ndescription: desc\n---\n\nAgent menu.\n',
    );

    const rescannedModules29b = await generator29.scanInstalledModules(tempFixture29);
    assert(rescannedModules29b.includes('multi-entry-mod'), 'scanInstalledModules recognizes multi-entry native-agent module');

    // skill-manifest.csv should include the native agent entrypoint
    const skillManifestCsv29 = await fs.readFile(path.join(tempFixture29, '_config', 'skill-manifest.csv'), 'utf8');
    assert(skillManifestCsv29.includes('bmad-tea'), 'skill-manifest.csv includes native type:agent SKILL.md entrypoint');
  } catch (error) {
    assert(false, 'Unified skill scanner test succeeds', error.message);
  } finally {
    if (tempFixture29) await fs.remove(tempFixture29).catch(() => {});
  }

  console.log('');

  // ============================================================
  // Suite 30: parseSkillMd validation (negative cases)
  // ============================================================
  console.log(`${colors.yellow}Test Suite 30: parseSkillMd Validation${colors.reset}\n`);

  let tempFixture30;
  try {
    tempFixture30 = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-test-30-'));

    const generator30 = new ManifestGenerator();
    generator30.bmadFolderName = '_bmad';

    // Case 1: Missing SKILL.md entirely
    const noSkillDir = path.join(tempFixture30, 'no-skill-md');
    await fs.ensureDir(noSkillDir);
    const result1 = await generator30.parseSkillMd(path.join(noSkillDir, 'SKILL.md'), noSkillDir, 'no-skill-md');
    assert(result1 === null, 'parseSkillMd returns null when SKILL.md is missing');

    // Case 2: SKILL.md with no frontmatter
    const noFmDir = path.join(tempFixture30, 'no-frontmatter');
    await fs.ensureDir(noFmDir);
    await fs.writeFile(path.join(noFmDir, 'SKILL.md'), '# Just a heading\n\nNo frontmatter here.\n');
    const result2 = await generator30.parseSkillMd(path.join(noFmDir, 'SKILL.md'), noFmDir, 'no-frontmatter');
    assert(result2 === null, 'parseSkillMd returns null when SKILL.md has no frontmatter');

    // Case 3: SKILL.md missing description
    const noDescDir = path.join(tempFixture30, 'no-desc');
    await fs.ensureDir(noDescDir);
    await fs.writeFile(path.join(noDescDir, 'SKILL.md'), '---\nname: no-desc\n---\n\nBody.\n');
    const result3 = await generator30.parseSkillMd(path.join(noDescDir, 'SKILL.md'), noDescDir, 'no-desc');
    assert(result3 === null, 'parseSkillMd returns null when description is missing');

    // Case 4: SKILL.md missing name
    const noNameDir = path.join(tempFixture30, 'no-name');
    await fs.ensureDir(noNameDir);
    await fs.writeFile(path.join(noNameDir, 'SKILL.md'), '---\ndescription: has desc but no name\n---\n\nBody.\n');
    const result4 = await generator30.parseSkillMd(path.join(noNameDir, 'SKILL.md'), noNameDir, 'no-name');
    assert(result4 === null, 'parseSkillMd returns null when name is missing');

    // Case 5: Name mismatch
    const mismatchDir = path.join(tempFixture30, 'actual-dir-name');
    await fs.ensureDir(mismatchDir);
    await fs.writeFile(path.join(mismatchDir, 'SKILL.md'), '---\nname: wrong-name\ndescription: A skill\n---\n\nBody.\n');
    const result5 = await generator30.parseSkillMd(path.join(mismatchDir, 'SKILL.md'), mismatchDir, 'actual-dir-name');
    assert(result5 === null, 'parseSkillMd returns null when name does not match directory name');

    // Case 6: Valid SKILL.md (positive control)
    const validDir = path.join(tempFixture30, 'valid-skill');
    await fs.ensureDir(validDir);
    await fs.writeFile(path.join(validDir, 'SKILL.md'), '---\nname: valid-skill\ndescription: A valid skill\n---\n\nBody.\n');
    const result6 = await generator30.parseSkillMd(path.join(validDir, 'SKILL.md'), validDir, 'valid-skill');
    assert(result6 !== null && result6.name === 'valid-skill', 'parseSkillMd returns metadata for valid SKILL.md');

    // Case 7: Malformed YAML (non-object)
    const malformedDir = path.join(tempFixture30, 'malformed');
    await fs.ensureDir(malformedDir);
    await fs.writeFile(path.join(malformedDir, 'SKILL.md'), '---\njust a string\n---\n\nBody.\n');
    const result7 = await generator30.parseSkillMd(path.join(malformedDir, 'SKILL.md'), malformedDir, 'malformed');
    assert(result7 === null, 'parseSkillMd returns null for non-object YAML frontmatter');
  } catch (error) {
    assert(false, 'parseSkillMd validation test succeeds', error.message);
  } finally {
    if (tempFixture30) await fs.remove(tempFixture30).catch(() => {});
  }

  console.log('');

  // ============================================================
  // Test 31: Skill-format installs report unique skill directories
  // ============================================================
  console.log(`${colors.yellow}Test Suite 31: Skill Count Reporting${colors.reset}\n`);

  let collisionFixtureRoot = null;
  let collisionProjectDir = null;

  try {
    clearCache();
    const collisionFixture = await createSkillCollisionFixture();
    collisionFixtureRoot = collisionFixture.root;
    collisionProjectDir = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-antigravity-test-'));

    const ideManager = new IdeManager();
    await ideManager.ensureInitialized();
    const result = await ideManager.setup('antigravity', collisionProjectDir, collisionFixture.bmadDir, {
      silent: true,
      selectedModules: ['core'],
    });

    assert(result.success === true, 'Antigravity setup succeeds with overlapping skill names');
    assert(result.detail === '1 skills → .agent/skills', 'Installer detail reports skill count and target dir');
    assert(result.handlerResult.results.skillDirectories === 1, 'Result exposes unique skill directory count');
    assert(result.handlerResult.results.skills === 1, 'Result retains verbatim skill count');
    assert(
      await fs.pathExists(path.join(collisionProjectDir, '.agent', 'skills', 'bmad-help', 'SKILL.md')),
      'Skill directory is created from skill-manifest',
    );
  } catch (error) {
    assert(false, 'Skill-format unique count test succeeds', error.message);
  } finally {
    if (collisionProjectDir) await fs.remove(collisionProjectDir).catch(() => {});
    if (collisionFixtureRoot) await fs.remove(collisionFixtureRoot).catch(() => {});
  }

  console.log('');

  // ============================================================
  // Suite 32: Ona Native Skills
  // ============================================================
  console.log(`${colors.yellow}Test Suite 32: Ona Native Skills${colors.reset}\n`);

  let tempProjectDir32;
  let installedBmadDir32;
  try {
    clearCache();
    const platformCodes32 = await loadPlatformCodes();
    const onaInstaller = platformCodes32.platforms.ona?.installer;

    assert(onaInstaller?.target_dir === '.ona/skills', 'Ona target_dir uses native skills path');

    tempProjectDir32 = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-ona-test-'));
    installedBmadDir32 = await createTestBmadFixture();

    const ideManager32 = new IdeManager();
    await ideManager32.ensureInitialized();

    // Verify Ona is selectable in available IDEs list
    const availableIdes32 = ideManager32.getAvailableIdes();
    assert(
      availableIdes32.some((ide) => ide.value === 'ona'),
      'Ona appears in available IDEs list',
    );

    // Verify Ona is NOT detected before install
    const detectedBefore32 = await ideManager32.detectInstalledIdes(tempProjectDir32);
    assert(!detectedBefore32.includes('ona'), 'Ona is not detected before install');

    const result32 = await ideManager32.setup('ona', tempProjectDir32, installedBmadDir32, {
      silent: true,
      selectedModules: ['bmm'],
    });

    assert(result32.success === true, 'Ona setup succeeds against temp project');

    // Verify Ona IS detected after install
    const detectedAfter32 = await ideManager32.detectInstalledIdes(tempProjectDir32);
    assert(detectedAfter32.includes('ona'), 'Ona is detected after install');

    const skillFile32 = path.join(tempProjectDir32, '.ona', 'skills', 'bmad-master', 'SKILL.md');
    assert(await fs.pathExists(skillFile32), 'Ona install writes SKILL.md directory output');

    const workflowFile32 = path.join(tempProjectDir32, '.ona', 'skills', 'bmad-master', 'workflow.md');
    assert(await fs.pathExists(workflowFile32), 'Ona install copies non-SKILL.md files (workflow.md) verbatim');

    // Parse YAML frontmatter between --- markers
    const skillContent32 = await fs.readFile(skillFile32, 'utf8');
    const fmMatch32 = skillContent32.match(/^---\n([\s\S]*?)\n---\n?([\s\S]*)$/);
    assert(fmMatch32, 'Ona SKILL.md contains valid frontmatter delimiters');

    const frontmatter32 = fmMatch32[1];
    const body32 = fmMatch32[2];

    // Verify name in frontmatter matches directory name
    const fmName32 = frontmatter32.match(/^name:\s*(.+)$/m);
    assert(fmName32 && fmName32[1].trim() === 'bmad-master', 'Ona skill name frontmatter matches directory name exactly');

    // Verify description exists and is non-empty
    const fmDesc32 = frontmatter32.match(/^description:\s*(.+)$/m);
    assert(fmDesc32 && fmDesc32[1].trim().length > 0, 'Ona skill description frontmatter is present and non-empty');

    // Verify frontmatter contains only name and description keys
    const fmKeys32 = [...frontmatter32.matchAll(/^([a-zA-Z0-9_-]+):/gm)].map((m) => m[1]);
    assert(
      fmKeys32.length === 2 && fmKeys32.includes('name') && fmKeys32.includes('description'),
      'Ona skill frontmatter contains only name and description keys',
    );

    // Verify body content is non-empty and contains expected activation instructions
    assert(body32.trim().length > 0, 'Ona skill body content is non-empty');
    assert(body32.includes('agent-activation'), 'Ona skill body contains expected agent activation instructions');

    // Reinstall/upgrade: run setup again over existing output
    const result32b = await ideManager32.setup('ona', tempProjectDir32, installedBmadDir32, {
      silent: true,
      selectedModules: ['bmm'],
    });
    assert(result32b.success === true, 'Ona reinstall/upgrade succeeds over existing skills');
    assert(await fs.pathExists(skillFile32), 'Ona reinstall preserves SKILL.md output');
  } catch (error) {
    assert(false, 'Ona native skills test succeeds', error.message);
  } finally {
    if (tempProjectDir32) await fs.remove(tempProjectDir32).catch(() => {});
    if (installedBmadDir32) await fs.remove(path.dirname(installedBmadDir32)).catch(() => {});
  }

  console.log('');

  // ============================================================
  // Test Suite 33: Custom Module Managers
  // ============================================================
  console.log(`${colors.yellow}Test Suite 33: Custom Module Managers${colors.reset}\n`);

  // --- CustomModuleManager._normalizeCustomModule ---
  {
    const { CustomModuleManager } = require('../tools/installer/modules/custom-module-manager');
    const mgr = new CustomModuleManager();

    const plugin = { name: 'test-plugin', description: 'A test', version: '1.0.0', author: 'tester', source: './src' };
    const data = { owner: 'Fallback Owner' };
    const result = mgr._normalizeCustomModule(plugin, 'https://github.com/o/r', data);

    assert(result.code === 'test-plugin', 'normalizeCustomModule sets code from plugin name');
    assert(result.type === 'custom', 'normalizeCustomModule sets type to custom');
    assert(result.trustTier === 'unverified', 'normalizeCustomModule sets trustTier to unverified');
    assert(result.version === '1.0.0', 'normalizeCustomModule preserves version');
    assert(result.author === 'tester', 'normalizeCustomModule uses plugin author over data.owner');

    const pluginNoAuthor = { name: 'x', description: '', version: null };
    const result2 = mgr._normalizeCustomModule(pluginNoAuthor, 'https://github.com/o/r', data);
    assert(result2.author === 'Fallback Owner', 'normalizeCustomModule falls back to data.owner');
  }

  console.log('');

  // ============================================================
  // Test Suite 35: Central Config Emission
  // ============================================================
  console.log(`${colors.yellow}Test Suite 35: Central Config Emission${colors.reset}\n`);

  {
    // Use the real src/ tree (core-skills + bmm-skills module.yaml are read via
    // getModulePath). Only the destination bmadDir is a temp dir, which the
    // installer writes config.toml / config.user.toml / custom/ into.
    const tempBmadDir35 = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-central-config-'));

    try {
      const moduleConfigs = {
        core: {
          user_name: 'TestUser',
          project_name: 'demo-project',
          communication_language: 'Spanish',
          document_output_language: 'English',
          output_folder: '_bmad-output',
        },
        bmm: {
          user_skill_level: 'expert',
          planning_artifacts: '{project-root}/_bmad-output/planning-artifacts',
          implementation_artifacts: '{project-root}/_bmad-output/implementation-artifacts',
          project_knowledge: '{project-root}/docs',
          // Spread-from-core pollution: legacy per-module config.yaml merges
          // core values into every module; writeCentralConfig must strip these
          // from [modules.bmm] so core values only live in [core].
          // project_name is now a core key (#2279), so it joins user_name etc.
          // as a spread-from-core key that must be stripped.
          user_name: 'TestUser',
          project_name: 'stale-bmm-copy',
          communication_language: 'Spanish',
          document_output_language: 'English',
          output_folder: '_bmad-output',
        },
        'external-mod': {
          // No src/modules/external-mod/module.yaml exists; installer treats
          // this as unknown-schema and falls through. Core-key stripping still
          // applies, so user_name/language must NOT appear under this module.
          custom_setting: 'external-value',
          another_setting: 'another-value',
          user_name: 'TestUser',
          communication_language: 'Spanish',
        },
      };

      const generator35 = new ManifestGenerator();
      generator35.bmadDir = tempBmadDir35;
      generator35.bmadFolderName = path.basename(tempBmadDir35);
      generator35.updatedModules = ['core', 'bmm', 'external-mod'];

      // collectAgentsFromModuleYaml reads from src/bmm-skills/module.yaml
      await generator35.collectAgentsFromModuleYaml();
      assert(generator35.agents.length >= 5, 'collectAgentsFromModuleYaml discovers bmm agents from module.yaml (>= 5 agents)');

      const maryEntry = generator35.agents.find((a) => a.code === 'bmad-agent-analyst');
      assert(maryEntry !== undefined, 'collectAgentsFromModuleYaml includes bmad-agent-analyst');
      assert(maryEntry && maryEntry.name === 'Mary', 'Agent entry carries name field');
      assert(maryEntry && maryEntry.title === 'Business Analyst', 'Agent entry carries title field');
      assert(maryEntry && maryEntry.icon === '📊', 'Agent entry carries icon field');
      assert(maryEntry && maryEntry.description.length > 0, 'Agent entry carries description field');
      assert(maryEntry && maryEntry.module === 'bmm', 'Agent entry module derives from owning module');
      assert(maryEntry && maryEntry.team === 'software-development', 'Agent entry carries explicit team from module.yaml');

      // writeCentralConfig produces the two root files
      const [teamPath, userPath] = await generator35.writeCentralConfig(tempBmadDir35, moduleConfigs);
      assert(teamPath === path.join(tempBmadDir35, 'config.toml'), 'writeCentralConfig returns team config path');
      assert(userPath === path.join(tempBmadDir35, 'config.user.toml'), 'writeCentralConfig returns user config path');
      assert(await fs.pathExists(teamPath), 'config.toml is written to disk');
      assert(await fs.pathExists(userPath), 'config.user.toml is written to disk');

      const teamContent = await fs.readFile(teamPath, 'utf8');
      const userContent = await fs.readFile(userPath, 'utf8');

      // [core] — team-scoped keys land in config.toml
      assert(teamContent.includes('[core]'), 'config.toml has [core] section');
      assert(teamContent.includes('document_output_language = "English"'), 'Team-scope core key lands in config.toml');
      assert(teamContent.includes('output_folder = "_bmad-output"'), 'Team-scope output_folder lands in config.toml');
      assert(teamContent.includes('project_name = "demo-project"'), 'project_name lands in [core] (core key as of #2279)');
      assert(teamContent.includes('user_name = "BMad"'), 'user_name (scope: user) gets its module.yaml default in config.toml');
      assert(
        teamContent.includes('communication_language = "English"'),
        'communication_language (scope: user) gets its module.yaml default in config.toml',
      );
      assert(!teamContent.includes('TestUser'), 'user_name answer stays out of config.toml');
      assert(!teamContent.includes('Spanish'), 'communication_language answer stays out of config.toml');

      // [core] — user-scoped keys land in config.user.toml
      assert(userContent.includes('[core]'), 'config.user.toml has [core] section');
      assert(userContent.includes('user_name = "TestUser"'), 'user_name lands in config.user.toml');
      assert(userContent.includes('communication_language = "Spanish"'), 'communication_language lands in config.user.toml');
      assert(!userContent.includes('document_output_language'), 'Team-scope key is absent from config.user.toml');

      // [modules.bmm] — core-key pollution stripped; own user-scope key routed to user file
      const bmmTeamMatch = teamContent.match(/\[modules\.bmm\][\s\S]*?(?=\n\[|$)/);
      assert(bmmTeamMatch !== null, 'config.toml has [modules.bmm] section');
      if (bmmTeamMatch) {
        const bmmTeamBlock = bmmTeamMatch[0];
        assert(bmmTeamBlock.includes('planning_artifacts'), 'bmm-owned team-scope key (planning_artifacts) lands under [modules.bmm]');
        assert(!bmmTeamBlock.includes('project_name'), 'project_name stripped from [modules.bmm] (now a core key, #2279)');
        assert(!bmmTeamBlock.includes('stale-bmm-copy'), 'stale bmm-copy of project_name not leaked into config.toml');
        assert(!bmmTeamBlock.includes('user_name'), 'user_name stripped from [modules.bmm] (core-key pollution)');
        assert(!bmmTeamBlock.includes('communication_language'), 'communication_language stripped from [modules.bmm]');
        assert(
          bmmTeamBlock.includes('user_skill_level = "intermediate"'),
          'user_skill_level (scope: user) gets its module.yaml default under [modules.bmm] in config.toml',
        );
      }

      const bmmUserMatch = userContent.match(/\[modules\.bmm\][\s\S]*?(?=\n\[|$)/);
      assert(bmmUserMatch !== null, 'config.user.toml has [modules.bmm] section');
      if (bmmUserMatch) {
        assert(bmmUserMatch[0].includes('user_skill_level = "expert"'), 'user_skill_level lands in config.user.toml [modules.bmm]');
      }

      // [modules.external-mod] — unknown schema, falls through as team; core keys still stripped
      const extMatch = teamContent.match(/\[modules\.external-mod\][\s\S]*?(?=\n\[|$)/);
      assert(extMatch !== null, 'Unknown-schema module survives with its own [modules.*] section');
      if (extMatch) {
        const extBlock = extMatch[0];
        assert(extBlock.includes('custom_setting = "external-value"'), 'Unknown-schema module retains its own keys');
        assert(!extBlock.includes('user_name'), 'Core-key pollution stripped from unknown-schema module too');
        assert(!extBlock.includes('communication_language'), 'All core-key pollution stripped from unknown-schema module');
      }

      // [agents.*] — agent roster from bmm module.yaml baked into config.toml (team-only)
      assert(teamContent.includes('[agents.bmad-agent-analyst]'), 'config.toml has [agents.bmad-agent-analyst] table');
      assert(teamContent.includes('[agents.bmad-agent-dev]'), 'config.toml has [agents.bmad-agent-dev] table');
      assert(teamContent.includes('module = "bmm"'), 'Agent entry serializes module field');
      assert(teamContent.includes('team = "software-development"'), 'Agent entry serializes team field');
      assert(teamContent.includes('name = "Mary"'), 'Agent entry serializes name');
      assert(teamContent.includes('icon = "📊"'), 'Agent entry serializes icon');
      assert(!userContent.includes('[agents.'), '[agents.*] tables are never written to config.user.toml');

      // Header comments present on both files
      assert(teamContent.includes('Installer-managed. Regenerated on every install'), 'config.toml has installer-managed header');
      assert(userContent.includes('Holds install answers scoped to YOU personally.'), 'config.user.toml header clarifies user scope');
    } finally {
      await fs.remove(tempBmadDir35).catch(() => {});
    }
  }

  console.log('');

  // ============================================================
  // Test Suite 36: Custom Config Stubs
  // ============================================================
  console.log(`${colors.yellow}Test Suite 36: Custom Config Stubs${colors.reset}\n`);

  {
    const tempBmadDir36 = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-custom-stubs-'));

    try {
      const generator36 = new ManifestGenerator();

      // First install: both stubs are created
      await generator36.ensureCustomConfigStubs(tempBmadDir36);

      const teamStub = path.join(tempBmadDir36, 'custom', 'config.toml');
      const userStub = path.join(tempBmadDir36, 'custom', 'config.user.toml');

      assert(await fs.pathExists(teamStub), 'ensureCustomConfigStubs creates custom/config.toml');
      assert(await fs.pathExists(userStub), 'ensureCustomConfigStubs creates custom/config.user.toml');

      // User writes content into the stub
      const userEdit = '# User edit\n[agents.kirk]\ndescription = "Enterprise captain"\n';
      await fs.writeFile(userStub, userEdit);

      // Second install: stubs are NOT overwritten
      await generator36.ensureCustomConfigStubs(tempBmadDir36);

      const preservedContent = await fs.readFile(userStub, 'utf8');
      assert(preservedContent === userEdit, 'ensureCustomConfigStubs does not overwrite user-edited custom/config.user.toml');
    } finally {
      await fs.remove(tempBmadDir36).catch(() => {});
    }
  }

  console.log('');

  // ============================================================
  // Test Suite 37: Agent Preservation for Non-Contributing Modules
  // ============================================================
  console.log(`${colors.yellow}Test Suite 37: Agent Preservation for Non-Contributing Modules${colors.reset}\n`);

  {
    // Scenario: quickUpdate preserves a module whose source isn't available
    // (e.g. external/marketplace). Its module.yaml isn't read, so its agents
    // aren't in this.agents. writeCentralConfig must read the prior config.toml
    // and keep those [agents.*] blocks so the roster doesn't silently shrink.
    const tempBmadDir37 = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-agent-preserve-'));

    try {
      // Seed a prior config.toml with an agent from an external module
      const priorToml = [
        '# prior',
        '',
        '[agents.bmad-agent-analyst]',
        'module = "bmm"',
        'team = "bmm"',
        'name = "Stale Mary"',
        '',
        '[agents.external-hero]',
        'module = "external-mod"',
        'team = "external-mod"',
        'name = "Hero"',
        'title = "External Agent"',
        'icon = "🦸"',
        'description = "Ships with the marketplace module."',
        '',
      ].join('\n');
      await fs.writeFile(path.join(tempBmadDir37, 'config.toml'), priorToml);

      const generator37 = new ManifestGenerator();
      generator37.bmadDir = tempBmadDir37;
      generator37.bmadFolderName = path.basename(tempBmadDir37);
      generator37.updatedModules = ['core', 'bmm', 'external-mod'];

      // bmm source is available; external-mod is not — it's a preserved module
      await generator37.collectAgentsFromModuleYaml();
      const freshModules = new Set(generator37.agents.map((a) => a.module));
      assert(freshModules.has('bmm'), 'bmm contributes fresh agents from src module.yaml');
      assert(!freshModules.has('external-mod'), 'external-mod source is unavailable (preserved-module scenario)');

      await generator37.writeCentralConfig(tempBmadDir37, { core: {}, bmm: {}, 'external-mod': {} });

      const teamContent = await fs.readFile(path.join(tempBmadDir37, 'config.toml'), 'utf8');

      assert(
        teamContent.includes('[agents.external-hero]'),
        'Preserved [agents.external-hero] block survives rewrite even though external-mod source was unavailable',
      );
      assert(teamContent.includes('Ships with the marketplace module.'), 'Preserved block keeps its original description');
      assert(teamContent.includes('module = "external-mod"'), 'Preserved block keeps its module field');

      // Freshly collected agents win over stale entries with the same code
      const maryMatches = teamContent.match(/\[agents\.bmad-agent-analyst\]/g) || [];
      assert(maryMatches.length === 1, 'bmad-agent-analyst emitted exactly once (fresh wins; stale not duplicated)');
      assert(!teamContent.includes('Stale Mary'), 'Stale name from prior config.toml is discarded when fresh module.yaml is read');
    } finally {
      await fs.remove(tempBmadDir37).catch(() => {});
    }
  }

  console.log('');

  // ============================================================
  // Test Suite 38: External-Module Agent Resolution
  // ============================================================
  console.log(`${colors.yellow}Test Suite 38: External-Module Agent Resolution${colors.reset}\n`);

  {
    // Scenario: external official modules (bmb, cis, gds, ...) are cloned into
    // ~/.bmad/cache/external-modules/<name>/ — NOT copied into src/modules/.
    // collectAgentsFromModuleYaml must resolve them from the cache or their
    // agent roster silently vanishes from config.toml.
    const tempCacheDir38 = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-ext-cache-'));
    const tempBmadDir38 = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-ext-install-'));
    const priorCacheEnv = process.env.BMAD_EXTERNAL_MODULES_CACHE;
    process.env.BMAD_EXTERNAL_MODULES_CACHE = tempCacheDir38;

    try {
      // Seed a fake external module with agents at cache/<mod>/src/module.yaml —
      // matches the real CIS layout.
      const extSrcDir = path.join(tempCacheDir38, 'fake-ext', 'src');
      await fs.ensureDir(extSrcDir);
      await fs.writeFile(
        path.join(extSrcDir, 'module.yaml'),
        [
          'code: fake-ext',
          'name: "Fake External Module"',
          'agents:',
          '  - code: bmad-fake-ext-agent-one',
          '    name: Ext-One',
          '    title: External Agent One',
          '    icon: "🧪"',
          '    team: fake',
          '    description: "First fake external agent."',
          '  - code: bmad-fake-ext-agent-two',
          '    name: Ext-Two',
          '    title: External Agent Two',
          '    icon: "🧬"',
          '    team: fake',
          '    description: "Second fake external agent."',
          '',
        ].join('\n'),
      );

      // Second fake module at cache/<mod>/skills/module.yaml — matches bmb layout.
      const extSkillsDir = path.join(tempCacheDir38, 'fake-skills', 'skills');
      await fs.ensureDir(extSkillsDir);
      await fs.writeFile(
        path.join(extSkillsDir, 'module.yaml'),
        [
          'code: fake-skills',
          'name: "Fake Skills-Layout Module"',
          'agents:',
          '  - code: bmad-fake-skills-agent',
          '    name: SkillsHero',
          '    title: Skills Layout Agent',
          '    icon: "🛠️"',
          '    team: fake-skills',
          '    description: "Lives under skills/ not src/."',
          '',
        ].join('\n'),
      );

      const generator38 = new ManifestGenerator();
      generator38.bmadDir = tempBmadDir38;
      generator38.bmadFolderName = path.basename(tempBmadDir38);
      generator38.updatedModules = ['core', 'bmm', 'fake-ext', 'fake-skills'];

      await generator38.collectAgentsFromModuleYaml();

      const byCode = new Map(generator38.agents.map((a) => [a.code, a]));
      assert(byCode.has('bmad-fake-ext-agent-one'), 'external module at cache/<name>/src resolves and contributes agent one');
      assert(byCode.has('bmad-fake-ext-agent-two'), 'external module at cache/<name>/src resolves and contributes agent two');
      assert(byCode.has('bmad-fake-skills-agent'), 'external module at cache/<name>/skills layout also resolves');
      assert(byCode.get('bmad-fake-ext-agent-one').module === 'fake-ext', 'agent.module matches the owning external module name');
      assert(byCode.get('bmad-fake-ext-agent-one').team === 'fake', 'explicit team from module.yaml is preserved');

      await generator38.writeCentralConfig(tempBmadDir38, {
        core: {},
        bmm: {},
        'fake-ext': {},
        'fake-skills': {},
      });

      const teamContent = await fs.readFile(path.join(tempBmadDir38, 'config.toml'), 'utf8');
      assert(teamContent.includes('[agents.bmad-fake-ext-agent-one]'), 'external-module agents land in config.toml [agents.*] section');
      assert(teamContent.includes('[agents.bmad-fake-skills-agent]'), 'skills-layout external module agents also land in config.toml');
      assert(teamContent.includes('First fake external agent.'), 'agent description from external module.yaml is written');
    } finally {
      if (priorCacheEnv === undefined) {
        delete process.env.BMAD_EXTERNAL_MODULES_CACHE;
      } else {
        process.env.BMAD_EXTERNAL_MODULES_CACHE = priorCacheEnv;
      }
      await fs.remove(tempCacheDir38).catch(() => {});
      await fs.remove(tempBmadDir38).catch(() => {});
    }
  }

  console.log('');

  // ============================================================
  // Test Suite 39: Module Version Resolution
  // ============================================================
  console.log(`${colors.yellow}Test Suite 39: Module Version Resolution${colors.reset}\n`);

  // --- package.json beats module.yaml and marketplace.json for cached external modules ---
  {
    const { resolveModuleVersion } = require('../tools/installer/modules/version-resolver');
    const tempCacheDir39 = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-version-cache-'));
    const priorCacheEnv39 = process.env.BMAD_EXTERNAL_MODULES_CACHE;
    process.env.BMAD_EXTERNAL_MODULES_CACHE = tempCacheDir39;

    try {
      const moduleRoot = path.join(tempCacheDir39, 'tea');
      const moduleSrc = path.join(moduleRoot, 'src');
      await fs.ensureDir(path.join(moduleRoot, '.claude-plugin'));
      await fs.ensureDir(moduleSrc);

      await fs.writeFile(
        path.join(moduleRoot, 'package.json'),
        JSON.stringify({ name: 'bmad-method-test-architecture-enterprise', version: '1.12.3' }, null, 2) + '\n',
      );
      await fs.writeFile(
        path.join(moduleSrc, 'module.yaml'),
        ['code: tea', 'name: Test Architect', 'module_version: 1.11.0', ''].join('\n'),
      );
      await fs.writeFile(
        path.join(moduleRoot, '.claude-plugin', 'marketplace.json'),
        JSON.stringify({ plugins: [{ name: 'tea', version: '1.7.2' }] }, null, 2) + '\n',
      );

      const versionInfo = await resolveModuleVersion('tea');
      assert(versionInfo.version === '1.12.3', 'resolver prefers cached package.json over stale marketplace metadata for external modules');
      assert(versionInfo.source === 'package.json', 'resolver reports package.json as the winning metadata source');
    } finally {
      if (priorCacheEnv39 === undefined) {
        delete process.env.BMAD_EXTERNAL_MODULES_CACHE;
      } else {
        process.env.BMAD_EXTERNAL_MODULES_CACHE = priorCacheEnv39;
      }
      await fs.remove(tempCacheDir39).catch(() => {});
    }
  }

  // --- module.yaml is used when package.json is absent ---
  {
    const { resolveModuleVersion } = require('../tools/installer/modules/version-resolver');
    const tempRepo39 = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-version-module-yaml-'));
    const tempCacheDir39 = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-version-module-yaml-cache-'));
    const priorCacheEnv39 = process.env.BMAD_EXTERNAL_MODULES_CACHE;
    process.env.BMAD_EXTERNAL_MODULES_CACHE = tempCacheDir39;

    try {
      const moduleDir = path.join(tempRepo39, 'src');
      await fs.ensureDir(path.join(tempRepo39, '.claude-plugin'));
      await fs.ensureDir(moduleDir);

      await fs.writeFile(path.join(moduleDir, 'module.yaml'), ['code: sample-mod', 'module_version: 2.4.0', ''].join('\n'));
      await fs.writeFile(
        path.join(tempRepo39, '.claude-plugin', 'marketplace.json'),
        JSON.stringify({ plugins: [{ name: 'sample-mod', version: '1.7.2' }] }, null, 2) + '\n',
      );

      const versionInfo = await resolveModuleVersion('sample-mod', { moduleSourcePath: moduleDir });
      assert(versionInfo.version === '2.4.0', 'resolver falls back to module.yaml when package.json is missing');
      assert(versionInfo.source === 'module.yaml', 'resolver reports module.yaml when it provides the selected version');
    } finally {
      if (priorCacheEnv39 === undefined) {
        delete process.env.BMAD_EXTERNAL_MODULES_CACHE;
      } else {
        process.env.BMAD_EXTERNAL_MODULES_CACHE = priorCacheEnv39;
      }
      await fs.remove(tempRepo39).catch(() => {});
      await fs.remove(tempCacheDir39).catch(() => {});
    }
  }

  // --- marketplace fallback uses semver-aware comparison ---
  {
    const { resolveModuleVersion } = require('../tools/installer/modules/version-resolver');
    const tempRepo39 = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-version-marketplace-'));
    const tempCacheDir39 = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-version-marketplace-cache-'));
    const priorCacheEnv39 = process.env.BMAD_EXTERNAL_MODULES_CACHE;
    process.env.BMAD_EXTERNAL_MODULES_CACHE = tempCacheDir39;

    try {
      const moduleDir = path.join(tempRepo39, 'src');
      await fs.ensureDir(path.join(tempRepo39, '.claude-plugin'));
      await fs.ensureDir(moduleDir);

      await fs.writeFile(
        path.join(tempRepo39, '.claude-plugin', 'marketplace.json'),
        JSON.stringify(
          {
            plugins: [
              { name: 'older-plugin', version: '1.7.2' },
              { name: 'newer-plugin', version: '1.12.3' },
            ],
          },
          null,
          2,
        ) + '\n',
      );

      const versionInfo = await resolveModuleVersion('missing-plugin', { moduleSourcePath: moduleDir });
      assert(
        versionInfo.version === '1.12.3',
        'resolver picks the highest marketplace fallback version using semver instead of string comparison',
      );
      assert(versionInfo.source === 'marketplace.json', 'resolver reports marketplace.json when it is the only usable metadata source');
    } finally {
      if (priorCacheEnv39 === undefined) {
        delete process.env.BMAD_EXTERNAL_MODULES_CACHE;
      } else {
        process.env.BMAD_EXTERNAL_MODULES_CACHE = priorCacheEnv39;
      }
      await fs.remove(tempRepo39).catch(() => {});
      await fs.remove(tempCacheDir39).catch(() => {});
    }
  }

  // --- package.json lookup must not escape the module repo boundary ---
  {
    const { resolveModuleVersion } = require('../tools/installer/modules/version-resolver');
    const tempHost39 = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-version-boundary-host-'));
    const tempCacheDir39 = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-version-boundary-cache-'));
    const priorCacheEnv39 = process.env.BMAD_EXTERNAL_MODULES_CACHE;
    process.env.BMAD_EXTERNAL_MODULES_CACHE = tempCacheDir39;

    try {
      const moduleRoot = path.join(tempHost39, 'nested-module');
      const moduleDir = path.join(moduleRoot, 'src');
      await fs.ensureDir(path.join(moduleRoot, '.claude-plugin'));
      await fs.ensureDir(moduleDir);

      await fs.writeFile(path.join(tempHost39, 'package.json'), JSON.stringify({ name: 'host-project', version: '9.9.9' }, null, 2) + '\n');
      await fs.writeFile(path.join(moduleDir, 'module.yaml'), ['code: sample-mod', 'module_version: 2.4.0', ''].join('\n'));
      await fs.writeFile(
        path.join(moduleRoot, '.claude-plugin', 'marketplace.json'),
        JSON.stringify({ plugins: [{ name: 'sample-mod', version: '1.7.2' }] }, null, 2) + '\n',
      );

      const versionInfo = await resolveModuleVersion('sample-mod', { moduleSourcePath: moduleDir });
      assert(versionInfo.version === '2.4.0', 'resolver does not read a host project package.json outside the module repo boundary');
      assert(versionInfo.source === 'module.yaml', 'resolver stops at the module repo boundary before climbing into host project metadata');
    } finally {
      if (priorCacheEnv39 === undefined) {
        delete process.env.BMAD_EXTERNAL_MODULES_CACHE;
      } else {
        process.env.BMAD_EXTERNAL_MODULES_CACHE = priorCacheEnv39;
      }
      await fs.remove(tempHost39).catch(() => {});
      await fs.remove(tempCacheDir39).catch(() => {});
    }
  }

  // --- Manifest uses the shared resolver for external modules ---
  {
    const { Manifest } = require('../tools/installer/core/manifest');
    const { ExternalModuleManager } = require('../tools/installer/modules/external-manager');
    const tempCacheDir39 = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-manifest-version-cache-'));
    const tempBmadDir39 = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-manifest-version-install-'));
    const priorCacheEnv39 = process.env.BMAD_EXTERNAL_MODULES_CACHE;
    const originalLoadConfig39 = ExternalModuleManager.prototype.loadExternalModulesConfig;
    process.env.BMAD_EXTERNAL_MODULES_CACHE = tempCacheDir39;

    ExternalModuleManager.prototype.loadExternalModulesConfig = async function () {
      return {
        modules: [
          {
            code: 'tea',
            name: 'Test Architect',
            repository: 'https://example.com/tea.git',
            module_definition: 'src/module.yaml',
            npm_package: 'bmad-method-test-architecture-enterprise',
          },
        ],
      };
    };

    try {
      const moduleRoot = path.join(tempCacheDir39, 'tea');
      const moduleSrc = path.join(moduleRoot, 'src');
      await fs.ensureDir(path.join(moduleRoot, '.claude-plugin'));
      await fs.ensureDir(moduleSrc);

      await fs.writeFile(
        path.join(moduleRoot, 'package.json'),
        JSON.stringify({ name: 'bmad-method-test-architecture-enterprise', version: '1.12.3' }, null, 2) + '\n',
      );
      await fs.writeFile(path.join(moduleSrc, 'module.yaml'), ['code: tea', 'module_version: 1.11.0', ''].join('\n'));
      await fs.writeFile(
        path.join(moduleRoot, '.claude-plugin', 'marketplace.json'),
        JSON.stringify({ plugins: [{ name: 'tea', version: '1.7.2' }] }, null, 2) + '\n',
      );

      const manifest39 = new Manifest();
      const versionInfo = await manifest39.getModuleVersionInfo('tea', tempBmadDir39, moduleSrc);

      assert(versionInfo.version === '1.12.3', 'manifest version info prefers external package.json over stale marketplace metadata');
      assert(versionInfo.source === 'external', 'manifest preserves external source classification while using the shared resolver');
      assert(
        versionInfo.npmPackage === 'bmad-method-test-architecture-enterprise',
        'manifest preserves npm package metadata for external modules',
      );
    } finally {
      ExternalModuleManager.prototype.loadExternalModulesConfig = originalLoadConfig39;
      if (priorCacheEnv39 === undefined) {
        delete process.env.BMAD_EXTERNAL_MODULES_CACHE;
      } else {
        process.env.BMAD_EXTERNAL_MODULES_CACHE = priorCacheEnv39;
      }
      await fs.remove(tempCacheDir39).catch(() => {});
      await fs.remove(tempBmadDir39).catch(() => {});
    }
  }

  // --- Update checks should not advertise npm downgrades when source installs are newer ---
  {
    const { Manifest } = require('../tools/installer/core/manifest');
    const manifest39 = new Manifest();
    const originalGetAllModuleVersions39 = manifest39.getAllModuleVersions.bind(manifest39);
    const originalFetchNpmVersion39 = manifest39.fetchNpmVersion.bind(manifest39);

    manifest39.getAllModuleVersions = async () => [
      {
        name: 'tea',
        version: '1.12.3',
        npmPackage: 'bmad-method-test-architecture-enterprise',
      },
    ];
    manifest39.fetchNpmVersion = async () => '1.7.2';

    try {
      const updates = await manifest39.checkForUpdates('/unused');
      assert(updates.length === 0, 'update check ignores older npm versions when installed source metadata is newer');
    } finally {
      manifest39.getAllModuleVersions = originalGetAllModuleVersions39;
      manifest39.fetchNpmVersion = originalFetchNpmVersion39;
    }
  }

  // --- Update checks ignore non-semver version strings instead of flagging false positives ---
  {
    const { Manifest } = require('../tools/installer/core/manifest');
    const manifest39 = new Manifest();
    const originalGetAllModuleVersions39 = manifest39.getAllModuleVersions.bind(manifest39);
    const originalFetchNpmVersion39 = manifest39.fetchNpmVersion.bind(manifest39);

    manifest39.getAllModuleVersions = async () => [
      {
        name: 'tea',
        version: 'workspace-build',
        npmPackage: 'bmad-method-test-architecture-enterprise',
      },
    ];
    manifest39.fetchNpmVersion = async () => 'latest-build';

    try {
      const updates = await manifest39.checkForUpdates('/unused');
      assert(updates.length === 0, 'update check ignores non-semver version strings instead of reporting misleading updates');
    } finally {
      manifest39.getAllModuleVersions = originalGetAllModuleVersions39;
      manifest39.fetchNpmVersion = originalFetchNpmVersion39;
    }
  }

  // --- Official module picker uses git tags for external module labels ---
  {
    const { UI } = require('../tools/installer/ui');
    const prompts = require('../tools/installer/prompts');
    const channelResolver = require('../tools/installer/modules/channel-resolver');
    const { ExternalModuleManager } = require('../tools/installer/modules/external-manager');

    const ui = new UI();
    const originalOfficialListAvailable39 = OfficialModules.prototype.listAvailable;
    const originalExternalListAvailable39 = ExternalModuleManager.prototype.listAvailable;
    const originalAutocomplete39 = prompts.autocompleteMultiselect;
    const originalSpinner39 = prompts.spinner;
    const originalWarn39 = prompts.log.warn;
    const originalMessage39 = prompts.log.message;
    const originalResolveChannel39 = channelResolver.resolveChannel;

    const seenLabels39 = [];
    const spinnerStarts39 = [];
    const spinnerStops39 = [];
    const warnings39 = [];

    OfficialModules.prototype.listAvailable = async function () {
      return {
        modules: [
          {
            id: 'core',
            name: 'BMad Core Module',
            description: 'always installed',
            defaultSelected: true,
          },
        ],
      };
    };

    ExternalModuleManager.prototype.listAvailable = async function () {
      return [
        {
          code: 'bmb',
          name: 'BMad Builder',
          description: 'Builder module',
          defaultSelected: false,
          builtIn: false,
          url: 'https://github.com/bmad-code-org/bmad-builder',
          defaultChannel: 'stable',
        },
        {
          code: 'tea',
          name: 'Test Architect',
          description: 'Test architecture module',
          defaultSelected: false,
          builtIn: false,
          url: 'https://github.com/bmad-code-org/bmad-method-test-architecture-enterprise',
          defaultChannel: 'stable',
        },
      ];
    };

    channelResolver.resolveChannel = async function ({ repoUrl, channel }) {
      if (channel !== 'stable') {
        return { channel, version: channel === 'next' ? 'main' : 'unknown' };
      }
      if (repoUrl.includes('bmad-builder')) {
        return { channel: 'stable', version: 'v1.7.0', ref: 'v1.7.0', resolvedFallback: false };
      }
      if (repoUrl.includes('bmad-method-test-architecture-enterprise')) {
        return { channel: 'stable', version: 'v1.15.0', ref: 'v1.15.0', resolvedFallback: false };
      }
      throw new Error(`unexpected repo ${repoUrl}`);
    };

    prompts.autocompleteMultiselect = async (options) => {
      seenLabels39.push(...options.options.map((opt) => opt.label));
      return ['core'];
    };
    prompts.spinner = async () => ({
      start(message) {
        spinnerStarts39.push(message);
      },
      stop(message) {
        spinnerStops39.push(message);
      },
      error(message) {
        spinnerStops39.push(`error:${message}`);
      },
    });
    prompts.log.warn = async (message) => {
      warnings39.push(message);
    };
    prompts.log.message = async () => {};

    try {
      await ui._selectOfficialModules(
        new Set(['bmb']),
        new Map([
          ['bmb', '1.1.0'],
          ['core', '6.2.0'],
        ]),
        { global: null, nextSet: new Set(), pins: new Map(), warnings: [] },
      );

      assert(
        seenLabels39.includes('BMad Builder (v1.1.0 → v1.7.0)'),
        'official module picker shows installed-to-latest arrow from git tags',
      );
      assert(seenLabels39.includes('Test Architect (v1.15.0)'), 'official module picker shows latest git-tag version for fresh installs');
      assert(
        spinnerStarts39.includes('Checking latest module versions...'),
        'official module picker wraps external lookups in a single spinner',
      );
      assert(spinnerStops39.includes('Checked latest module versions.'), 'official module picker stops the version-check spinner');
      assert(warnings39.length === 0, 'official module picker does not warn when tag lookups succeed');
    } finally {
      OfficialModules.prototype.listAvailable = originalOfficialListAvailable39;
      ExternalModuleManager.prototype.listAvailable = originalExternalListAvailable39;
      prompts.autocompleteMultiselect = originalAutocomplete39;
      prompts.spinner = originalSpinner39;
      prompts.log.warn = originalWarn39;
      prompts.log.message = originalMessage39;
      channelResolver.resolveChannel = originalResolveChannel39;
    }
  }

  // --- Channel pickers: a registry-pinned module skips the picker; unpinned modules still choose ---
  {
    const { UI } = require('../tools/installer/ui');
    const prompts = require('../tools/installer/prompts');
    const channelResolver = require('../tools/installer/modules/channel-resolver');
    const { ExternalModuleManager } = require('../tools/installer/modules/external-manager');
    const { Manifest } = require('../tools/installer/core/manifest');
    const { parseChannelOptions, decideChannelForModule } = require('../tools/installer/modules/channel-plan');

    const saved = {
      listAvailable: ExternalModuleManager.prototype.listAvailable,
      read: Manifest.prototype.read,
      confirm: prompts.confirm,
      select: prompts.select,
      info: prompts.log.info,
      fetchStableTags: channelResolver.fetchStableTags,
    };

    const TEA = {
      code: 'tea',
      name: 'Test Architect',
      builtIn: false,
      url: 'https://github.com/bmad-code-org/bmad-method-test-architecture-enterprise',
      defaultChannel: 'stable',
      pin: 'v1.27.2',
    };
    const BMB = {
      code: 'bmb',
      name: 'BMad Builder',
      builtIn: false,
      url: 'https://github.com/bmad-code-org/bmad-builder',
      defaultChannel: 'stable',
      pin: null,
    };
    ExternalModuleManager.prototype.listAvailable = async () => [TEA, BMB];
    channelResolver.fetchStableTags = async () => [{ tag: 'v3.0.0' }];

    let prompted = 0;
    const notices = [];
    const answer = ({ confirm, select }) => {
      prompted = 0;
      notices.length = 0;
      prompts.confirm = async () => {
        prompted++;
        return confirm;
      };
      prompts.select = async () => {
        prompted++;
        return select;
      };
      prompts.log.info = async (message) => {
        notices.push(message);
      };
    };
    const resolve = (module, channelOptions) =>
      decideChannelForModule({ code: module.code, channelOptions, registryDefault: 'stable', registryPin: module.pin });
    const installGate = async (selectedModules, answers, options = {}) => {
      const channelOptions = parseChannelOptions({});
      answer(answers);
      await new UI()._interactiveChannelGate({ options, channelOptions, selectedModules });
      return channelOptions;
    };
    const updateFlow = async (module, answers) => {
      const channelOptions = parseChannelOptions({});
      Manifest.prototype.read = async () => ({ modulesDetailed: [module] });
      answer(answers);
      await new UI()._resolveUpdateChannels({ bmadDir: '/unused', selectedModules: [module.name], channelOptions, yes: false });
      return channelOptions;
    };

    try {
      const pinnedOnly = await installGate(['tea'], { confirm: false, select: 'stable' });
      assert(prompted === 0, 'install picker: a registry-pinned module asks no channel question');
      assert(
        notices.length === 1 &&
          notices[0].includes('tea is pinned to v1.27.2') &&
          notices[0].includes('npx skills add bmad-code-org/bmad-method-test-architecture-enterprise'),
        'install picker: a registry-pinned module gets a notice with the v7 install command',
      );
      assert(resolve(TEA, pinnedOnly).pin === 'v1.27.2', 'install picker: the registry-pinned module installs at its pin');

      const mixed = await installGate(['tea', 'bmb'], { confirm: false, select: 'stable' });
      assert(mixed.stableSet.has('bmb') && !mixed.stableSet.has('tea'), 'install picker: an unpinned module still gets the channel choice');
      assert(resolve(TEA, mixed).channel === 'pinned', 'install picker: the pinned module stays pinned beside an unpinned one');

      const fastPath = await installGate(['bmb'], { confirm: true, select: 'unused' });
      assert(fastPath.stableSet.size === 0 && fastPath.nextSet.size === 0, 'install picker: the all-stable fast path records no choice');

      const reviewSkipped = await updateFlow({ name: 'tea', channel: 'pinned', version: 'v1.27.2' }, { confirm: true, select: 'stable' });
      assert(prompted === 0, 'update flow: a registry-pinned module is left out of the channel review');
      assert(resolve(TEA, reviewSkipped).channel === 'pinned', 'update flow: a registry-pinned module stays on its pin');

      const keptPin = await updateFlow({ name: 'tea', channel: 'pinned', version: 'v1.26.0' }, { confirm: true, select: 'stable' });
      assert(resolve(TEA, keptPin).pin === 'v1.26.0', 'update flow: a version the user pinned earlier is kept');
      assert(notices.length === 0, 'update flow: no pin notice when the user keeps their own pin');

      const noticed = await updateFlow({ name: 'tea', channel: 'stable', version: 'v1.20.0' }, { confirm: true, select: 'stable' });
      assert(resolve(TEA, noticed).pin === 'v1.27.2', 'update flow: a recorded stable install moves to the registry pin');
      assert(
        notices.length === 1 && notices[0].includes('tea is pinned to v1.27.2') && notices[0].includes('npx skills add'),
        'update flow: the pin notice explains the registry pin and the v7 install command',
      );

      const headless = await installGate(['tea'], { confirm: true, select: 'stable' }, { yes: true });
      assert(prompted === 0 && notices.length === 1, 'headless install: the pin notice prints and nothing is asked');
      assert(resolve(TEA, headless).pin === 'v1.27.2', 'headless install: the registry-pinned module installs at its pin');

      const legacyPinned = await updateFlow({ name: 'tea', channel: null, version: null }, { confirm: false, select: 'unused' });
      assert(resolve(TEA, legacyPinned).channel === 'pinned', 'update flow: a legacy registry-pinned install stays on its pin');

      const switched = await updateFlow({ name: 'bmb', channel: 'next', version: 'main' }, { confirm: true, select: 'stable' });
      assert(
        resolve(BMB, switched).channel === 'stable' && switched.stableSet.has('bmb'),
        'update picker: "Switch to stable" is recorded for an unpinned module',
      );

      const legacy = await updateFlow({ name: 'bmb', channel: null, version: null }, { confirm: false, select: 'unused' });
      assert(legacy.stableSet.has('bmb'), 'update flow: a legacy main-tracking install moves to stable');
    } finally {
      ExternalModuleManager.prototype.listAvailable = saved.listAvailable;
      Manifest.prototype.read = saved.read;
      prompts.confirm = saved.confirm;
      prompts.select = saved.select;
      prompts.log.info = saved.info;
      channelResolver.fetchStableTags = saved.fetchStableTags;
    }
  }

  // --- Official module picker warns and falls back to cached versions when tag lookups fail ---
  {
    const { UI } = require('../tools/installer/ui');
    const prompts = require('../tools/installer/prompts');
    const channelResolver = require('../tools/installer/modules/channel-resolver');
    const { ExternalModuleManager } = require('../tools/installer/modules/external-manager');

    const ui = new UI();
    const tempCacheDir39 = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-picker-cache-'));
    const priorCacheEnv39 = process.env.BMAD_EXTERNAL_MODULES_CACHE;
    const originalOfficialListAvailable39 = OfficialModules.prototype.listAvailable;
    const originalExternalListAvailable39 = ExternalModuleManager.prototype.listAvailable;
    const originalAutocomplete39 = prompts.autocompleteMultiselect;
    const originalSpinner39 = prompts.spinner;
    const originalWarn39 = prompts.log.warn;
    const originalMessage39 = prompts.log.message;
    const originalResolveChannel39 = channelResolver.resolveChannel;

    const seenLabels39 = [];
    const warnings39 = [];

    process.env.BMAD_EXTERNAL_MODULES_CACHE = tempCacheDir39;
    await fs.ensureDir(path.join(tempCacheDir39, 'bmb'));
    await fs.writeFile(
      path.join(tempCacheDir39, 'bmb', 'package.json'),
      JSON.stringify({ name: 'bmad-builder', version: '1.7.0' }, null, 2) + '\n',
    );

    OfficialModules.prototype.listAvailable = async function () {
      return {
        modules: [
          {
            id: 'core',
            name: 'BMad Core Module',
            description: 'always installed',
            defaultSelected: true,
          },
        ],
      };
    };

    ExternalModuleManager.prototype.listAvailable = async function () {
      return [
        {
          code: 'bmb',
          name: 'BMad Builder',
          description: 'Builder module',
          defaultSelected: false,
          builtIn: false,
          url: 'https://github.com/bmad-code-org/bmad-builder',
          defaultChannel: 'stable',
        },
      ];
    };

    channelResolver.resolveChannel = async function () {
      throw new Error('tag lookup unavailable');
    };

    prompts.autocompleteMultiselect = async (options) => {
      seenLabels39.push(...options.options.map((opt) => opt.label));
      return ['core'];
    };
    prompts.spinner = async () => ({
      start() {},
      stop() {},
      error() {},
    });
    prompts.log.warn = async (message) => {
      warnings39.push(message);
    };
    prompts.log.message = async () => {};

    try {
      await ui._selectOfficialModules(new Set(), new Map(), { global: null, nextSet: new Set(), pins: new Map(), warnings: [] });

      assert(
        seenLabels39.includes('BMad Builder (v1.7.0)'),
        'official module picker falls back to cached/local versions when tag lookup fails',
      );
      assert(
        warnings39.includes('Could not check latest module versions; showing cached/local versions.'),
        'official module picker warns once when all latest-version lookups fail',
      );
    } finally {
      OfficialModules.prototype.listAvailable = originalOfficialListAvailable39;
      ExternalModuleManager.prototype.listAvailable = originalExternalListAvailable39;
      prompts.autocompleteMultiselect = originalAutocomplete39;
      prompts.spinner = originalSpinner39;
      prompts.log.warn = originalWarn39;
      prompts.log.message = originalMessage39;
      channelResolver.resolveChannel = originalResolveChannel39;
      if (priorCacheEnv39 === undefined) {
        delete process.env.BMAD_EXTERNAL_MODULES_CACHE;
      } else {
        process.env.BMAD_EXTERNAL_MODULES_CACHE = priorCacheEnv39;
      }
      await fs.remove(tempCacheDir39).catch(() => {});
    }
  }

  console.log('');

  // ============================================================
  // Test Suite 40: Shared target_dir coordination
  // ============================================================
  console.log(`${colors.yellow}Test Suite 40: Shared target_dir coordination${colors.reset}\n`);

  try {
    // Cursor and Gemini both use .agents/skills — verify they coordinate.
    clearCache();
    const platformCodes40 = await loadPlatformCodes();
    const cursorTarget = platformCodes40.platforms.cursor?.installer?.target_dir;
    const geminiTarget = platformCodes40.platforms.gemini?.installer?.target_dir;
    assert(cursorTarget === '.agents/skills' && geminiTarget === '.agents/skills', 'Cursor and Gemini share .agents/skills target_dir');

    const tempProjectDir40 = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-shared-target-'));
    const installedBmadDir40 = await createTestBmadFixture();

    const ideManager40 = new IdeManager();
    await ideManager40.ensureInitialized();

    // Run setupBatch with both platforms — second should skip skill write.
    const batchResults = await ideManager40.setupBatch(['cursor', 'gemini'], tempProjectDir40, installedBmadDir40, {
      silent: true,
      selectedModules: ['core'],
    });

    assert(batchResults.length === 2, 'setupBatch returns one result per IDE');
    assert(batchResults[0].success === true, 'First platform (cursor) succeeds');
    assert(batchResults[1].success === true, 'Second platform (gemini) succeeds');
    assert(
      batchResults[1].handlerResult?.results?.sharedTargetHandledByPeer === true,
      'Second platform marked sharedTargetHandledByPeer (skipped redundant write)',
    );

    // Skill should be present in the shared dir after batch.
    const sharedDir = path.join(tempProjectDir40, '.agents', 'skills');
    const sharedDirEntries = await fs.readdir(sharedDir);
    assert(sharedDirEntries.includes('bmad-master'), 'Shared .agents/skills/ contains bmad-master after batched install');

    // Now uninstall just cursor while gemini remains. Skills must survive.
    const cleanupResults = await ideManager40.cleanupByList(tempProjectDir40, ['cursor'], {
      silent: true,
      remainingIdes: ['gemini'],
    });
    assert(cleanupResults[0].skippedTarget === true, 'Cursor cleanup skips target_dir wipe when Gemini remains');
    const stillThere = await fs.readdir(sharedDir);
    assert(stillThere.includes('bmad-master'), 'bmad-master still present after partial uninstall (gemini still installed)');

    // (Cleanup of the last sharing platform requires bmadDir to be inside
    //  projectDir to compute removalSet; that's the production layout. The
    //  fixture above keeps bmad in a separate temp dir, so test 41 below
    //  exercises the in-project layout instead.)

    await fs.remove(tempProjectDir40).catch(() => {});
    await fs.remove(path.dirname(installedBmadDir40)).catch(() => {});
  } catch (error) {
    console.log(`${colors.red}Test Suite 40 setup failed: ${error.message}${colors.reset}`);
    failed++;
  }

  console.log('');

  // ============================================================
  // Test Suite 40b: setupBatch — failed first writer does not poison peers
  // ============================================================
  console.log(`${colors.yellow}Test Suite 40b: setupBatch resilience to first-writer failure${colors.reset}\n`);

  try {
    const tempProjectDir40b = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-batch-fail-'));
    const installedBmadDir40b = await createTestBmadFixture();

    const ideManager40b = new IdeManager();
    await ideManager40b.ensureInitialized();

    // Force cursor's setup() to fail. With the bug, gemini would see the
    // claimed target and skip — leaving .agents/skills/ empty.
    const cursorHandler40b = ideManager40b.handlers.get('cursor');
    const originalSetup = cursorHandler40b.setup.bind(cursorHandler40b);
    cursorHandler40b.setup = async () => {
      throw new Error('Simulated cursor failure');
    };

    const batchResults40b = await ideManager40b.setupBatch(['cursor', 'gemini'], tempProjectDir40b, installedBmadDir40b, {
      silent: true,
      selectedModules: ['core'],
    });

    // Restore so other tests aren't affected.
    cursorHandler40b.setup = originalSetup;

    assert(batchResults40b[0].success === false, 'Cursor reports failure');
    assert(batchResults40b[1].success === true, 'Gemini still succeeds despite cursor failure');
    assert(
      batchResults40b[1].handlerResult?.results?.sharedTargetHandledByPeer !== true,
      'Gemini does NOT skip its own write — it becomes the new first writer',
    );

    const sharedDir40b = path.join(tempProjectDir40b, '.agents', 'skills');
    const entries40b = await fs.readdir(sharedDir40b);
    assert(entries40b.includes('bmad-master'), 'Shared dir is populated by gemini after cursor failure');

    await fs.remove(tempProjectDir40b).catch(() => {});
    await fs.remove(path.dirname(installedBmadDir40b)).catch(() => {});
  } catch (error) {
    console.log(`${colors.red}Test Suite 40b setup failed: ${error.message}${colors.reset}`);
    failed++;
  }

  console.log('');

  // ============================================================
  // Test Suite 40c: OpenCode command pointers in multi-IDE batches
  // ============================================================
  // Regression: when OpenCode is the *peer* in a setupBatch sharing
  // .agents/skills (e.g. with openhands), the skill write is dedup-skipped
  // but the per-IDE .opencode/commands/ pointers must still be generated.
  // Symmetrically, partial uninstall while a peer remains must still clean
  // up OpenCode's own command pointers.
  console.log(`${colors.yellow}Test Suite 40c: OpenCode command pointers in shared-target batches${colors.reset}\n`);

  try {
    clearCache();
    const platformCodes40c = await loadPlatformCodes();
    const opencodeTarget40c = platformCodes40c.platforms.opencode?.installer?.target_dir;
    const openhandsTarget40c = platformCodes40c.platforms.openhands?.installer?.target_dir;
    assert(
      opencodeTarget40c === '.agents/skills' && openhandsTarget40c === '.agents/skills',
      'OpenCode and OpenHands share .agents/skills target_dir',
    );

    // Order A: opencode first → opencode is the writer.
    const projA = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-opencode-batch-a-'));
    const bmadA = await createTestBmadFixture();
    const mgrA = new IdeManager();
    await mgrA.ensureInitialized();
    const resultsA = await mgrA.setupBatch(['opencode', 'openhands'], projA, bmadA, {
      silent: true,
      selectedModules: ['core'],
    });
    const cmdA = path.join(projA, '.opencode', 'commands', 'bmad-master.md');
    assert(
      resultsA.every((r) => r.success === true),
      'opencode-first batch: all platforms succeed',
    );
    assert(await fs.pathExists(cmdA), 'opencode-first batch: command pointer is created');

    // Order B: openhands first → opencode is the peer (skipTarget=true).
    // Without the fix, the early-return would bypass installCommandPointers.
    const projB = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-opencode-batch-b-'));
    const bmadB = await createTestBmadFixture();
    const mgrB = new IdeManager();
    await mgrB.ensureInitialized();
    const resultsB = await mgrB.setupBatch(['openhands', 'opencode'], projB, bmadB, {
      silent: true,
      selectedModules: ['core'],
    });
    const cmdB = path.join(projB, '.opencode', 'commands', 'bmad-master.md');
    const opencodeResultB = resultsB.find((r) => r.ide === 'opencode');
    assert(
      resultsB.every((r) => r.success === true),
      'openhands-first batch: all platforms succeed',
    );
    assert(
      opencodeResultB?.handlerResult?.results?.sharedTargetHandledByPeer === true,
      'openhands-first batch: opencode is marked sharedTargetHandledByPeer (skill write deduped)',
    );
    assert(await fs.pathExists(cmdB), 'openhands-first batch: command pointer is generated even when skill write is deduped');

    // Cleanup symmetry: uninstall opencode while openhands remains.
    // Uses an in-project bmadDir so the cleanup path can compute removalSet
    // from the manifest (the production layout). The cross-temp-dir fixture
    // above can't exercise this — same constraint Test Suite 40 documents.
    const projC = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-opencode-batch-c-'));
    const bmadC = path.join(projC, '_bmad');
    await fs.ensureDir(path.join(bmadC, '_config'));
    await fs.writeFile(
      path.join(bmadC, '_config', 'skill-manifest.csv'),
      'canonicalId,name,description,module,path\n' +
        '"bmad-master","bmad-master","Minimal test agent fixture","core","_bmad/core/bmad-master/SKILL.md"\n',
    );
    const skillC = path.join(bmadC, 'core', 'bmad-master');
    await fs.ensureDir(skillC);
    await fs.writeFile(
      path.join(skillC, 'SKILL.md'),
      ['---', 'name: bmad-master', 'description: Minimal test agent fixture', '---', '', 'You are a test agent.'].join('\n'),
    );

    const mgrC = new IdeManager();
    await mgrC.ensureInitialized();
    await mgrC.setupBatch(['openhands', 'opencode'], projC, bmadC, {
      silent: true,
      selectedModules: ['core'],
    });
    const cmdC = path.join(projC, '.opencode', 'commands', 'bmad-master.md');
    assert(await fs.pathExists(cmdC), 'in-project fixture: pointer is generated for opencode peer');

    const cleanupResultsC = await mgrC.cleanupByList(projC, ['opencode'], {
      silent: true,
      remainingIdes: ['openhands'],
    });
    assert(cleanupResultsC[0].success !== false, 'opencode partial-uninstall reports success');
    const sharedSurvivesC = await fs.pathExists(path.join(projC, '.agents', 'skills', 'bmad-master', 'SKILL.md'));
    assert(sharedSurvivesC, 'shared .agents/skills/ survives partial uninstall (peer still uses it)');
    assert(!(await fs.pathExists(cmdC)), 'opencode command pointer is removed on partial uninstall even when peer remains');

    await fs.remove(projA).catch(() => {});
    await fs.remove(path.dirname(bmadA)).catch(() => {});
    await fs.remove(projB).catch(() => {});
    await fs.remove(path.dirname(bmadB)).catch(() => {});
    await fs.remove(projC).catch(() => {});
  } catch (error) {
    console.log(`${colors.red}Test Suite 40c setup failed: ${error.message}${colors.reset}`);
    failed++;
  }

  console.log('');

  // ============================================================
  // Test Suite 41: Custom-module skill ownership (non-bmad prefix)
  // ============================================================
  console.log(`${colors.yellow}Test Suite 41: Custom-module skill ownership${colors.reset}\n`);

  try {
    // A custom module can ship a skill with any canonicalId (e.g. "fred-cool-skill").
    // detect() must recognize it as BMAD-owned via the manifest, not the bmad- prefix.
    const fixtureRoot41 = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-custom-prefix-'));
    const bmadDir41 = path.join(fixtureRoot41, '_bmad');
    await fs.ensureDir(path.join(bmadDir41, '_config'));
    await fs.writeFile(
      path.join(bmadDir41, '_config', 'skill-manifest.csv'),
      [
        'canonicalId,name,description,module,path',
        '"fred-cool-skill","fred-cool-skill","Custom module skill","fred","_bmad/fred/skills/fred-cool-skill/SKILL.md"',
        '',
      ].join('\n'),
    );
    const fredSkill = path.join(bmadDir41, 'fred', 'skills', 'fred-cool-skill');
    await fs.ensureDir(fredSkill);
    await fs.writeFile(
      path.join(fredSkill, 'SKILL.md'),
      ['---', 'name: fred-cool-skill', 'description: Custom module skill', '---', '', 'A custom module skill.'].join('\n'),
    );

    const ideManager41 = new IdeManager();
    await ideManager41.ensureInitialized();
    await ideManager41.setup('cursor', fixtureRoot41, bmadDir41, { silent: true, selectedModules: ['fred'] });

    const cursorHandler = ideManager41.handlers.get('cursor');
    const detected = await cursorHandler.detect(fixtureRoot41);
    assert(detected === true, 'detect() recognizes non-bmad-prefixed skill as BMAD-owned via skill-manifest.csv');

    await fs.remove(fixtureRoot41).catch(() => {});
  } catch (error) {
    console.log(`${colors.red}Test Suite 41 setup failed: ${error.message}${colors.reset}`);
    failed++;
  }

  console.log('');

  // ============================================================
  // Test Suite 42: --tools flag parsing & validation (#2326)
  // ============================================================
  console.log(`${colors.yellow}Test Suite 42: --tools flag parsing & validation${colors.reset}\n`);
  try {
    const { UI } = require('../tools/installer/ui');
    const ui = new UI();
    const known = new Set(['claude-code', 'cursor', 'windsurf']);

    assert(
      JSON.stringify(ui._parseToolsFlag('claude-code', known)) === JSON.stringify(['claude-code']),
      'parseToolsFlag returns single ID',
    );

    assert(
      JSON.stringify(ui._parseToolsFlag('claude-code,cursor', known)) === JSON.stringify(['claude-code', 'cursor']),
      'parseToolsFlag returns multiple IDs',
    );

    assert(
      JSON.stringify(ui._parseToolsFlag(' claude-code , cursor ', known)) === JSON.stringify(['claude-code', 'cursor']),
      'parseToolsFlag trims whitespace',
    );

    let emptyErr;
    try {
      ui._parseToolsFlag('', known);
    } catch (error) {
      emptyErr = error;
    }
    assert(
      emptyErr && emptyErr.expected === true && /empty/i.test(emptyErr.message),
      'parseToolsFlag rejects empty string with expected=true',
    );

    let commasOnlyErr;
    try {
      ui._parseToolsFlag(' , , ', known);
    } catch (error) {
      commasOnlyErr = error;
    }
    assert(commasOnlyErr && commasOnlyErr.expected === true, 'parseToolsFlag rejects whitespace/comma-only input');

    let noneErr;
    try {
      ui._parseToolsFlag('none', known);
    } catch (error) {
      noneErr = error;
    }
    assert(noneErr && noneErr.expected === true && /Unknown tool ID/.test(noneErr.message), 'parseToolsFlag rejects "none" as unknown ID');

    let typoErr;
    try {
      ui._parseToolsFlag('claude-code,claude-cdoe', known);
    } catch (error) {
      typoErr = error;
    }
    const typoHeader = typoErr ? typoErr.message.split('\n')[0] : '';
    assert(
      typoErr && typoErr.expected === true && /claude-cdoe/.test(typoHeader) && !/claude-code/.test(typoHeader),
      'parseToolsFlag reports only the unknown ID in error header (valid ones not listed as unknown)',
    );

    // --list-tools and --tools validation must agree on what counts as a valid ID.
    const { formatPlatformList } = require('../tools/installer/ide/platform-codes');
    const { IdeManager } = require('../tools/installer/ide/manager');
    const ideManager42 = new IdeManager();
    await ideManager42.ensureInitialized();
    const validIds = new Set(ideManager42.getAvailableIdes().map((i) => i.value));
    const listed = await formatPlatformList();
    // Each entry line starts with ' *' (preferred) or '  ' (other), followed by the ID, then padding.
    const entryLines = listed.split('\n').filter((l) => /^( \*| {2})[a-z]/.test(l));
    const listedIds = entryLines.map((l) => l.trim().replace(/^\*/, '').split(/\s+/)[0]);
    const missingFromList = [...validIds].filter((id) => !listedIds.includes(id));
    const extraInList = listedIds.filter((id) => !validIds.has(id));
    assert(
      missingFromList.length === 0 && extraInList.length === 0,
      '--list-tools output matches the IDs that --tools accepts',
      `Missing from list: ${missingFromList.join(',') || '(none)'}; Extra in list: ${extraInList.join(',') || '(none)'}`,
    );
  } catch (error) {
    console.log(`${colors.red}Test Suite 42 setup failed: ${error.message}${colors.reset}`);
    console.log(error.stack);
    failed++;
  }

  console.log('');

  // ============================================================
  // Test Suite 43: project_name promoted to core + hoist migration (#2279)
  // ============================================================
  console.log(`${colors.yellow}Test Suite 43: project_name in core + hoist migration${colors.reset}\n`);
  try {
    const yamlLib = require('yaml');
    const coreSchemaPath = path.join(__dirname, '..', 'src', 'core-skills', 'module.yaml');
    const bmmSchemaPath = path.join(__dirname, '..', 'src', 'bmm-skills', 'module.yaml');
    const coreSchema = yamlLib.parse(await fs.readFile(coreSchemaPath, 'utf8'));
    const bmmSchema = yamlLib.parse(await fs.readFile(bmmSchemaPath, 'utf8'));

    assert(
      coreSchema.project_name && coreSchema.project_name.prompt && coreSchema.project_name.default === '{directory_name}',
      'core/module.yaml declares project_name with {directory_name} default',
    );

    assert(coreSchema.project_name.scope === undefined, 'project_name has no user scope (project-scoped, not user-scoped)');

    assert(bmmSchema.project_name === undefined, 'bmm/module.yaml no longer declares project_name (now inherited from core)');

    // Set up a mock existing install: bmm directory has project_name (legacy),
    // core has user_name but not project_name. After hoist, project_name should
    // move to core, leaving bmm with only its own keys.
    const fixtureRoot43 = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-fixture-43-'));
    const bmadDir43 = path.join(fixtureRoot43, '_bmad');
    await fs.ensureDir(path.join(bmadDir43, '_config'));
    await fs.writeFile(path.join(bmadDir43, '_config', 'manifest.yaml'), 'modules: []\n', 'utf8');
    await fs.ensureDir(path.join(bmadDir43, 'core'));
    await fs.ensureDir(path.join(bmadDir43, 'bmm'));
    await fs.writeFile(path.join(bmadDir43, 'core', 'config.yaml'), 'user_name: alice\n', 'utf8');
    await fs.writeFile(
      path.join(bmadDir43, 'bmm', 'config.yaml'),
      'project_name: legacy-from-bmm\nuser_skill_level: intermediate\n',
      'utf8',
    );

    const officialModules43 = new OfficialModules();
    await officialModules43.loadExistingConfig(fixtureRoot43);

    assert(
      officialModules43.existingConfig.core?.project_name === 'legacy-from-bmm',
      'loadExistingConfig hoists bmm.project_name to core on existing-install upgrade',
    );

    assert(
      !('project_name' in (officialModules43.existingConfig.bmm || {})),
      'loadExistingConfig removes project_name from bmm after hoisting',
    );

    assert(
      officialModules43.existingConfig.bmm?.user_skill_level === 'intermediate',
      'loadExistingConfig leaves non-core bmm keys (user_skill_level) untouched',
    );

    assert(officialModules43.existingConfig.core?.user_name === 'alice', 'loadExistingConfig preserves pre-existing core values');

    // Precedence: if core already has the key, hoist must NOT overwrite it.
    const fixtureRoot43b = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-fixture-43b-'));
    const bmadDir43b = path.join(fixtureRoot43b, '_bmad');
    await fs.ensureDir(path.join(bmadDir43b, '_config'));
    await fs.writeFile(path.join(bmadDir43b, '_config', 'manifest.yaml'), 'modules: []\n', 'utf8');
    await fs.ensureDir(path.join(bmadDir43b, 'core'));
    await fs.ensureDir(path.join(bmadDir43b, 'bmm'));
    await fs.writeFile(path.join(bmadDir43b, 'core', 'config.yaml'), 'project_name: from-core\n', 'utf8');
    await fs.writeFile(path.join(bmadDir43b, 'bmm', 'config.yaml'), 'project_name: stale-from-bmm\n', 'utf8');

    const officialModules43b = new OfficialModules();
    await officialModules43b.loadExistingConfig(fixtureRoot43b);

    assert(officialModules43b.existingConfig.core?.project_name === 'from-core', 'hoist does not overwrite an existing core value');

    assert(
      !('project_name' in (officialModules43b.existingConfig.bmm || {})),
      'hoist still strips the duplicate from bmm so writeCentralConfig partition stays clean',
    );

    // Malformed config.yaml (parses to a scalar) must not crash loadExistingConfig
    // or the hoist pass — they should treat it as "no config for that module"
    // and continue. Regression for augment review on PR #2348.
    const fixtureRoot43c = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-fixture-43c-'));
    const bmadDir43c = path.join(fixtureRoot43c, '_bmad');
    await fs.ensureDir(path.join(bmadDir43c, '_config'));
    await fs.writeFile(path.join(bmadDir43c, '_config', 'manifest.yaml'), 'modules: []\n', 'utf8');
    await fs.ensureDir(path.join(bmadDir43c, 'core'));
    await fs.ensureDir(path.join(bmadDir43c, 'bmm'));
    // Scalar YAML — yaml.parse returns the literal 42 (truthy non-object).
    // Pre-fix this crashed _hoistCoreKeysFromLegacyModuleConfigs with
    // "Cannot use 'in' operator to search for 'project_name' in 42".
    await fs.writeFile(path.join(bmadDir43c, 'core', 'config.yaml'), '42\n', 'utf8');
    await fs.writeFile(path.join(bmadDir43c, 'bmm', 'config.yaml'), 'project_name: rescued\n', 'utf8');

    const officialModules43c = new OfficialModules();
    let crashErr;
    try {
      await officialModules43c.loadExistingConfig(fixtureRoot43c);
    } catch (error) {
      crashErr = error;
    }
    assert(!crashErr, 'loadExistingConfig does not crash on a scalar core/config.yaml', crashErr?.stack);

    assert(
      officialModules43c.existingConfig.core?.project_name === 'rescued',
      'scalar core gets replaced with {} and bmm.project_name still hoists in',
    );

    await fs.remove(fixtureRoot43).catch(() => {});
    await fs.remove(fixtureRoot43b).catch(() => {});
    await fs.remove(fixtureRoot43c).catch(() => {});
  } catch (error) {
    console.log(`${colors.red}Test Suite 43 setup failed: ${error.message}${colors.reset}`);
    console.log(error.stack);
    failed++;
  }

  console.log('');

  // ============================================================
  // Test Suite 44: --set <module>.<key>=<value> CLI overrides (#1663)
  // ============================================================
  console.log(`${colors.yellow}Test Suite 44: --set CLI overrides${colors.reset}\n`);
  try {
    const { parseSetEntry, parseSetEntries, applySetOverrides, upsertTomlKey, tomlString } = require('../tools/installer/set-overrides');
    const { discoverOfficialModuleYamls, formatOptionsList } = require('../tools/installer/list-options');

    // ---- Parser ----------------------------------------------------------
    const ok = parseSetEntry('bmm.project_knowledge=research');
    assert(
      ok.module === 'bmm' && ok.key === 'project_knowledge' && ok.value === 'research',
      'parseSetEntry splits <module>.<key>=<value> correctly',
    );
    assert(parseSetEntry('bmm.weird=a=b=c').value === 'a=b=c', 'parseSetEntry preserves additional "=" inside the value');

    const badInputs = ['no-equals', 'no-dot=value', '=value', '.=value', 'foo.=value', '.bar=value', ''];
    let allBadThrow = true;
    for (const bad of badInputs) {
      try {
        parseSetEntry(bad);
        allBadThrow = false;
      } catch {
        /* expected */
      }
    }
    assert(allBadThrow, `parseSetEntry rejects malformed inputs (${badInputs.length} cases)`);

    const multi = parseSetEntries(['bmm.project_knowledge=research', 'bmm.user_skill_level=expert', 'core.user_name=Brian']);
    assert(
      multi.bmm.project_knowledge === 'research' && multi.bmm.user_skill_level === 'expert' && multi.core.user_name === 'Brian',
      'parseSetEntries groups by module',
    );
    assert(parseSetEntries(['bmm.x=first', 'bmm.x=second']).bmm.x === 'second', 'parseSetEntries: later --set entry overrides earlier');
    const empty = parseSetEntries();
    assert(empty && Object.keys(empty).length === 0, 'parseSetEntries() returns empty object when called without args');

    // Prototype-pollution guard. `--set __proto__.x=1` would otherwise reach
    // `overrides.__proto__[x] = 1` and pollute every plain object.
    const polluteProbe = {};
    let pollutionThrown = false;
    try {
      parseSetEntries(['__proto__.polluted=1']);
    } catch {
      pollutionThrown = true;
    }
    assert(pollutionThrown, 'parseSetEntries rejects __proto__ as a module name');
    assert(polluteProbe.polluted === undefined, 'Object.prototype is not polluted by __proto__ in --set entries');
    let constructorThrown = false;
    try {
      parseSetEntries(['bmm.constructor=evil']);
    } catch {
      constructorThrown = true;
    }
    assert(constructorThrown, 'parseSetEntries rejects "constructor" as a key name');

    // ---- tomlString ------------------------------------------------------
    assert(tomlString('hello') === '"hello"', 'tomlString quotes a plain string');
    assert(tomlString('with "quotes"') === String.raw`"with \"quotes\""`, 'tomlString escapes embedded double-quotes');
    assert(tomlString(String.raw`back\slash`) === String.raw`"back\\slash"`, 'tomlString escapes backslashes');
    assert(tomlString('line1\nline2') === String.raw`"line1\nline2"`, 'tomlString escapes newlines');

    // ---- upsertTomlKey: insert into existing section ---------------------
    {
      const before = `[core]\nuser_name = "Brian"\n\n[modules.bmm]\nproject_knowledge = "{project-root}/docs"\n`;
      const after = upsertTomlKey(before, '[modules.bmm]', 'future_thing', '"persists"');
      assert(after.includes('future_thing = "persists"'), 'upsertTomlKey inserts a new key into an existing section');
      assert(/project_knowledge = "{project-root}\/docs"/.test(after), 'upsertTomlKey preserves existing keys');
    }

    // ---- upsertTomlKey: replace existing key, keep comment tail ----------
    {
      const before = `[core]\nuser_name = "old"  # set on first install\n`;
      const after = upsertTomlKey(before, '[core]', 'user_name', '"Brian"');
      assert(/user_name = "Brian"\s+# set on first install/.test(after), 'upsertTomlKey preserves trailing comments');
      assert(!after.includes('"old"'), 'upsertTomlKey replaces the prior value');
    }

    // ---- upsertTomlKey: section missing → append new section -------------
    {
      const before = `[core]\nuser_name = "Brian"\n`;
      const after = upsertTomlKey(before, '[modules.bmm]', 'project_knowledge', '"research"');
      assert(after.includes('[modules.bmm]'), 'upsertTomlKey appends a new section when missing');
      assert(after.includes('project_knowledge = "research"'), 'upsertTomlKey appends the key under the new section');
      // Existing section remains untouched
      assert(after.indexOf('[core]') < after.indexOf('[modules.bmm]'), 'upsertTomlKey adds the new section AFTER existing content');
    }

    // ---- upsertTomlKey: empty file ---------------------------------------
    {
      const after = upsertTomlKey('', '[core]', 'user_name', '"Brian"');
      assert(after.startsWith('[core]'), 'upsertTomlKey on an empty string emits the section header');
      assert(after.includes('user_name = "Brian"'), 'upsertTomlKey on an empty string writes the key');
    }

    // ---- upsertTomlKey: trailing newline preserved -----------------------
    {
      const withTrailing = upsertTomlKey('[core]\nuser_name = "old"\n', '[core]', 'user_name', '"new"');
      assert(withTrailing.endsWith('\n'), 'upsertTomlKey preserves trailing newline');
      const withoutTrailing = upsertTomlKey('[core]\nuser_name = "old"', '[core]', 'user_name', '"new"');
      assert(!withoutTrailing.endsWith('\n'), 'upsertTomlKey preserves absence of trailing newline');
    }

    // ---- applySetOverrides happy path ------------------------------------
    {
      const tmp = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-applyset-'));
      const bmadDir = path.join(tmp, '_bmad');
      await fs.ensureDir(bmadDir);
      // Seed a realistic post-install state: team config has bmm.project_knowledge,
      // user config has core.user_name. The applySetOverrides router should
      // route bmm.user_skill_level → user.toml (already there), core.user_name
      // update → user.toml (already there), and a brand-new key → team.toml.
      await fs.writeFile(
        path.join(bmadDir, 'config.toml'),
        '[core]\nproject_name = "demo"\n\n[modules.bmm]\nproject_knowledge = "{project-root}/docs"\n',
        'utf8',
      );
      await fs.writeFile(
        path.join(bmadDir, 'config.user.toml'),
        '[core]\nuser_name = "OldName"\n\n[modules.bmm]\nuser_skill_level = "intermediate"\n',
        'utf8',
      );
      // Per-module config.yaml stubs are the "is this module installed?"
      // signal applySetOverrides uses to skip uninstalled-module overrides.
      await fs.ensureDir(path.join(bmadDir, 'core'));
      await fs.writeFile(path.join(bmadDir, 'core', 'config.yaml'), 'project_name: demo\n', 'utf8');
      await fs.ensureDir(path.join(bmadDir, 'bmm'));
      await fs.writeFile(
        path.join(bmadDir, 'bmm', 'config.yaml'),
        'project_knowledge: "{project-root}/docs"\nuser_skill_level: intermediate\n',
        'utf8',
      );

      const overrides = {
        core: { user_name: 'Brian' },
        bmm: { user_skill_level: 'expert', future_thing: 'persists' },
      };
      const applied = await applySetOverrides(overrides, bmadDir);

      const team = await fs.readFile(path.join(bmadDir, 'config.toml'), 'utf8');
      const user = await fs.readFile(path.join(bmadDir, 'config.user.toml'), 'utf8');

      assert(user.includes('user_name = "Brian"'), 'applySetOverrides updates user-scope key in config.user.toml');
      assert(user.includes('user_skill_level = "expert"'), 'applySetOverrides updates pre-existing user-scope key in config.user.toml');
      assert(team.includes('future_thing = "persists"'), 'applySetOverrides routes brand-new key to team config.toml');
      assert(team.includes('project_knowledge = "{project-root}/docs"'), 'applySetOverrides leaves untouched team keys alone');
      assert(!team.includes('user_name = "Brian"'), 'applySetOverrides does NOT duplicate user-scope key into team file');

      const summary = applied
        .map((a) => `${a.module}.${a.key}->${a.scope}`)
        .sort()
        .join(',');
      assert(
        summary === 'bmm.future_thing->team,bmm.user_skill_level->user,core.user_name->user',
        `applySetOverrides reports correct routing decisions (got: ${summary})`,
      );

      await fs.remove(tmp).catch(() => {});
    }

    // ---- applySetOverrides creates config.user.toml if missing -----------
    {
      const tmp = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-applyset-nouser-'));
      const bmadDir = path.join(tmp, '_bmad');
      await fs.ensureDir(bmadDir);
      await fs.writeFile(path.join(bmadDir, 'config.toml'), '[core]\nuser_name = "Brian"\n', 'utf8');
      await fs.ensureDir(path.join(bmadDir, 'core'));
      await fs.writeFile(path.join(bmadDir, 'core', 'config.yaml'), 'user_name: Brian\n', 'utf8');
      // Override targets a key only in team config; routes to team. user.toml
      // never gets created in this case (correct — no user-scope writes).
      await applySetOverrides({ core: { user_name: 'Updated' } }, bmadDir);
      const team = await fs.readFile(path.join(bmadDir, 'config.toml'), 'utf8');
      assert(team.includes('user_name = "Updated"'), 'applySetOverrides updates team key when user.toml is absent');
      assert(
        !(await fs.pathExists(path.join(bmadDir, 'config.user.toml'))),
        'applySetOverrides does not create config.user.toml unnecessarily',
      );
      await fs.remove(tmp).catch(() => {});
    }

    // ---- applySetOverrides skips modules without per-module config.yaml --
    {
      const tmp = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-applyset-skip-'));
      const bmadDir = path.join(tmp, '_bmad');
      await fs.ensureDir(bmadDir);
      await fs.writeFile(path.join(bmadDir, 'config.toml'), '[core]\nuser_name = "Brian"\n', 'utf8');
      await fs.ensureDir(path.join(bmadDir, 'core'));
      await fs.writeFile(path.join(bmadDir, 'core', 'config.yaml'), 'user_name: Brian\n', 'utf8');
      // bmm is not installed (no `_bmad/bmm/config.yaml`). The override for
      // bmm should be silently skipped, no `[modules.bmm]` section created.
      const applied = await applySetOverrides({ bmm: { foo: 'bar' }, core: { user_name: 'Updated' } }, bmadDir);
      const team = await fs.readFile(path.join(bmadDir, 'config.toml'), 'utf8');
      assert(!team.includes('[modules.bmm]'), 'applySetOverrides does NOT create section for uninstalled module');
      assert(team.includes('user_name = "Updated"'), 'applySetOverrides still applies overrides for installed modules');
      assert(applied.length === 1 && applied[0].module === 'core', 'applySetOverrides reports only the installed-module entries');
      await fs.remove(tmp).catch(() => {});
    }

    // ---- applySetOverrides: empty/missing input is a no-op ---------------
    {
      const tmp = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-applyset-empty-'));
      const bmadDir = path.join(tmp, '_bmad');
      await fs.ensureDir(bmadDir);
      const empty1 = await applySetOverrides({}, bmadDir);
      const empty2 = await applySetOverrides(null, bmadDir);
      const empty3 = await applySetOverrides(undefined, bmadDir);
      assert(
        empty1.length === 0 && empty2.length === 0 && empty3.length === 0,
        'applySetOverrides is a no-op for empty/null/undefined input',
      );
      await fs.remove(tmp).catch(() => {});
    }

    // ---- discoverOfficialModuleYamls + formatOptionsList -----------------
    // These read the on-disk external-module cache. Point that env at a temp
    // dir so test results don't depend on whatever the developer / CI runner
    // has cached.
    const priorCacheEnv44 = process.env.BMAD_EXTERNAL_MODULES_CACHE;
    const tempCacheDir44 = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-list-options-cache-'));
    process.env.BMAD_EXTERNAL_MODULES_CACHE = tempCacheDir44;
    try {
      const discovered = await discoverOfficialModuleYamls();
      const codes = new Set(discovered.map((d) => d.code));
      assert(codes.has('core') && codes.has('bmm'), 'discoverOfficialModuleYamls finds core and bmm built-ins');

      const bmmListing = await formatOptionsList('bmm');
      assert(bmmListing.ok === true, '--list-options bmm reports ok: true');
      assert(bmmListing.text.includes('bmm.project_knowledge'), '--list-options bmm renders bmm.project_knowledge');
      assert(bmmListing.text.includes('bmm.user_skill_level'), '--list-options bmm renders bmm.user_skill_level');

      // Case-insensitive filter.
      const bmmUpper = await formatOptionsList('BMM');
      assert(bmmUpper.ok === true && bmmUpper.text.includes('bmm.project_knowledge'), '--list-options is case-insensitive');

      // Unknown module → non-zero exit signal.
      const unknown = await formatOptionsList('definitely-not-a-module');
      assert(unknown.ok === false, '--list-options <unknown> reports ok: false');
      assert(unknown.text.includes('No locally-known module.yaml'), '--list-options unknown explains the miss');
    } finally {
      if (priorCacheEnv44 === undefined) {
        delete process.env.BMAD_EXTERNAL_MODULES_CACHE;
      } else {
        process.env.BMAD_EXTERNAL_MODULES_CACHE = priorCacheEnv44;
      }
      await fs.remove(tempCacheDir44).catch(() => {});
    }
  } catch (error) {
    console.log(`${colors.red}Test Suite 44 setup failed: ${error.message}${colors.reset}`);
    console.log(error.stack);
    failed++;
  }

  console.log('');

  // ============================================================
  // Test Suite 45: _cleanupSkillDirs prunes empty parent dirs (#empty-bmm-folders)
  // ============================================================
  console.log(`${colors.yellow}Test Suite 45: cleanup prunes empty skill-group dirs${colors.reset}\n`);

  let root45;
  try {
    root45 = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-cleanup-test-'));
    const bmadDir45 = path.join(root45, '_bmad');
    await fs.ensureDir(path.join(bmadDir45, '_config'));

    // Two skills under grouping dirs (agents, nested plan/research), plus a
    // module-level file that must survive the cleanup.
    await fs.writeFile(
      path.join(bmadDir45, '_config', 'skill-manifest.csv'),
      [
        'canonicalId,name,description,module,path',
        '"bmad-agent-analyst","bmad-agent-analyst","fixture","bmm","_bmad/bmm/agents/bmad-agent-analyst/SKILL.md"',
        '"bmad-research","bmad-research","fixture","bmm","_bmad/bmm/plan/research/bmad-research/SKILL.md"',
        '',
      ].join('\n'),
    );
    await fs.ensureDir(path.join(bmadDir45, 'bmm', 'agents', 'bmad-agent-analyst'));
    await fs.writeFile(path.join(bmadDir45, 'bmm', 'agents', 'bmad-agent-analyst', 'SKILL.md'), 'x');
    await fs.ensureDir(path.join(bmadDir45, 'bmm', 'plan', 'research', 'bmad-research'));
    await fs.writeFile(path.join(bmadDir45, 'bmm', 'plan', 'research', 'bmad-research', 'SKILL.md'), 'x');
    await fs.writeFile(path.join(bmadDir45, 'bmm', 'config.yaml'), 'module: bmm\n');

    const installer45 = new Installer();
    await installer45._cleanupSkillDirs(bmadDir45);

    assert(!(await fs.pathExists(path.join(bmadDir45, 'bmm', 'agents'))), 'empty skill-group dir is pruned after cleanup');
    assert(!(await fs.pathExists(path.join(bmadDir45, 'bmm', 'plan'))), 'empty nested skill-group dir is pruned');
    assert(await fs.pathExists(path.join(bmadDir45, 'bmm', 'config.yaml')), 'module-level files are preserved');
    assert(await fs.pathExists(bmadDir45), 'bmad root is never removed');
  } catch (error) {
    console.log(`${colors.red}Test Suite 45 setup failed: ${error.message}${colors.reset}`);
    console.log(error.stack);
    failed++;
  } finally {
    if (root45) await fs.remove(root45).catch(() => {});
  }

  console.log('');

  // ============================================================
  // Test Suite 46: uv environment check (version parsing + messaging)
  // ============================================================
  console.log(`${colors.yellow}Test Suite 46: uv-check version parsing and messaging${colors.reset}\n`);

  try {
    const { parseUvVersion, parsePythonVersion, pythonMeetsMinimum, detectUv, detectPython3 } = require('../tools/installer/core/uv-check');

    // Version parsing
    const plain = parseUvVersion('uv 0.5.31');
    assert(plain && plain.major === 0 && plain.minor === 5 && plain.patch === 31, 'parses "uv 0.5.31"');
    const brew = parseUvVersion('uv 0.5.31 (Homebrew 2025-02-12)');
    assert(brew && brew.raw === '0.5.31', 'parses uv version with build suffix');
    const noPatch = parseUvVersion('uv 1.2');
    assert(noPatch && noPatch.patch === 0, 'missing patch defaults to 0');
    assert(parseUvVersion('') === null, 'empty output returns null');
    assert(parseUvVersion('command not found: uv') === null, 'non-version output returns null');
    assert(parseUvVersion(null) === null, 'null output returns null');

    // Python version parsing — probed only as the no-uv fallback.
    const py = parsePythonVersion('Python 3.11.7');
    assert(py && py.major === 3 && py.minor === 11 && py.patch === 7, 'parses "Python 3.11.7"');
    assert(parsePythonVersion('Python 3.13.0rc1').raw === '3.13.0', 'parses a prerelease python version');
    assert(parsePythonVersion('python3: command not found') === null, 'non-version python output returns null');
    assert(pythonMeetsMinimum({ major: 3, minor: 11 }), '3.11 meets the minimum');
    assert(pythonMeetsMinimum({ major: 3, minor: 13 }), '3.13 meets the minimum');
    assert(!pythonMeetsMinimum({ major: 3, minor: 10 }), '3.10 is below the minimum');
    assert(!pythonMeetsMinimum({ major: 2, minor: 7 }), '2.7 is below the minimum');
    assert(pythonMeetsMinimum({ major: 4, minor: 0 }), 'a future 4.x meets the minimum');
    assert(!pythonMeetsMinimum(null), 'a missing python version does not meet the minimum');

    // Detection smoke tests — must not throw; result is null or well-formed.
    const detectedUv = detectUv();
    assert(detectedUv === null || typeof detectedUv.version.raw === 'string', 'detectUv returns null or a well-formed result');
    const detectedPy = detectPython3();
    assert(detectedPy === null || typeof detectedPy.version.raw === 'string', 'detectPython3 returns null or a well-formed result');

    // checkUvEnvironment branch coverage — stub detection + prompts so the
    // assertions are deterministic regardless of what's installed locally.
    const uvCheck = require('../tools/installer/core/uv-check');
    const promptsModule = require('../tools/installer/prompts');
    const realUv = {
      detectUv: uvCheck.detectUv,
      detectPython3: uvCheck.detectPython3,
      log: promptsModule.log,
      note: promptsModule.note,
    };
    const stubUv = (detectResult, pythonResult = null) => {
      const seen = { success: [], warn: [], note: [] };
      uvCheck.detectUv = () => detectResult;
      uvCheck.detectPython3 = () => pythonResult;
      promptsModule.log = {
        success: async (m) => void seen.success.push(m),
        warn: async (m) => void seen.warn.push(m),
        info: async () => {},
        error: async () => {},
      };
      promptsModule.note = async (m, t) => void seen.note.push(t || m);
      return seen;
    };

    try {
      // Branch: uv present — success, no warning, and python3 is never probed
      // (uv provisions its own interpreter from the script's requires-python).
      let probedPython = false;
      let seen = stubUv({ version: { major: 0, minor: 5, patch: 31, raw: '0.5.31' } });
      uvCheck.detectPython3 = () => {
        probedPython = true;
        return null;
      };
      let result = await uvCheck.checkUvEnvironment();
      assert(result.status === 'found' && seen.success.length === 1, 'uv present logs success');
      assert(
        seen.success[0].includes('Python UV check pass') && seen.warn.length === 0,
        'uv present shows Python UV check pass, no warning',
      );
      assert(!probedPython, 'uv present skips the python3 probe');

      // Branch: uv missing — warn + setup note, never blocks (no prompt).
      seen = stubUv(null, { version: { major: 3, minor: 12, patch: 1, raw: '3.12.1' } });
      result = await uvCheck.checkUvEnvironment();
      assert(result.status === 'missing' && seen.warn.length === 1, 'uv missing warns');
      assert(seen.warn[0].includes('bmad-build') && seen.warn[0].includes('HALT'), 'uv-missing warning names the skills that halt');
      assert(!seen.warn[0].includes('de facto standard'), 'uv-missing warning no longer frames uv as optional');
      assert(seen.warn[0].includes('install itself completes'), 'uv-missing warning says the install still completes');
      assert(
        seen.warn[0].includes('python3 3.12.1 is present'),
        'uv missing with a usable python3 says the direct-interpreter skills still work',
      );
      assert(seen.note.length === 1 && seen.note[0] === 'uv required', 'uv missing shows a setup note titled "uv required"');

      // Branch: uv missing and python3 too old — nothing Python-backed runs.
      seen = stubUv(null, { version: { major: 3, minor: 10, patch: 12, raw: '3.10.12' } });
      result = await uvCheck.checkUvEnvironment();
      assert(
        seen.warn[0].includes('below the required 3.11') && seen.warn[0].includes('no Python-backed skill will run'),
        'uv missing with python3 < 3.11 reports that nothing Python-backed runs',
      );
      assert(result.python.version.raw === '3.10.12', 'the probed python version is returned to the caller');

      // Branch: neither uv nor python3.
      seen = stubUv(null, null);
      result = await uvCheck.checkUvEnvironment();
      assert(seen.warn[0].includes('No python3 on PATH either'), 'uv and python3 both missing is reported');
      assert(result.python === null, 'no python result is returned when python3 is absent');
    } finally {
      uvCheck.detectUv = realUv.detectUv;
      uvCheck.detectPython3 = realUv.detectPython3;
      promptsModule.log = realUv.log;
      promptsModule.note = realUv.note;
    }
  } catch (error) {
    console.log(`${colors.red}Test Suite 46 setup failed: ${error.message}${colors.reset}`);
    console.log(error.stack);
    failed++;
  }

  console.log('');

  // ============================================================
  // Test Suite 47: WSL shell using Windows Node guard
  // ============================================================
  console.log(`${colors.yellow}Test Suite 47: WSL Windows Node guard${colors.reset}\n`);

  try {
    const wslNodeCheck = require('../tools/installer/core/wsl-node-check');

    let detection = wslNodeCheck.detectWindowsNodeFromWsl({
      platform: 'win32',
      env: { WSL_DISTRO_NAME: 'Ubuntu-26.04' },
      cwd: String.raw`C:\Windows`,
      execPath: String.raw`C:\Program Files\nodejs\node.exe`,
    });
    assert(detection.isMismatch === true, 'detects Windows Node launched from WSL via WSL_DISTRO_NAME');

    detection = wslNodeCheck.detectWindowsNodeFromWsl({
      platform: 'win32',
      env: { PWD: '/home/devuser/projects/md2pdf' },
      cwd: String.raw`\\wsl.localhost\Ubuntu-26.04\home\devuser\projects\md2pdf`,
      execPath: String.raw`C:\Program Files\nodejs\node.exe`,
    });
    assert(detection.isMismatch === true, 'detects Windows Node launched from WSL via Linux PWD / WSL UNC cwd');

    detection = wslNodeCheck.detectWindowsNodeFromWsl({
      platform: 'win32',
      env: {},
      cwd: String.raw`\\wsl$\Ubuntu-26.04\home\devuser\projects\md2pdf`,
      execPath: String.raw`C:\Program Files\nodejs\node.exe`,
    });
    assert(detection.isMismatch === true, 'detects Windows Node launched from WSL via legacy WSL UNC cwd');

    detection = wslNodeCheck.detectWindowsNodeFromWsl({
      platform: 'linux',
      env: { WSL_DISTRO_NAME: 'Ubuntu-26.04', PWD: '/home/devuser/projects/md2pdf' },
      cwd: '/home/devuser/projects/md2pdf',
      execPath: '/usr/bin/node',
    });
    assert(detection.isMismatch === false, 'allows native Linux Node inside WSL');

    detection = wslNodeCheck.detectWindowsNodeFromWsl({
      platform: 'win32',
      env: { PWD: String.raw`C:\Users\devuser\project` },
      cwd: String.raw`C:\Users\devuser\project`,
      execPath: String.raw`C:\Program Files\nodejs\node.exe`,
    });
    assert(detection.isMismatch === false, 'allows normal Windows Node outside WSL');

    detection = wslNodeCheck.detectWindowsNodeFromWsl({
      platform: 'win32',
      env: { PWD: '/c/Users/devuser/project' },
      cwd: String.raw`C:\Users\devuser\project`,
      execPath: String.raw`C:\Program Files\nodejs\node.exe`,
    });
    assert(detection.isMismatch === false, 'allows Git Bash Windows-drive PWD outside WSL');

    detection = wslNodeCheck.detectWindowsNodeFromWsl({
      platform: 'win32',
      env: { PWD: '/cygdrive/c/Users/devuser/project' },
      cwd: String.raw`C:\Users\devuser\project`,
      execPath: String.raw`C:\Program Files\nodejs\node.exe`,
    });
    assert(detection.isMismatch === false, 'allows Cygwin Windows-drive PWD outside WSL');

    const message = wslNodeCheck.formatWindowsNodeFromWslMessage({
      isMismatch: true,
      reason: 'WSL_DISTRO_NAME is set',
      execPath: String.raw`C:\Program Files\nodejs\node.exe`,
    });
    assert(message.includes('Install Node.js inside WSL'), 'guard message tells user to install Node.js inside WSL');
    assert(message.includes(String.raw`C:\Program Files\nodejs\node.exe`), 'guard message includes detected Windows Node path');

    const promptsModule = require('../tools/installer/prompts');
    const real = {
      detectWindowsNodeFromWsl: wslNodeCheck.detectWindowsNodeFromWsl,
      log: promptsModule.log,
      exit: process.exit,
    };
    const seen = { errors: [], exit: [] };
    wslNodeCheck.detectWindowsNodeFromWsl = () => ({
      isMismatch: true,
      reason: 'WSL_INTEROP is set',
      execPath: String.raw`C:\Program Files\nodejs\node.exe`,
    });
    promptsModule.log = {
      error: async (m) => void seen.errors.push(m),
      info: async () => {},
      success: async () => {},
      warn: async () => {},
      message: async () => {},
      step: async () => {},
    };
    process.exit = (code) => {
      seen.exit.push(code);
      throw new Error('__stub_exit__');
    };

    try {
      let threw = false;
      try {
        await wslNodeCheck.checkWindowsNodeFromWsl();
      } catch (error) {
        threw = error.message === '__stub_exit__';
      }
      assert(threw && seen.exit[0] === 1, 'guard exits with code 1 when Windows Node is launched from WSL');
      assert(seen.errors[0].includes('Windows Node.js was launched from a WSL shell'), 'guard logs the mismatch explanation');
    } finally {
      wslNodeCheck.detectWindowsNodeFromWsl = real.detectWindowsNodeFromWsl;
      promptsModule.log = real.log;
      process.exit = real.exit;
    }
  } catch (error) {
    console.log(`${colors.red}Test Suite 47 setup failed: ${error.message}${colors.reset}`);
    console.log(error.stack);
    failed++;
  }

  console.log('');

  // ============================================================
  // Test Suite 48: registry module-code aliases (renamed modules)
  // ============================================================
  console.log(`${colors.yellow}Test Suite 48: registry module-code aliases${colors.reset}\n`);

  try {
    const { ExternalModuleManager } = require('../tools/installer/modules/external-manager');
    const originalLoadConfig48 = ExternalModuleManager.prototype.loadExternalModulesConfig;

    ExternalModuleManager.prototype.loadExternalModulesConfig = async function () {
      return {
        modules: [
          {
            code: 'bmad-loop',
            aliases: ['bauto'],
            name: 'BMad Loop',
            repository: 'https://example.com/bmad-loop.git',
            module_definition: 'src/automator/data/skills/bmad-loop-setup/assets/module.yaml',
          },
          {
            code: 'cis',
            name: 'BMad Creative Intelligence Suite',
            repository: 'https://example.com/cis.git',
            module_definition: 'src/module.yaml',
          },
        ],
      };
    };

    try {
      const manager48 = new ExternalModuleManager();

      const byCanonical = await manager48.getModuleByCode('bmad-loop');
      assert(byCanonical && byCanonical.code === 'bmad-loop', 'getModuleByCode resolves the canonical code directly');

      const byAlias = await manager48.getModuleByCode('bauto');
      assert(byAlias && byAlias.code === 'bmad-loop', 'getModuleByCode resolves a prior code via aliases');

      const noAliasModule = await manager48.getModuleByCode('cis');
      assert(noAliasModule && noAliasModule.code === 'cis', 'getModuleByCode is unaffected for modules with no aliases');

      const unknown = await manager48.getModuleByCode('nonexistent-code');
      assert(unknown === null, 'getModuleByCode returns null for a code that matches nothing, including no alias');

      assert((await manager48.resolveCanonicalCode('bauto')) === 'bmad-loop', 'resolveCanonicalCode maps an alias to its canonical code');
      assert(
        (await manager48.resolveCanonicalCode('bmad-loop')) === 'bmad-loop',
        'resolveCanonicalCode is a no-op for an already-canonical code',
      );
      assert(
        (await manager48.resolveCanonicalCode('some-custom-module')) === 'some-custom-module',
        'resolveCanonicalCode passes through a code that matches no registry entry (e.g. a custom module)',
      );
    } finally {
      ExternalModuleManager.prototype.loadExternalModulesConfig = originalLoadConfig48;
    }
  } catch (error) {
    console.log(`${colors.red}Test Suite 48 setup failed: ${error.message}${colors.reset}`);
    console.log(error.stack);
    failed++;
  }

  console.log('');

  // ============================================================
  // Test Suite 49: shared renderer installation surface for both build skills
  // ============================================================
  console.log(`${colors.yellow}Test Suite 49: shared renderer installation surface for both build skills${colors.reset}\n`);

  let root49;
  try {
    root49 = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-build-auto-install-'));
    const { UI } = require('../tools/installer/ui');
    const partialConfig49 = await new UI().collectModuleConfigs(root49, ['core', 'bmm'], {
      yes: true,
      userName: 'E2E',
      communicationLanguage: 'English',
      documentOutputLanguage: 'English',
    });
    assert(
      partialConfig49.moduleConfigs.core.output_folder === '_bmad-output' &&
        partialConfig49.moduleConfigs.core.project_name === path.basename(root49),
      'partial noninteractive core options retain defaults for omitted values',
    );
    assert(
      partialConfig49.moduleConfigs.bmm.implementation_artifacts === '{project-root}/_bmad-output/implementation-artifacts' &&
        partialConfig49.moduleConfigs.bmm.planning_artifacts === '{project-root}/_bmad-output/planning-artifacts',
      'partial noninteractive core options resolve dependent module defaults',
    );

    const bmadDir49 = path.join(root49, '_bmad');
    await fs.ensureDir(path.join(bmadDir49, 'custom'));
    const paths49 = {
      srcDir: path.resolve(__dirname, '..'),
      bmadDir: bmadDir49,
      scriptsDir: path.join(bmadDir49, 'scripts'),
      customDir: path.join(bmadDir49, 'custom'),
    };
    const installer49 = new Installer();
    await installer49._installSharedScripts(paths49);
    const renderGitignore49 = path.join(bmadDir49, 'render', '.gitignore');
    const reinstall49 = new Installer();
    await reinstall49._installSharedScripts(paths49);
    assert(reinstall49.installedFiles.has(renderGitignore49), 'existing render gitignore remains installer-owned on update');

    const official49 = new OfficialModules();
    await official49.install('bmm', bmadDir49, null, {
      skipModuleInstaller: true,
      moduleConfig: {},
      silent: true,
    });
    await installer49.generateModuleConfigs(bmadDir49, { core: { communication_language: 'English' }, bmm: {} });

    const scripts49 = path.join(bmadDir49, 'scripts');
    const skill49 = path.join(bmadDir49, 'bmm', 'ship', 'bmad-build-auto');
    const skill49Build = path.join(bmadDir49, 'bmm', 'ship', 'bmad-build');
    assert(await fs.pathExists(path.join(scripts49, 'render_skill.py')), 'shared render_skill.py reaches installed _bmad/scripts');
    assert(await fs.pathExists(path.join(scripts49, 'config_utils.py')), 'shared config utility reaches installed _bmad/scripts');
    assert(!(await fs.pathExists(path.join(scripts49, 'tests'))), 'shared-script development tests are excluded from install');
    assert(!(await fs.pathExists(path.join(scripts49, '__pycache__'))), 'shared-script Python caches are excluded from install');
    assert(await fs.pathExists(path.join(skill49, 'SKILL.md')), 'build-auto entry reaches installed skill surface');
    const skillSource49 = await fs.readFile(path.join(skill49, 'SKILL.md'), 'utf8');
    assert(
      skillSource49.includes('uv run --no-cache "{project-root}/_bmad/scripts/render_skill.py"'),
      'build-auto avoids the user-level uv cache and lets script metadata select Python',
    );
    assert(!skillSource49.includes('uv run --python'), 'build-auto does not pin an exact Python series');
    assert(!(await fs.pathExists(path.join(skill49, 'render.toml'))), 'installed skill has no duplicate render contract');
    assert(!(await fs.pathExists(path.join(skill49, 'render.py'))), 'no skill-local renderer reaches installed build-auto');
    assert(await fs.pathExists(path.join(skill49, 'workflow.md')), 'build-auto workflow source reaches installed skill surface');
    assert(await fs.pathExists(path.join(skill49, 'step-04-review.md')), 'build-auto step sources reach installed skill surface');
    // Compare against build-auto's own shipped command rather than a second hardcoded
    // literal, so the two skills cannot drift apart while both still match this file.
    const fenced49 = skillSource49.match(/```bash\n([\s\S]*?)```/);
    assert(
      fenced49 !== null && fenced49[1].includes('render_skill.py'),
      'build-auto ships its renderer invocation as a fenced bash command',
      skillSource49,
    );
    const sharedInvocation49 = fenced49 === null ? '' : fenced49[1].trim();
    assert(await fs.pathExists(path.join(skill49Build, 'SKILL.md')), 'build entry reaches installed skill surface');
    const buildSource49 = await fs.readFile(path.join(skill49Build, 'SKILL.md'), 'utf8');
    assert(
      sharedInvocation49 !== '' && buildSource49.includes(sharedInvocation49),
      'build dispatches the same shared renderer invocation as build-auto',
      `build-auto ships: ${sharedInvocation49}\nbuild ships: ${buildSource49}`,
    );
    assert(!buildSource49.includes('uv run --python'), 'build does not pin an exact Python series');
    assert(!(await fs.pathExists(path.join(skill49Build, 'render.py'))), 'the retired skill-local renderer never reaches installed build');
    assert(!(await fs.pathExists(path.join(skill49Build, 'render.toml'))), 'installed build has no duplicate render contract');
    assert(await fs.pathExists(path.join(skill49Build, 'workflow.md')), 'build workflow source reaches installed skill surface');
    assert(await fs.pathExists(path.join(skill49Build, 'step-04-review.md')), 'build step sources reach installed skill surface');
    assert(
      (await fs.readFile(renderGitignore49, 'utf8')) === '*\n!.gitignore\n',
      'generated render snapshots are ignored by installed projects',
    );
    assert(!(await fs.pathExists(path.join(bmadDir49, 'render', 'config.yaml'))), 'render cache is excluded from module config generation');

    await fs.writeFile(
      path.join(bmadDir49, 'config.toml'),
      [
        '[core]',
        'communication_language = "English"',
        'document_output_language = "English"',
        '',
        '[modules.bmm]',
        'user_skill_level = "expert"',
        `planning_artifacts = ${JSON.stringify(path.join(root49, 'planning'))}`,
        `implementation_artifacts = ${JSON.stringify(path.join(root49, 'implementation'))}`,
        '',
      ].join('\n'),
      'utf8',
    );
    // The harness pins the interpreter to keep this scratch run deterministic; the shipped
    // SKILL.md command must not pin one, and test/test-build-auto-renderer.js executes that
    // unpinned form verbatim for both skills.
    const renderOptions49 = { encoding: 'utf8', timeout: 120_000 };
    const render49 = spawnSync(
      'uv',
      ['run', '--python', '3.11', path.join(scripts49, 'render_skill.py'), '--project-root', root49, '--skill', skill49],
      renderOptions49,
    );
    assert(
      !render49.error && typeof render49.stdout === 'string',
      'shared renderer is spawnable for the installed build-auto tree',
      String(render49.error || 'uv produced no stdout'),
    );
    const dispatch49 = (render49.stdout || '').trim().replace(/^read and follow /, '');
    assert(
      render49.status === 0 &&
        path.isAbsolute(dispatch49) &&
        dispatch49.includes(`${path.sep}render${path.sep}bmad-build-auto${path.sep}`) &&
        path.basename(dispatch49) === 'workflow.md' &&
        (await fs.pathExists(dispatch49)),
      'installer-produced build-auto tree renders and dispatches end to end',
      `${render49.stdout}${render49.stderr}`,
    );
    const render49Build = spawnSync(
      'uv',
      ['run', '--python', '3.11', path.join(scripts49, 'render_skill.py'), '--project-root', root49, '--skill', skill49Build],
      renderOptions49,
    );
    assert(
      !render49Build.error && typeof render49Build.stdout === 'string',
      'shared renderer is spawnable for the installed build tree',
      String(render49Build.error || 'uv produced no stdout'),
    );
    const dispatch49Build = (render49Build.stdout || '').trim().replace(/^read and follow /, '');
    assert(
      render49Build.status === 0 &&
        path.isAbsolute(dispatch49Build) &&
        dispatch49Build.includes(`${path.sep}render${path.sep}bmad-build${path.sep}`) &&
        path.basename(dispatch49Build) === 'workflow.md' &&
        (await fs.pathExists(dispatch49Build)),
      'installer-produced build tree renders and dispatches end to end',
      `${render49Build.stdout}${render49Build.stderr}`,
    );

    // A fresh clone has the installer's config.toml but no gitignored config.user.toml (#3016).
    const generator49 = new ManifestGenerator();
    generator49.updatedModules = ['core', 'bmm'];
    await generator49.writeCentralConfig(bmadDir49, partialConfig49.moduleConfigs);
    await fs.remove(path.join(bmadDir49, 'config.user.toml'));
    for (const skillDir of [skill49, skill49Build]) {
      const renderClone49 = spawnSync(
        'uv',
        ['run', '--python', '3.11', path.join(scripts49, 'render_skill.py'), '--project-root', root49, '--skill', skillDir],
        renderOptions49,
      );
      assert(
        renderClone49.status === 0 && !(renderClone49.stdout || '').startsWith('HALT'),
        `${path.basename(skillDir)} renders from config.toml alone when config.user.toml is absent`,
        `${renderClone49.stdout}${renderClone49.stderr}`,
      );
    }
    const resolveCustomization49 = spawnSync(
      'uv',
      [
        'run',
        '--python',
        '3.11',
        path.join(scripts49, 'resolve_customization.py'),
        '--project-root',
        root49,
        '--skill',
        skill49,
        '--key',
        'workflow',
      ],
      { encoding: 'utf8' },
    );
    assert(resolveCustomization49.status === 0, 'installed customization resolver executes successfully');
    assert(
      !(await fs.pathExists(path.join(scripts49, '__pycache__'))),
      'installed config utility suppresses bytecode caches for every importer',
    );
    const detected49 = await installer49.detectCustomFiles(bmadDir49, []);
    assert(
      !detected49.customFiles.some((file) => path.relative(bmadDir49, file).split(path.sep)[0] === 'render'),
      'generated render snapshots are excluded from custom-file preservation',
    );
  } catch (error) {
    console.log(`${colors.red}Test Suite 49 setup failed: ${error.message}${colors.reset}`);
    console.log(error.stack);
    failed++;
  } finally {
    if (root49) await fs.remove(root49).catch(() => {});
  }

  console.log('');

  // ============================================================
  // Test Suite 50: --set core.<key> reaches config collection
  // ============================================================
  console.log(`${colors.yellow}Test Suite 50: --set core.<key> reaches config collection${colors.reset}\n`);

  let root50;
  try {
    root50 = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-set-core-'));
    const { UI } = require('../tools/installer/ui');

    // core.output_folder is dependency-bearing: module artifact paths are built
    // from it during collection. Applying it only as a post-install TOML patch
    // left those paths on the default while core config claimed the override.
    const viaSet50 = await new UI().collectModuleConfigs(root50, ['core', 'bmm'], {
      yes: true,
      set: ['core.output_folder=generated'],
    });
    assert(viaSet50.moduleConfigs.core.output_folder === 'generated', '--set core.output_folder seeds the collected core config');
    assert(
      viaSet50.moduleConfigs.bmm.planning_artifacts === '{project-root}/generated/planning-artifacts' &&
        viaSet50.moduleConfigs.bmm.implementation_artifacts === '{project-root}/generated/implementation-artifacts',
      '--set core.output_folder resolves dependent module paths',
    );

    // The docs present --set core.<key> and the legacy shortcuts as equivalent,
    // so they must collect identically.
    const viaFlag50 = await new UI().collectModuleConfigs(root50, ['core', 'bmm'], {
      yes: true,
      outputFolder: 'generated',
    });
    assert(
      viaSet50.moduleConfigs.bmm.planning_artifacts === viaFlag50.moduleConfigs.bmm.planning_artifacts &&
        viaSet50.moduleConfigs.core.output_folder === viaFlag50.moduleConfigs.core.output_folder,
      '--set core.output_folder and --output-folder collect identically',
    );

    // Every core key seeds, not just the four with a legacy shortcut flag.
    // project_name has none, and module config.yaml files snapshot the core
    // values at generate time, so a key that misses collection leaves those
    // copies stale.
    const otherKeys50 = await new UI().collectModuleConfigs(root50, ['core', 'bmm'], {
      yes: true,
      set: ['core.user_name=Bob', 'core.project_name=Foo', 'bmm.user_skill_level=expert'],
    });
    assert(otherKeys50.moduleConfigs.core.user_name === 'Bob', '--set core.user_name seeds the collected core config');
    assert(
      otherKeys50.moduleConfigs.core.project_name === 'Foo',
      '--set core.project_name seeds the collected core config (no legacy shortcut flag exists for it)',
    );
    assert(otherKeys50.moduleConfigs.core.output_folder === '_bmad-output', 'core keys omitted from --set keep their headless defaults');
    assert(otherKeys50.setOverrides.bmm.user_skill_level === 'expert', 'non-core --set overrides still reach the post-install patch step');
  } catch (error) {
    console.log(`${colors.red}Test Suite 50 setup failed: ${error.message}${colors.reset}`);
    console.log(error.stack);
    failed++;
  } finally {
    if (root50) await fs.remove(root50).catch(() => {});
  }

  console.log('');

  // ============================================================
  // Test Suite 51: directory input resolution
  // ============================================================
  console.log(`${colors.yellow}Test Suite 51: directory input resolution${colors.reset}\n`);

  let root51;
  try {
    const { resolveDirectoryInput } = require('../tools/installer/prompts');

    root51 = await fs.mkdtemp(path.join(os.tmpdir(), 'bmad-dirprompt-'));
    const submitted51 = path.join(root51, 'workspace');
    assert(resolveDirectoryInput(submitted51) === submitted51, 'an absolute submitted path is returned unchanged');

    const cwd51 = path.join(root51, 'working-directory');
    const default51 = 'default-install';
    assert(
      resolveDirectoryInput('', { default: default51, cwd: cwd51 }) === path.resolve(cwd51, default51),
      'empty input resolves the default directory',
    );

    const relative51 = path.join('projects', 'bmad');
    assert(
      resolveDirectoryInput(relative51, { cwd: cwd51 }) === path.resolve(cwd51, relative51),
      'relative input resolves against the explicit working directory',
    );

    assert(resolveDirectoryInput('~', { cwd: cwd51 }) === os.homedir(), 'bare tilde input expands to the home directory');

    assert(
      resolveDirectoryInput('~/destination', { cwd: cwd51 }) === path.join(os.homedir(), 'destination'),
      'home-relative input expands below the home directory',
    );

    const newDestination51 = path.join(root51, 'missing-parent', 'destination');
    const resolvedDestination51 = resolveDirectoryInput(newDestination51, { cwd: cwd51 });
    assert(
      resolvedDestination51 === newDestination51 && !(await fs.pathExists(newDestination51)),
      'a nonexistent destination is normalized without being created',
    );
  } catch (error) {
    console.log(`${colors.red}Test Suite 51 setup failed: ${error.message}${colors.reset}`);
    console.log(error.stack);
    failed++;
  } finally {
    if (root51) await fs.remove(root51).catch(() => {});
  }

  console.log('');

  // ============================================================
  // Test Suite 52: module registry — order and WDS deprecation
  // ============================================================
  console.log(`${colors.yellow}Test Suite 52: module registry — order and WDS deprecation${colors.reset}\n`);

  try {
    const { ExternalModuleManager } = require('../tools/installer/modules/external-manager');
    const { UI } = require('../tools/installer/ui');
    const prompts = require('../tools/installer/prompts');
    const registry52 = await new ExternalModuleManager().listAvailable();

    // The picker renders built-in core/bmm first, then registry entries in
    // registry order, so the registry sequence is the display sequence.
    const activeOrder52 = registry52.filter((mod) => !mod.builtIn && !mod.deprecated).map((mod) => mod.code);
    assert(
      JSON.stringify(activeOrder52.slice(0, 4)) === JSON.stringify(['bmb', 'cis', 'tea', 'bmad-loop']),
      'registry lists bmb, cis, tea, bmad-loop in that order (bmm is built-in and precedes them)',
      `got: ${activeOrder52.join(', ')}`,
    );

    const wds52 = registry52.find((mod) => mod.code === 'wds');
    assert(wds52 !== undefined, 'wds stays in the registry so existing installs still resolve a source');
    assert(wds52 && wds52.deprecated === true, 'wds is marked deprecated');
    assert(wds52 && wds52.defaultSelected === false, 'wds is never selected by default');
    assert(
      wds52 && /no longer receiving updates/i.test(wds52.deprecationMessage || ''),
      'wds deprecation message states it is not receiving updates',
    );
    assert(wds52 && /bmm/i.test(wds52.deprecationMessage || ''), 'wds deprecation message points at bmm as the replacement');
    assert(
      wds52 && Boolean(wds52.url) && Boolean(wds52.moduleDefinition),
      'wds keeps its source so an installed copy can still be updated',
    );

    // Picker visibility: hidden for new users, visible for existing installs.
    // Mirrors the filter in UI._selectOfficialModules.
    const visibleFor52 = (installed) =>
      registry52.filter((mod) => !mod.builtIn && (!mod.deprecated || installed.has(mod.code))).map((mod) => mod.code);
    assert(!visibleFor52(new Set()).includes('wds'), 'wds is hidden from the picker on a fresh install');
    assert(visibleFor52(new Set(['wds'])).includes('wds'), 'wds stays visible in the picker when already installed');

    // Deprecation notice reaches the non-interactive paths.
    const warnings52 = [];
    const originalWarn52 = prompts.log.warn;
    prompts.log.warn = async (message) => warnings52.push(message);
    let warned52;
    try {
      warned52 = await new UI()._warnDeprecatedModules(['core', 'bmm', 'wds']);
    } finally {
      prompts.log.warn = originalWarn52;
    }
    assert(warned52.includes('wds'), '_warnDeprecatedModules reports wds when it is part of the selection');
    assert(
      warnings52.some((message) => message.includes('wds') && /no longer receiving updates/i.test(message)),
      'the wds deprecation notice is logged for --modules / --yes installs',
    );

    const warnedClean52 = await new UI()._warnDeprecatedModules(['core', 'bmm', 'bmb']);
    assert(warnedClean52.length === 0, 'no deprecation notice for a selection of supported modules');

    // core is a dependency of every module — it is never offered as a row,
    // but it is always part of the result.
    const originalOfficial52 = OfficialModules.prototype.listAvailable;
    const originalExternal52 = ExternalModuleManager.prototype.listAvailable;
    const originalAutocomplete52 = prompts.autocompleteMultiselect;
    const originalSpinner52 = prompts.spinner;
    const originalMessage52 = prompts.log.message;

    let pickerOptions52 = [];
    let pickerRequired52;
    let pickerLocked52;
    let summary52 = '';
    OfficialModules.prototype.listAvailable = async () => ({
      modules: [
        { id: 'core', name: 'BMad Core Module', description: 'always installed', defaultSelected: true },
        { id: 'bmm', name: 'BMad Method', description: 'the method', defaultSelected: true },
      ],
    });
    ExternalModuleManager.prototype.listAvailable = async () => [];
    prompts.spinner = async () => ({ start() {}, stop() {}, error() {} });
    prompts.log.message = async (message) => {
      summary52 = message;
    };

    try {
      prompts.autocompleteMultiselect = async (opts) => {
        pickerOptions52 = opts.options.map((opt) => opt.value);
        pickerRequired52 = opts.required;
        pickerLocked52 = opts.lockedValues;
        return ['bmm'];
      };
      const picked52 = await new UI()._selectOfficialModules(new Set(), new Map(), null);

      assert(!pickerOptions52.includes('core'), 'core is not shown as a row in the official module picker');
      assert(pickerOptions52.includes('bmm'), 'other built-in modules are still shown in the picker');
      assert(pickerLocked52 === undefined, 'no locked always-on row remains in the picker');
      assert(picked52.includes('core'), 'core is still returned from the picker so it always installs');
      assert(picked52.includes('bmm'), 'the user selection is preserved alongside core');
      assert(!summary52.includes('BMad Core Module'), 'the selection summary does not list core');

      // Selecting nothing is a valid core-only install, not a validation error.
      prompts.autocompleteMultiselect = async (opts) => {
        pickerRequired52 = opts.required;
        return [];
      };
      const coreOnly52 = await new UI()._selectOfficialModules(new Set(), new Map(), null);
      assert(pickerRequired52 === false, 'the picker no longer requires a selection now that core is implicit');
      assert(JSON.stringify(coreOnly52) === JSON.stringify(['core']), 'selecting nothing yields a core-only install');
    } finally {
      OfficialModules.prototype.listAvailable = originalOfficial52;
      ExternalModuleManager.prototype.listAvailable = originalExternal52;
      prompts.autocompleteMultiselect = originalAutocomplete52;
      prompts.spinner = originalSpinner52;
      prompts.log.message = originalMessage52;
    }
  } catch (error) {
    console.log(`${colors.red}Test Suite 52 setup failed: ${error.message}${colors.reset}`);
    console.log(error.stack);
    failed++;
  }

  console.log('');

  // ============================================================
  // Summary
  // ============================================================
  console.log(`${colors.cyan}========================================`);
  console.log('Test Results:');
  console.log(`  Passed: ${colors.green}${passed}${colors.reset}`);
  console.log(`  Failed: ${colors.red}${failed}${colors.reset}`);
  console.log(`========================================${colors.reset}\n`);

  if (failed === 0) {
    console.log(`${colors.green}✨ All installation component tests passed!${colors.reset}\n`);
    process.exit(0);
  } else {
    console.log(`${colors.red}❌ Some installation component tests failed${colors.reset}\n`);
    process.exit(1);
  }
}

// Run tests
runTests().catch((error) => {
  console.error(`${colors.red}Test runner failed:${colors.reset}`, error.message);
  console.error(error.stack);
  process.exit(1);
});
