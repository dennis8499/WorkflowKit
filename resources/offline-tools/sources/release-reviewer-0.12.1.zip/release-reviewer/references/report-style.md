# 上版檢查報告風格

報告是入口 Repo/review-reports 內的一份繁體中文 Markdown。首行為 `**產生時判斷**｜靜態檢查狀態。結論摘要`，接續 P0／P1 程式問題數量，以及阻擋、合併衝突、待確認、缺口數；合併衝突計入阻擋，不列為程式問題等級。二級章節依序為：

1. `比較資訊`：Repo、本機路徑、基礎／比較分支的輸入、實際 ref、短 SHA 表格，合併方向、差異起點、最終受審來源與版本、快照擷取時間及適用版本。
2. `問題`：保留 R-*／M-001 編號，程式風險標題為 `### R-001｜[P1] 問題名稱`。每項固定六個粗體區塊，各自另起段落：`問題描述`、`重現原因`、`預期結果`、`實際結果`、`證據`、`建議改善方式`。問題描述交代影響、邊界與上版阻擋依據；重現原因交代操作、技術觸發條件，推導情境只標一次「依程式推導，未實際重現。」。預期及實際結果由審查者依證據填寫。證據包括技術說明、Repo／路徑／行號、來源、完整固定 SHA、內容 SHA-256 與安全程式碼區塊；設定值與認證內容省略。建議提供處理方向及工程修正；同一區塊內的相同段落只列一次。
3. `範圍與限制`：已提交差異範圍、缺口、未查環境、已執行／未執行檢查；新增部署依賴與可編輯 Checklist 展開置於本節，依賴提醒與程式阻擋分開。
4. `下一步`：列後續處理；沒有項目時明說沒有另外列出的下一步。
5. `技術審查紀錄`：置於報告末尾的 `<details>`，保留擷取時間、固定 SHA、來源、Diff 起點、搜尋 ID／命中數、關聯判斷、功能鏈、覆蓋及執行紀錄。

沒有問題時明說已檢查範圍未發現有證據的直接阻擋，仍交代限制及待確認部署條件。新草稿使用 `engineering-review/v2`，完整提供 `expected`、`actual`、`scenario` 與 `technical_details`；歷史 v1／無 layout 草稿缺少結果欄位時顯示「未提供」，保留已驗證結論。

進度與最終回答採結果先行，簡單答覆一至三句；最後給唯一報告連結與重要阻擋／缺口。只有使用者明確要求或選取 output-style，才載入該 Skill 與本次必要參考來調整行文密度；固定章節、Checklist、證據及產生時判斷仍依本契約。
# Engineering v2 layout in 0.8.0

New `engineering-review/v2` drafts render directly as `# 上版檢查: {Repo}` followed by exactly five H2 sections: 審查結論、問題總攬、問題詳情（工程師參考）、範圍與限制、技術審查紀錄（工程師參考）. The conclusion includes the entry Repo, base/head branch names, eight-character SHAs and merge direction. The overview links confirmed blockers to their details. Keep the existing six bold risk blocks, fixed evidence and sensitive-content handling.

Place detailed comparison data and complete SHAs in the technical section. Keep next steps, necessary gaps, new deployment dependencies and the editable Checklist open under 範圍與限制; retain the collapsible technical evidence. Layout v1 and drafts without a layout retain the historical sections documented below. The helper renders the final layout, so publication needs no manual section rewriting.
