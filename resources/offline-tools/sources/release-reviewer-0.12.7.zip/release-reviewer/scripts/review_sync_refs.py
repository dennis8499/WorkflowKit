"""Recover request-owned Git refs after an interrupted remote capture."""

import hashlib
import json
import os
from pathlib import Path
import re
from uuid import uuid4

import git_network_lease
import git_support as git
import review_coordinator as coordination


SCHEMA = "ReleaseReviewSyncRefs/v1"
OID = re.compile(r"[a-f0-9]{40}(?:[a-f0-9]{24})?")


def journal_root():
    root = coordination.plain(git_network_lease.runtime_root() / "release-reviewer-refs").resolve()
    if any((parent / ".git").exists() for parent in (root, *root.parents)):
        raise git.ReviewContextError("ReleaseReviewer 的 Git ref 紀錄必須位於 Repo 外。")
    return root


class PrivateRefs:
    def __init__(self, repo, request_id=None):
        status, output, error = git.run_git_capture(repo, ["rev-parse", "--path-format=absolute", "--git-common-dir"])
        if status or not Path(output.strip()).is_absolute():
            raise git.ReviewContextError(f"無法核對 ReleaseReviewer 的 common Git 目錄：{error.strip()}")
        common = Path(output.strip()).resolve(strict=True)
        info = common.stat()
        if not common.is_dir() or not info.st_ino:
            raise git.ReviewContextError("無法確認 ReleaseReviewer 的 common Git 目錄身分。")
        self.repo = repo
        self.identity = [os.path.normcase(str(common)), info.st_dev, info.st_ino]
        key = hashlib.sha256(json.dumps(self.identity, separators=(",", ":")).encode()).hexdigest()[:24]
        self.directory = journal_root() / key
        self.identifier = uuid4().hex
        self.namespace = f"refs/release-reviewer-sync/{self.identifier}"
        self.path = self.directory / (self.identifier + ".json")
        self.owner = None
        self.record = {"schema": SCHEMA, "repository": self.identity, "request_id": request_id,
                       "fetching": False, "refs": {}}

    def _write(self, **fields):
        record = {**self.record, **fields}
        coordination.atomic(self.path, record)
        self.record = record

    def begin(self, refs):
        if self.owner is None:
            self.owner = coordination.FileLock(self.path.with_suffix(".lock")).acquire()
            seen = self._observe(self.namespace, supervised=False)
            if seen or self.path.exists():
                raise git.ReviewContextError("ReleaseReviewer 本次同步的暫存 ref 空間已被使用。")
        self._write(fetching=True, refs={**self.record["refs"], **dict.fromkeys(refs)})

    def settled(self):
        # The supervised fetch has returned, including release of its admission lease.
        self._write(fetching=False)

    def pin(self, refs):
        self._write(refs={**self.record["refs"], **refs})

    def _observe(self, namespace, *, supervised):
        args = ["for-each-ref", "--format=%(refname)%00%(objectname)%00%(symref)", namespace + "/"]
        status, output, error = git.run_git_capture(self.repo, args, supervised=supervised)
        if status:
            raise git.GitCommandError(args, status, error)
        return {ref: (sha, symbolic) for ref, sha, symbolic in (row.split("\0") for row in output.splitlines())}

    def _clean(self, path, record):
        refs = record["refs"]
        namespace = f"refs/release-reviewer-sync/{path.stem}"
        # A dead Python owner alone cannot prove that its Git child has stopped.
        # Acquire the same supervised Git lease for the observation when that proof is missing.
        observed = self._observe(namespace, supervised=record["fetching"])
        remaining = dict(refs)
        for ref, expected in refs.items():
            current = observed.get(ref)
            if current is None:
                # for-each-ref can omit a dangling symbolic ref.
                status, _, _ = git.run_git_capture(self.repo, ["symbolic-ref", "--quiet", ref])
                if status == 1:
                    del remaining[ref]
                continue
            sha, symbolic = current
            if symbolic or not OID.fullmatch(sha) or expected is not None and expected != sha:
                continue
            status, _, _ = git.run_git_capture(self.repo, ["update-ref", "--no-deref", "-d", ref, sha])
            if status == 0:
                del remaining[ref]
        if remaining:
            coordination.atomic(path, {**record, "fetching": False, "refs": remaining})
            return False
        path.unlink(missing_ok=True)
        return True

    def _valid(self, path, record):
        prefix = rf"refs/release-reviewer-sync/{path.stem}/[0-9]+"
        return (isinstance(record, dict) and record.get("schema") == SCHEMA and
                record.get("repository") == self.identity and type(record.get("fetching")) is bool and
                isinstance(record.get("refs"), dict) and all(
                    re.fullmatch(prefix, ref) and (sha is None or isinstance(sha, str) and OID.fullmatch(sha))
                    for ref, sha in record["refs"].items()))

    def recover(self, request_id=None):
        if not coordination.plain(self.directory).is_dir():
            return True
        clean = True
        for path in sorted(self.directory.glob("*.json")):
            if not coordination.IDENTIFIER.fullmatch(path.stem) or path == self.path:
                continue
            lock = coordination.FileLock(path.with_suffix(".lock"))
            try:
                if not lock.acquire(blocking=False):
                    continue
                record = coordination.read_json(path)
                if request_id is not None and (not isinstance(record, dict) or record.get("request_id") != request_id):
                    continue
                if not self._valid(path, record) or not self._clean(path, record):
                    clean = False
            except FileNotFoundError:
                continue
            except (OSError, ValueError, git.ReviewContextError):
                clean = False
            finally:
                self._release(lock, path)
        return clean

    @staticmethod
    def _release(lock, path):
        lock.release()
        if not path.exists():
            try:
                lock.path.unlink(missing_ok=True)
            except OSError:
                pass  # A concurrent reaper can briefly retain the lock handle.

    def close(self):
        if self.owner is None:
            return True
        try:
            return not self.record["refs"] or self._clean(self.path, self.record)
        except (OSError, ValueError, git.ReviewContextError):
            return False
        finally:
            self._release(self.owner, self.path)
            self.owner = None


def recover_request(repo, request_id):
    if not journal_root().is_dir():
        return True
    return PrivateRefs(repo).recover(request_id)
