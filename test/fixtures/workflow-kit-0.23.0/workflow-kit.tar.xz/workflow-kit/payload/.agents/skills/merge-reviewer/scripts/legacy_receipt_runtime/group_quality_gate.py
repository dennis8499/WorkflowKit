"""GitLab Workspace Group v2/v3/v4 quality contracts, snapshots, and delivery gates."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
from pathlib import Path, PurePosixPath
from urllib.parse import urlsplit, urlunsplit
from quality_gate import InvalidEvidence, PLAN_VERSION_PATTERN, RESULT_STATUSES, WORK_ID_PATTERN, _unique_json_object, canonical_relative, cited_claims, cited_file, digest_entries, git, line, read_json, valid_allowed_path, validate_recorded_checks, workflow_fields
from group_workspace import InvalidWorkspace, fingerprint as skills_fingerprint
GROUP_SHA_PATTERN = re.compile('^[0-9a-f]{40,64}$')

def within_group(group_root: Path, relative: object) -> Path:
    group_root = group_root.resolve()
    canonical = canonical_relative(relative)
    path = (group_root / canonical).resolve()
    if not path.is_relative_to(group_root) or path == group_root:
        raise InvalidEvidence(f'path escapes Group root: {relative}')
    return path

def group_evidence_file(group_root: Path, work_id: str, relative: object) -> Path:
    path = within_group(group_root, relative)
    evidence_root = (group_root / 'docs' / 'work' / work_id / 'evidence').resolve()
    if not path.is_relative_to(evidence_root) or path == evidence_root:
        raise InvalidEvidence(f'source must be in this Work ID evidence directory: {relative}')
    return path

def group_record_entries(group_root: Path, work_id: str, records: set[str]) -> list[dict[str, str]]:
    group_root = group_root.resolve()
    work = group_root / 'docs' / 'work' / work_id
    workflow_relative = f'docs/work/{work_id}/workflow.md'
    entries: list[dict[str, str]] = []
    for path in sorted(work.rglob('*')):
        if not path.is_file():
            continue
        resolved = path.resolve()
        if not resolved.is_relative_to(group_root):
            raise InvalidEvidence(f'Group work record path escapes root: {path}')
        relative = path.relative_to(group_root).as_posix()
        if relative == workflow_relative or relative in records:
            continue
        entries.append({'path': f'@group/{relative}', 'mode': '100755' if path.stat().st_mode & 73 else '100644', 'content': hashlib.sha256(path.read_bytes()).hexdigest()})
    return entries

def group_allowed_path(relative: str, allowed: list[str]) -> bool:
    return any((relative.startswith(rule) if rule.endswith('/') else relative == rule for rule in allowed))

def group_commit_entries(repo: Path, commit: str) -> list[dict[str, str]]:
    raw_entries = git(repo, 'ls-tree', '-r', '-z', '--full-tree', commit)
    entries: list[dict[str, str]] = []
    for raw in raw_entries.split(b'\x00'):
        if not raw:
            continue
        metadata, raw_path = raw.split(b'\t', maxsplit=1)
        mode, _kind, object_id = metadata.decode('ascii').split()
        relative = canonical_relative(raw_path.decode('utf-8'))
        entries.append({'path': relative, 'mode': mode, 'content': object_id})
    return sorted(entries, key=lambda item: item['path'])

def validate_delivery_gate_receipt(group_root: Path, work_id: str, fields: dict[str, str], contract: dict, records: set[str], delivery: dict, digest: str, approved_repo_snapshots: dict, reasons: list[str]) -> str | None:
    receipt = delivery.get('delivery_gate')
    if not isinstance(receipt, dict) or receipt.get('schema') != 'megin-delivery-gate-receipt/v1' or receipt.get('status') != 'passed' or (receipt.get('snapshot') != digest):
        reasons.append('delivery record lacks a versioned passed delivery-gate receipt')
        return None
    source = receipt.get('source')
    source_path = source.get('path') if isinstance(source, dict) else None
    source_digest = source.get('sha256') if isinstance(source, dict) else None
    expected_source = canonical_relative(fields['quality_ref'])
    if source_path != expected_source or source_path not in records or (not isinstance(source_digest, str)) or (not re.fullmatch('[0-9a-f]{64}', source_digest)):
        reasons.append('delivery-gate receipt source reference is invalid')
    else:
        try:
            source_file = group_evidence_file(group_root, work_id, source_path)
            actual_source_digest = hashlib.sha256(source_file.read_bytes()).hexdigest()
            if actual_source_digest != source_digest:
                reasons.append('delivery-gate receipt source digest differs from quality evidence')
        except (InvalidEvidence, OSError) as exc:
            reasons.append(f'delivery-gate receipt source cannot be verified: {exc}')
    gate_result = receipt.get('result')
    stdout = gate_result.get('stdout') if isinstance(gate_result, dict) else None
    exit_code = gate_result.get('exit_code') if isinstance(gate_result, dict) else None
    result_digest = receipt.get('result_sha256')
    if type(exit_code) is not int or exit_code != 0 or (not isinstance(stdout, str)) or (not stdout) or (not isinstance(result_digest, str)) or (not re.fullmatch('[0-9a-f]{64}', result_digest)):
        reasons.append('delivery-gate receipt does not contain raw output and a successful exit code')
        return None
    actual_result_digest = hashlib.sha256(stdout.encode('utf-8')).hexdigest()
    if actual_result_digest != result_digest:
        reasons.append('raw delivery gate result digest is invalid')
        return actual_result_digest
    try:
        result = json.loads(stdout, object_pairs_hook=_unique_json_object)
    except (UnicodeError, json.JSONDecodeError, InvalidEvidence) as exc:
        reasons.append(f'raw delivery gate result is not valid JSON: {exc}')
        return actual_result_digest
    if not isinstance(result, dict):
        reasons.append('raw delivery gate result must be an object')
        return actual_result_digest
    if result.get('gate') != 'delivery' or result.get('ok') is not True or result.get('snapshot') != digest or (result.get('delivery_mode') != contract.get('delivery_mode')) or (result.get('reasons') != []):
        reasons.append('raw delivery gate result is not a passing result for the accepted snapshot')
    expected_paths = {item['repo_path'] for item in contract['repositories']}
    raw_repositories = result.get('repositories')
    if not isinstance(raw_repositories, dict) or set(raw_repositories) != expected_paths:
        reasons.append('raw delivery gate result Repo snapshots are missing or duplicated')
    else:
        for repo_path, repo_snapshot in approved_repo_snapshots.items():
            raw_repo = raw_repositories.get(repo_path)
            if not isinstance(repo_snapshot, dict) or not isinstance(raw_repo, dict) or raw_repo.get('product_sha256') != repo_snapshot.get('product_sha256') or (raw_repo.get('path_count') != repo_snapshot.get('path_count')):
                reasons.append(f'{repo_path}: raw delivery gate Repo snapshot differs from accepted content')
    raw_remote_bases = result.get('remote_bases')
    if not isinstance(raw_remote_bases, dict) or set(raw_remote_bases) != expected_paths:
        reasons.append('raw delivery gate remote-base checks are missing or duplicated')
    else:
        for repository in contract['repositories']:
            repo_path = repository['repo_path']
            remote_check = raw_remote_bases.get(repo_path)
            expected_ref = f"refs/heads/{repository['base_branch']}"
            if not isinstance(remote_check, dict) or remote_check.get('status') != 'passed' or remote_check.get('remote') != repository['remote'] or (remote_check.get('ref') != expected_ref) or (remote_check.get('expected_commit') != repository['base_commit']) or (remote_check.get('observed_commit') != repository['base_commit']):
                reasons.append(f'{repo_path}: raw delivery gate does not prove the approved remote base')
    raw_staged = result.get('staged_repositories')
    if not isinstance(raw_staged, dict) or set(raw_staged) != expected_paths:
        reasons.append('raw delivery gate staged Repo results are missing or duplicated')
    else:
        approved_repositories = {item['repo_path']: item for item in contract['repositories']}
        for repo_path, repo_snapshot in approved_repo_snapshots.items():
            staged = raw_staged.get(repo_path)
            if not isinstance(repo_snapshot, dict) or not isinstance(staged, dict) or staged.get('staged_snapshot') != repo_snapshot.get('product_sha256'):
                reasons.append(f'{repo_path}: raw delivery gate staged snapshot differs from accepted content')
                continue
            staged_paths = staged.get('staged_paths')
            if not isinstance(staged_paths, list) or any((not isinstance(path, str) for path in staged_paths)):
                reasons.append(f'{repo_path}: raw delivery gate staged paths are invalid')
                continue
            if len(staged_paths) != len(set(staged_paths)):
                reasons.append(f'{repo_path}: raw delivery gate staged paths contain duplicates')
                continue
            for staged_path in staged_paths:
                try:
                    canonical = canonical_relative(staged_path)
                except InvalidEvidence:
                    reasons.append(f'{repo_path}: raw delivery gate staged path is not canonical')
                    continue
                if canonical != staged_path or not group_allowed_path(staged_path, approved_repositories[repo_path]['allowed_paths']):
                    reasons.append(f'{repo_path}: raw delivery gate staged path is outside approved scope')
    return actual_result_digest

def validate_optional_check_bindings(root, work_id, records, contract, evidence, current, reasons):
    if not contract.get('verification_inputs'):
        return
    digest = current['verification_inputs_sha256']
    identifiers = {identifier for item in current['verification_inputs'] for identifier in item['check_ids']}
    results = {item.get('id'): item for item in evidence.get('checks', []) if isinstance(item, dict)}
    for identifier in identifiers:
        result = results.get(identifier, {})
        if result.get('verification_inputs_sha256') != digest:
            reasons.append(f'{identifier}: fixed verification input binding missing or stale')
        cited_claims(root, work_id, records, result.get('output'), identifier + ' fixed inputs', reasons, {'verification_inputs': 'Verification inputs SHA-256: ' + digest}, require_locator=True)
