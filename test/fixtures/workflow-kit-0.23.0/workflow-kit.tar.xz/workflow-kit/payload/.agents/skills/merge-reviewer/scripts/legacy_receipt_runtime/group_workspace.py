"""Read-only Group configuration and reproducible Skills fingerprint, plus explicit workspace ownership."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
import re
import subprocess
import stat
import sys
import tempfile
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from validate_skills import EXPECTED
WORK_ID_PATTERN = re.compile('work-[0-9]{8}-[a-z0-9-]+\\Z')
REMOTE_PATTERN = re.compile('[A-Za-z0-9][A-Za-z0-9._-]*\\Z')
EXCLUSIVE_PHASES = {'implementation', 'review', 'verification', 'acceptance', 'delivery'}
ACTIVE_STATUSES = {'active', 'awaiting_user', 'awaiting_review', 'blocked', 'needs_revision'}
WORKFLOW_PHASES = {'requirements', 'planning', 'approval', 'implementation', 'review', 'verification', 'acceptance', 'delivery'}
WORKFLOW_STATUSES = ACTIVE_STATUSES | {'complete'}

class InvalidWorkspace(Exception):
    """The Group path, setting, fingerprint, or lock record is invalid."""

def git(repo: Path, *arguments: str) -> str:
    result = subprocess.run(['git', '-C', str(repo), *arguments], text=True, encoding='utf-8', errors='replace', capture_output=True, check=False)
    if result.returncode:
        raise InvalidWorkspace(result.stderr.strip() or 'Git command failed')
    return result.stdout.strip()

def canonical_child(value: object) -> str:
    if not isinstance(value, str) or not value or '\\' in value or (value in ('.', '..')) or (':' in value):
        raise InvalidWorkspace(f'repository must be one direct-child name: {value!r}')
    child = PurePosixPath(value)
    if child.is_absolute() or child.as_posix() != value or len(child.parts) != 1:
        raise InvalidWorkspace(f'repository must be one direct-child name: {value!r}')
    return value

def validate_repo(group_root: Path, repo_path: object) -> tuple[str, Path]:
    group_root = group_root.resolve()
    name = canonical_child(repo_path)
    lexical = group_root / name
    if lexical.is_symlink() or (lexical.exists() and bool(getattr(lexical.lstat(), 'st_file_attributes', 0) & getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0))):
        raise InvalidWorkspace(f'repository path must not be a symlink or junction: {name}')
    repo = lexical.resolve()
    if repo.parent != group_root or not repo.is_dir():
        raise InvalidWorkspace(f'repository must be an existing direct child: {name}')
    if Path(git(repo, 'rev-parse', '--show-toplevel')).resolve() != repo:
        raise InvalidWorkspace(f'repository path is not its Git root: {name}')
    return (name, repo)

def _skill_files(group_root: Path) -> list[Path]:
    root = group_root / '.agents' / 'skills'
    if root.is_symlink() or not root.is_dir():
        raise InvalidWorkspace('Group .agents/skills directory is missing or unsafe')
    result: list[Path] = []
    for name in EXPECTED:
        skill = root / name
        if skill.is_symlink() or not skill.is_dir():
            raise InvalidWorkspace(f'required Megin Skill is missing or unsafe: {name}')
        for path in sorted(skill.rglob('*'), key=lambda item: item.relative_to(root).as_posix()):
            if '__pycache__' in path.parts or path.suffix.lower() == '.pyc':
                continue
            resolved = path.resolve()
            if not resolved.is_relative_to(root) or path.is_symlink():
                raise InvalidWorkspace(f'Skill resource escapes its directory: {path}')
            if path.is_file():
                result.append(path)
    return sorted(result, key=lambda item: item.relative_to(root).as_posix())

def fingerprint(group_root: Path) -> dict[str, object]:
    root = group_root.resolve() / '.agents' / 'skills'
    entries: list[dict[str, object]] = []
    for path in _skill_files(group_root.resolve()):
        raw = path.read_bytes()
        entries.append({'path': f'.agents/skills/{path.relative_to(root).as_posix()}', 'size': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
    encoded = json.dumps(entries, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode('utf-8')
    return {'schema': 'megin-skills-fingerprint/v1', 'algorithm': 'sha256', 'sha256': hashlib.sha256(encoded).hexdigest(), 'skill_count': len(EXPECTED), 'file_count': len(entries), 'files': entries}
