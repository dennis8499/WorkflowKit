"""Read-only structural checks for a single-repository Megin workflow."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
from pathlib import Path, PurePosixPath
sys.dont_write_bytecode = True
WORK_ID_PATTERN = re.compile('work-[0-9]{8}-[a-z0-9-]+\\Z')
PLAN_VERSION_PATTERN = re.compile('plan-[a-z0-9-]+\\Z')
RESULT_STATUSES = {'passed', 'failed', 'blocked', 'not_run'}

class InvalidEvidence(Exception):
    """An input cannot be interpreted as this version of the evidence format."""

def git(repo: Path, *arguments: str) -> bytes:
    result = subprocess.run(['git', '-C', str(repo), *arguments], capture_output=True, check=False)
    if result.returncode:
        raise InvalidEvidence(result.stderr.decode('utf-8', errors='replace').strip())
    return result.stdout

def line(repo: Path, *arguments: str) -> str:
    return git(repo, *arguments).decode('utf-8', errors='replace').strip()

def read_json(path: Path) -> dict:
    try:
        value = json.loads(path.read_text(encoding='utf-8'), object_pairs_hook=_unique_json_object)
    except (OSError, UnicodeError, json.JSONDecodeError, ValueError) as exc:
        raise InvalidEvidence(f'cannot read JSON {path}: {exc}') from exc
    if not isinstance(value, dict):
        raise InvalidEvidence(f'expected JSON object: {path}')
    return value

def _unique_json_object(pairs: list[tuple[str, object]]) -> dict:
    value: dict[str, object] = {}
    for key, item in pairs:
        if key in value:
            raise ValueError(f'duplicate JSON key: {key}')
        value[key] = item
    return value

def workflow_fields(path: Path) -> dict[str, str]:
    try:
        contents = path.read_text(encoding='utf-8')
    except OSError as exc:
        raise InvalidEvidence(f'cannot read workflow: {exc}') from exc
    header = contents.split('\n## ', maxsplit=1)[0]
    fields: dict[str, str] = {}
    for match in re.finditer('(?m)^- ([a-z0-9_]+): (.+)$', header):
        key, value = match.groups()
        if key in fields:
            raise InvalidEvidence(f'duplicate workflow header: {key}')
        fields[key] = value
    return fields

def canonical_relative(relative: object) -> str:
    if not isinstance(relative, str) or not relative or '\\' in relative:
        raise InvalidEvidence(f'invalid relative path: {relative!r}')
    pure = PurePosixPath(relative)
    if pure.is_absolute() or pure.as_posix() != relative or any((part in ('', '.', '..') for part in pure.parts)) or (pure.parts and ':' in pure.parts[0]):
        raise InvalidEvidence(f'invalid relative path: {relative!r}')
    return relative

def within_repo(repo: Path, relative: object) -> Path:
    canonical = canonical_relative(relative)
    path = (repo / canonical).resolve()
    if not path.is_relative_to(repo) or path == repo:
        raise InvalidEvidence(f'path escapes repository: {relative}')
    return path

def evidence_file(repo: Path, work_id: str, relative: object) -> Path:
    path = within_repo(repo, relative)
    root = (repo / 'docs' / 'work' / work_id / 'evidence').resolve()
    if not path.is_relative_to(root) or path == root:
        raise InvalidEvidence(f"source must be in this Work ID's evidence directory: {relative}")
    return path

def valid_allowed_path(value: object) -> bool:
    if not isinstance(value, str) or not value:
        return False
    candidate = value[:-1] if value.endswith('/') else value
    try:
        return canonical_relative(candidate) == candidate
    except InvalidEvidence:
        return False

def digest_entries(entries: list[dict[str, str]]) -> str:
    encoded = json.dumps(entries, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
    return hashlib.sha256(encoded.encode('utf-8')).hexdigest()

def cited_file(repo: Path, work_id: str, records: set[str], value: object, label: str, reasons: list[str], require_locator: bool=False) -> list[str] | None:
    if not isinstance(value, dict):
        reasons.append(f'{label}: missing source reference')
        return None
    relative, expected = (value.get('path'), value.get('sha256'))
    if not isinstance(relative, str) or not isinstance(expected, str):
        reasons.append(f'{label}: incomplete source reference')
        return None
    path = evidence_file(repo, work_id, relative)
    if relative not in records:
        raise InvalidEvidence(f'{label}: source is not an approved process record')
    if not path.is_file():
        reasons.append(f'{label}: source missing or digest changed')
        return None
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != expected:
        reasons.append(f'{label}: source missing or digest changed')
        return None
    lines = raw.decode('utf-8', errors='replace').splitlines()
    if require_locator:
        number, claimed = (value.get('line'), value.get('text'))
        if type(number) is not int or number < 1 or number > len(lines) or (not isinstance(claimed, str)) or (lines[number - 1] != claimed):
            reasons.append(f'{label}: raw output locator missing or changed')
    return lines

def cited_claims(repo: Path, work_id: str, records: set[str], value: object, label: str, reasons: list[str], expected: dict[str, str], require_locator: bool=False) -> None:
    lines = cited_file(repo, work_id, records, value, label, reasons, require_locator)
    if lines is None or not isinstance(value, dict):
        return
    claims = value.get('claims')
    if not isinstance(claims, dict):
        reasons.append(f'{label}: raw claim locators missing')
        return
    for name, expected_text in expected.items():
        locator = claims.get(name)
        if not isinstance(locator, dict):
            reasons.append(f'{label}: {name} claim locator missing')
            continue
        number, claimed = (locator.get('line'), locator.get('text'))
        if type(number) is not int or number < 1 or number > len(lines) or (claimed != expected_text) or (lines[number - 1] != expected_text):
            reasons.append(f'{label}: raw {name} claim differs from structured evidence')

def validate_recorded_checks(repo: Path, work_id: str, records: set[str], obligations: list[dict], evidence: dict, digest: str, reasons: list[str], require_pass: bool) -> None:
    recorded = evidence.get('checks')
    valid_recorded = isinstance(recorded, list) and all((isinstance(entry, dict) and isinstance(entry.get('id'), str) for entry in recorded))
    by_id = {entry['id']: entry for entry in recorded} if valid_recorded else {}
    if not valid_recorded or len(by_id) != len(recorded):
        reasons.append('duplicate or invalid recorded check IDs')
    approved_ids = {entry['id'] for entry in obligations}
    for extra in sorted(set(by_id) - approved_ids):
        reasons.append(f'{extra}: result is not an approved check')
    for obligation in obligations:
        identifier = obligation['id']
        result = by_id.get(identifier)
        if not isinstance(result, dict):
            reasons.append(f'{identifier}: required result missing')
            continue
        status, exit_code = (result.get('status'), result.get('exit_code'))
        expected = {'command': f"Command: {obligation['command']}"}
        if 'cwd' in obligation:
            expected['cwd'] = f"Working directory: {obligation['cwd']}"
        if type(exit_code) is int:
            expected['exit_code'] = f'Exit code: {exit_code}'
        cited_claims(repo, work_id, records, result.get('output'), identifier, reasons, expected, require_locator=True)
        if result.get('snapshot') != digest:
            reasons.append(f'{identifier}: stale snapshot')
        if not isinstance(status, str) or status not in RESULT_STATUSES or type(exit_code) is not int:
            reasons.append(f'{identifier}: result status or exit code is unknown')
        if obligation.get('kind') == 'test':
            counts = tuple((result.get(name) for name in ('executed', 'failed', 'skipped')))
            if any((type(value) is not int or value < 0 for value in counts)):
                reasons.append(f'{identifier}: test counts are missing or invalid')
            elif require_pass and (counts[0] <= 0 or counts[1] != 0 or counts[2] != 0):
                reasons.append(f'{identifier}: test count is zero, failed, skipped, or unknown')
        if require_pass and (status != 'passed' or exit_code != 0):
            reasons.append(f'{identifier}: required command did not pass')
