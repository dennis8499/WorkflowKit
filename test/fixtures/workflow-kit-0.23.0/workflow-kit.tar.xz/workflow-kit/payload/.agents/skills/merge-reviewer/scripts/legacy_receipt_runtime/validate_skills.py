"""Static package check for the Megin Skills-only bundle.

This is a development validator, not a workflow runner. The installed workflow is driven by
the Skills and Markdown records; no Megin command is required at runtime.
"""
from __future__ import annotations
import re
import sys
import argparse
import hashlib
import os
import stat
import tempfile
import zipfile
from collections import Counter
from pathlib import Path
EXPECTED = ('megin', 'megin-requirements-discovery', 'megin-technical-planning', 'megin-bug-diagnosis', 'megin-project-knowledge', 'megin-behavior-contract', 'megin-implementation-execution', 'megin-test-driven-development', 'megin-code-review', 'megin-verification-before-completion', 'megin-human-acceptance', 'megin-finishing-delivery')
