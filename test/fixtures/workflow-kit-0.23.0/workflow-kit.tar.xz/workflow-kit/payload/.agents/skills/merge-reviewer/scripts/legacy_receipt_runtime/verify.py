"""Read-only historical Group v1 receipt validation; no workflow or writer CLI."""
import json, sys
from pathlib import Path
sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
from delivery_receipt import export_receipt
if __name__ == '__main__':
    print(json.dumps(export_receipt(Path(sys.argv[1]), sys.argv[2]), ensure_ascii=False))
