### GitLab Workspace workflow kit

This Git repository uses the native single-repository workflow. First read `.agents/gitlab-workspace-kit/profile.md`, then invoke the corresponding locally installed Skill. Use this repository root for Codex, knowledge, work records and helper `--workspace` arguments. The repository profile defines the scope of these tasks even when an ancestor contains a Group profile.

For `megin-spec-export` or generate-and-export, also read the kit-only reference
`.agents/gitlab-workspace-kit/references/megin-spec-export.md` and export the
checked standalone five-section artifact under this Repo's `exports/megin/`.
BA/SA/SD are not prerequisites. Query follow-ups carry one selected concrete
preview confirmation into the complete bounded update/save workflow.

Megin uses its native repository lock and local delivery contract. Wiki source paths are relative to this repository. Review contexts and drafts belong in system temporary storage; MergeReviewer reports belong under this repository's `review-reports/`, while ReleaseReviewer writes directly at the VSCode workspace root (saved .code-workspace parent when provided). ReleaseReviewer requires exactly an explicit Repo and base/head branches and publishes one concise v3 Release Report with an embedded manual checklist, separating direct P0/P1 blockers, incomplete static evidence and pending environment conditions. Preserve historical reports and edit human records only inside the checklist boundary. MergeReviewer retains optional JSON. Clean the owned context after completion or interruption.

New work uses native Megin Repo v3 and Group v6, with architecture v2 and required cross-Repo impact evidence. Explore current-source functions and neutral requirements, obtain exact-plan approval, then preserve BDD/TDD raw evidence and a fresh independent read-only reviewer for initial round 0 plus at most three correction rounds. Approval can stop retries early; three failed corrections remain incomplete. Resume preserves the original attempt history and fingerprint. Functional exploration is source-first and read-only by default; normal Wiki queries stay Wiki-first.
