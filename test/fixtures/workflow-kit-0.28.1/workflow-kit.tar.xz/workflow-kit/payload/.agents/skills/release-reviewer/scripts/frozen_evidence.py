"""Own complete fixed Git trees; evidence never borrows a source repository."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import os
from pathlib import Path, PurePosixPath
import re

import git_support as git

POLICY = "frozen-start/v1"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def owned_path(context: Path, relative: str) -> Path:
    require(git.safe_relative_git_path(relative) and "\\" not in relative, "快照路徑無效。")
    root = Path(context).resolve()
    path = root / relative
    for parent in (path, *path.parents):
        if parent == root:
            break
        require(not parent.is_symlink() and not getattr(parent, "is_junction", lambda: False)(),
                "快照路徑不能包含連結。")
    require(path.resolve().is_relative_to(root), "快照路徑超出 owned context。")
    return path


def repository(context: Path, record: dict) -> Path:
    snapshot = record.get("snapshot")
    require(isinstance(snapshot, dict) and snapshot.get("policy") == POLICY, "缺少自足固定快照。")
    relative = f"repos/{record['id']}/snapshot.git"
    require(snapshot.get("git_dir") == relative, "快照 Repo 身分不符。")
    path = owned_path(context, relative)
    require(path.is_dir() and owned_path(context, relative + "/HEAD").is_file(), "固定 Git 快照不存在。")
    require(owned_path(context, relative + "/objects").is_dir(), "固定物件目錄不存在。")
    require(not (path / "objects/info/alternates").exists(), "固定快照不能借用其他物件。")
    pack = owned_path(context, relative + "/objects/pack")
    require(pack.is_dir(), "固定 pack 目錄不存在。")
    for item in pack.iterdir():
        owned_path(context, item.relative_to(context).as_posix())
    owned_path(context, relative + "/config")
    return path


def environment(context: Path, record: dict) -> dict:
    path = repository(context, record)
    result = dict(os.environ)
    for key in ("GIT_DIR", "GIT_COMMON_DIR", "GIT_WORK_TREE", "GIT_INDEX_FILE",
                "GIT_OBJECT_DIRECTORY", "GIT_ALTERNATE_OBJECT_DIRECTORIES"):
        result.pop(key, None)
    result.update(GIT_DIR=str(path), GIT_COMMON_DIR=str(path), GIT_OBJECT_DIRECTORY=str(path / "objects"),
                  GIT_ALTERNATE_OBJECT_DIRECTORIES="", GIT_NO_REPLACE_OBJECTS="1", GIT_NO_LAZY_FETCH="1",
                  GIT_OPTIONAL_LOCKS="0", GIT_TERMINAL_PROMPT="0")
    return result


def inventory(repo: Path, tree: str, env=None) -> tuple[list, set]:
    raw = git.run_git(repo, ["ls-tree", "-r", "-t", "-z", tree], binary=True, env=env)
    entries, objects = [], {tree}
    for entry in raw.split(b"\0"):
        if not entry:
            continue
        metadata, path = entry.split(b"\t", 1)
        mode, kind, object_id = metadata.decode("ascii").split()
        name = path.decode("utf-8", errors="surrogateescape")
        entries.append({"path": name, "mode": mode, "kind": kind, "object": object_id})
        if kind != "commit":  # A gitlink does not include the submodule's repository.
            objects.add(object_id)
    return entries, objects


def seal(context: Path, record: dict, refs: list[str], *, env=None):
    source = Path(record["path"])
    relative = f"repos/{record['id']}/snapshot.git"
    destination = owned_path(context, relative)
    object_format = str(git.run_git(source, ["rev-parse", "--show-object-format"])).strip()
    require(object_format in {"sha1", "sha256"}, "不支援的 Git 物件格式。")
    git.run_git(context, ["init", "--bare", f"--object-format={object_format}", str(destination)])
    objects, sources, instructions = set(), {}, []
    for reference in dict.fromkeys(refs):
        require(isinstance(reference, str) and re.fullmatch(r"[a-f0-9]{40}|[a-f0-9]{64}", reference), "固定 ref 無效。")
        tree = str(git.run_git(source, ["rev-parse", f"{reference}^{{tree}}"], env=env)).strip()
        entries, closure = inventory(source, tree, env)
        sources[reference] = {"tree": tree, "entries": entries}
        objects.update(closure)
        objects.add(reference)
        for item in entries:
            if item["kind"] == "blob" and PurePosixPath(item["path"]).name == "AGENTS.md":
                content = git.run_git(source, ["cat-file", "blob", item["object"]], binary=True, env=env)
                instructions.append({"ref": reference, "path": item["path"],
                                     "sha256": hashlib.sha256(content).hexdigest()})
    git.run_git(source, ["pack-objects", str(destination / "objects/pack/snapshot")],
                input_bytes=("\n".join(sorted(objects)) + "\n").encode("ascii"), env=env)
    record["snapshot"] = {"policy": POLICY, "git_dir": relative, "object_format": object_format,
                          "captured_at": datetime.now(timezone.utc).isoformat(), "sources": sources}
    record["instructions"] = instructions
    validate(context, record)


def validate(context: Path, record: dict):
    try:
        return _validate(context, record)
    except git.ReviewContextError as exc:
        raise ValueError(f"固定快照驗證失敗：{exc}") from exc


def _validate(context: Path, record: dict):
    path, env = repository(context, record), environment(context, record)
    sources = record["snapshot"].get("sources")
    require(isinstance(sources, dict) and sources, "快照沒有固定來源。")
    objects, checked_trees = set(), {}
    for reference, expected in sources.items():
        tree = str(git.run_git(path, ["rev-parse", f"{reference}^{{tree}}"], env=env)).strip()
        require(tree == expected["tree"], "快照 tree 身分不符。")
        if tree not in checked_trees:
            checked_trees[tree] = inventory(path, tree, env)
        entries, closure = checked_trees[tree]
        require(entries == expected["entries"], "快照內容清單不符。")
        objects.update(closure)
        objects.add(reference)
    checked = str(git.run_git(path, ["cat-file", "--batch-check"], env=env,
                              input_bytes=("\n".join(sorted(objects)) + "\n").encode("ascii")))
    require(len(checked.splitlines()) == len(objects) and all(len(row.split()) == 3 for row in checked.splitlines()),
            "快照物件不完整。")
    for index in (path / "objects/pack").glob("*.idx"):
        git.run_git(path, ["verify-pack", str(owned_path(context, index.relative_to(context).as_posix()))], env=env)
    for item in record.get("instructions", []):
        content = git.run_git(path, ["cat-file", "blob", f"{item['ref']}:{item['path']}"], binary=True, env=env)
        require(hashlib.sha256(content).hexdigest() == item["sha256"], "固定審查指示摘要不符。")


def capture_workspace_instructions(context: Path, roots: list[Path], repositories: list[Path]) -> list:
    """Freeze applicable on-disk ancestor instructions within declared roots."""
    files = set()
    for repo in repositories:
        for root in roots:
            if repo.is_relative_to(root):
                current = repo
                while current.is_relative_to(root):
                    candidate = current / "AGENTS.md"
                    if candidate.is_file():
                        files.add(candidate)
                    if current == root:
                        break
                    current = current.parent
    result = []
    for number, source in enumerate(sorted(files), 1):
        require(not source.is_symlink() and not getattr(source, "is_junction", lambda: False)(), "審查指示不能是連結。")
        content = source.read_bytes()
        relative = f"instructions/workspace-{number:03}.md"
        target = owned_path(context, relative)
        target.parent.mkdir(exist_ok=True)
        target.write_bytes(content)
        result.append({"origin": str(source), "file": relative, "sha256": hashlib.sha256(content).hexdigest()})
    return result


def validate_workspace_instructions(context: Path, records: list):
    for item in records:
        require(hashlib.sha256(owned_path(context, item["file"]).read_bytes()).hexdigest() == item["sha256"],
                "工作區審查指示摘要不符。")
