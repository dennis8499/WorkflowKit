"""Shared safe decoding and display redaction for captured source content."""
from __future__ import annotations

from pathlib import PurePosixPath
import base64
import binascii
import re

_BINARY_SUFFIXES = {
    ".dll", ".exe", ".so", ".dylib", ".pdb", ".class", ".jar", ".war", ".ear",
    ".png", ".jpg", ".jpeg", ".gif", ".webp", ".ico", ".bmp", ".pdf", ".zip",
    ".7z", ".gz", ".bz2", ".xz", ".rar", ".woff", ".woff2", ".ttf", ".otf",
    ".mp3", ".mp4", ".mov", ".avi", ".sqlite", ".db", ".bin", ".dat",
}
_MAGIC = (b"MZ", b"\x7fELF", b"\x89PNG\r\n\x1a\n", b"PK\x03\x04", b"\xff\xd8\xff")
_SENSITIVE = re.compile(
    r"(?i)([\"']?\b(?:password|passwd|pwd|token|api[_-]?key|secret|access[_-]?key|"
    r"private[_-]?key|client[_-]?secret|credential|authorization|connection[_-]?string)\b[\"']?"
    r"\s*[=:]\s*)(\"(?:\\.|[^\"\\])*\"|'(?:\\.|[^'\\])*'|[^;,\s&)\]}]+)"
)
_SENSITIVE_LINE = re.compile(r"(?i)\b(?:data\s*source|initial\s*catalog|server|host)\s*=")
_LITERAL = re.compile(r'''"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*' ''', re.VERBOSE)
_SOURCE_SUFFIXES = {".cs", ".py", ".ts", ".tsx", ".js", ".jsx", ".java", ".go", ".rs", ".kt", ".vb", ".cpp", ".c", ".h"}
_CONFIG_LOOKUP = re.compile(
    r'''(?:[A-Za-z_]\w*\.)*GetConnectionString\(\s*(?:"[A-Za-z0-9_.:-]+"|'[A-Za-z0-9_.:-]+'|[A-Za-z_]\w*(?:\.[A-Za-z_]\w*)*)\s*$'''
)
_URL_CREDENTIALS = re.compile(r"(?i)([a-z][a-z0-9+.-]*://)[^/\s:@]+:[^/\s@]+@")
_BEARER = re.compile(r"(?i)(\bBearer\s+)[A-Za-z0-9._~+/-]+=*")
_BASIC = re.compile(r"(?i)(\bBasic\s+)([A-Za-z0-9_+/-]+={0,2})")
_CREDENTIAL_CONTEXT = re.compile(r"(?i)password|passwd|pwd|secret|credential|authorization|authenticationheadervalue|"
                                 r"api[_-]?key|access[_-]?key|private[_-]?key|\b\w*token\s*\(")
_HTTP_CONTEXT = re.compile(r"(?i)authenticationheadervalue|\bauthorization\b|\bheaders?\s*\.")
_PRIVATE_KEY = re.compile(r"(?i)-----BEGIN [^-]*PRIVATE KEY-----")
_PRIVATE_END = re.compile(r"(?i)-----END [^-]*PRIVATE KEY-----")


def redact_auth_lines(lines):
    """Keep header schemes and call structure while hiding credential literals."""
    output, depth, http, literal_index = [], 0, False, 0

    def basic(match):
        token = match.group(2)
        if re.search(r"(?i)\bauthorization\b", line):
            return match.group(1) + "[已遮蔽]"
        try:
            decoded = base64.b64decode(token + "=" * (-len(token) % 4), altchars=b"-_", validate=True)
        except (ValueError, binascii.Error):
            return match.group(0)
        # Ordinary prose such as 'Basic arithmetic' is not an encoded credential.
        return match.group(1) + "[已遮蔽]" if b":" in decoded else match.group(0)

    for line in lines:
        value = _BASIC.sub(basic, _BEARER.sub(r"\1[已遮蔽]", line))
        structural = _LITERAL.sub("", value)
        context = bool(_CREDENTIAL_CONTEXT.search(structural))
        if not depth:
            literal_index = 0
            http = bool(_HTTP_CONTEXT.search(structural))
        if depth or context:
            def literal(match):
                nonlocal literal_index
                raw = match.group(0)
                body, quote = raw[1:-1], raw[0]
                first = literal_index == 0
                literal_index += 1
                if http and first and body.lower() in ("basic", "bearer", "authorization"):
                    return raw
                prefix = re.match(r"(?i)^(Basic|Bearer)\s+", body) if http else None
                masked = prefix.group(0) + "[已遮蔽]" if prefix else "[已遮蔽]"
                return quote + masked + quote
            value = _LITERAL.sub(literal, value)
            if not line.lstrip().startswith(("#", "//", "/*", "*")):
                depth = max(0, depth + structural.count("(") - structural.count(")"))
        output.append(value)
    return output, output != list(lines)


def decode_source(raw: bytes, path: str = "") -> tuple[list[str] | None, str | None, bool]:
    """Return byte-line-aligned text, encoding label, and whether decoding lost data.

    UTF-8 and BOM-marked UTF-16 are preferred. Taiwan legacy text is tried as
    CP950. Unknown byte sequences get a visibly lossy UTF-8 replacement view;
    binary blobs are returned without fabricated text lines.
    """
    suffix = PurePosixPath(path.replace("\\", "/")).suffix.lower()
    if suffix in _BINARY_SUFFIXES or any(raw.startswith(magic) for magic in _MAGIC):
        return None, None, False
    if raw.startswith((b"\xff\xfe", b"\xfe\xff")):
        encoding = "utf-16"
    else:
        encoding = None
        for candidate in ("utf-8", "cp950"):
            try:
                raw.decode(candidate, errors="strict")
            except UnicodeDecodeError:
                continue
            encoding = candidate
            break
    if encoding is None:
        return [line.decode("utf-8", errors="replace") for line in raw.splitlines()], "unknown", True
    if b"\0" in raw and encoding != "utf-16":
        return None, None, False
    try:
        decoded = raw.decode(encoding, errors="strict")
    except UnicodeDecodeError:
        return [line.decode("utf-8", errors="replace") for line in raw.splitlines()], "unknown", True
    # Preserve Git's byte-based line numbering; Unicode separators inside text
    # must not invent evidence lines.
    byte_lines = raw.splitlines()
    if not raw:
        byte_lines = []
    if encoding == "utf-16":
        # Split only on physical CR/LF delimiters. str.splitlines() also treats
        # Unicode separators as lines, which would break Git byte line numbers.
        lines = re.split(r"\r\n|\r|\n", decoded)
        if lines and not lines[-1] and decoded.endswith(("\r", "\n")):
            lines.pop()
        if lines:
            lines[0] = lines[0].removeprefix("\ufeff")
    else:
        lines = [line.decode(encoding, errors="strict") for line in byte_lines]
        if encoding == "utf-8" and lines:
            lines[0] = lines[0].removeprefix("\ufeff")
    sample = raw[:8192]
    if encoding != "utf-16" and sample:
        controls = sum(byte < 9 or 13 < byte < 32 for byte in sample)
        if controls / len(sample) > 0.05:
            return None, None, False
    return lines, encoding, False


def has_trailing_newline(raw: bytes, encoding: str) -> bool:
    """Tell display callers whether the decoded source ended with a line break."""
    errors = "replace" if encoding == "unknown" else "strict"
    return raw.decode(encoding, errors=errors).endswith(("\n", "\r"))


def redact_lines(lines: list[str], path: str = "") -> tuple[list[str], bool]:
    """Mask common secret values while preserving one output row per source row."""
    suffix = PurePosixPath(path.replace("\\", "/")).suffix.lower()
    if suffix in {".pem", ".key", ".pfx", ".p12"}:
        return (["[私鑰內容已省略]" for _ in lines], bool(lines))
    auth_visible, changed = redact_auth_lines(lines)
    result, in_private_key = [], False
    for line in auth_visible:
        if in_private_key or _PRIVATE_KEY.search(line):
            in_private_key = True
            result.append("[私鑰內容已省略]")
            changed = True
            if _PRIVATE_END.search(line):
                in_private_key = False
            continue
        literals = list(_LITERAL.finditer(line))

        def in_literal(position):
            return any(item.start() <= position < item.end() for item in literals)

        connection = _SENSITIVE_LINE.search(line)
        if connection and (suffix not in _SOURCE_SUFFIXES or in_literal(connection.start())):
            result.append("[含認證或連線設定的行已省略]")
            changed = True
            continue
        # Mask the token before assignment matching can consume the word Bearer.
        value = _BEARER.sub(r"\1[已遮蔽]", line)
        literals = list(_LITERAL.finditer(value))

        def assignment(match):
            supplied = match.group(2)
            # This argument names configuration; it is not the returned value.
            # Closing ')' lies outside the assignment match's bare-value token.
            if suffix in _SOURCE_SUFFIXES and not in_literal(match.start()) and _CONFIG_LOOKUP.fullmatch(supplied):
                return match.group(0)
            if (suffix in _SOURCE_SUFFIXES and not in_literal(match.start())
                    and re.fullmatch(r"[A-Za-z_][A-Za-z_0-9.]*", supplied)):
                return match.group(0)
            if supplied == "{":  # A configuration section has no credential value.
                return match.group(0)
            return match.group(1) + "[已遮蔽]"

        value = _SENSITIVE.sub(assignment, value)
        value = _URL_CREDENTIALS.sub(r"\1[已遮蔽]@", value)
        result.append(value)
        changed |= value != line
    return result, changed
