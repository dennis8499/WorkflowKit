### GitLab Workspace workflow kit

For development, Wiki, Merge Request review and release checks in this Group, first read
`.agents/gitlab-workspace-kit/profile.md`, then invoke the corresponding installed
Skill. Use this Group root and shared `wiki/`; cite sources as `Repo/path`.

For human-readable output, use the installed `$output-style` at
`.agents/skills/output-style/SKILL.md` before the selected workflow's fallback.
Preserve required artifact structure, evidence and completion gates. If absent,
keep the selected Skill's original output style.

Choose the development workflow requested by the user. When BMAD is selected, start
with `$bmad-help`, then invoke the chosen Skill; `$bmad-build` is the implementation
entry point. The bundled runtime and 29 Codex Skills live at this Group root, so a
Group has one shared installation. For work in a child Repo, pass its explicit path
to the BMAD workflow. BMAD uses `wiki/` as project knowledge and `_bmad-output/` for
planning and implementation artifacts. Preserve user configuration, memory, render
snapshots and generated output. If status reports `bmadMode: external`, use the
pre-existing BMAD and do not claim the kit's `bmad-workflow` capability. Ensure the
user-provided `uv` runtime is available before running bundled BMAD workflows.

Run every local helper command from an installed Skill through the shared
`.agents/gitlab-workspace-kit/run.py` at the selected installation root, keeping
the original command, working directory and arguments. From a child Repo use the
Group root's absolute runner path. Bundled BMAD instructions include this wrapper;
also use it for Wiki, Reviewer, Python and Node.js helpers. Preserve each
Reviewer's existing `--runtime-root`; for a single Repo, it must name an
authorized writable path outside all Git Repos. If a helper requires an explicit
system temporary directory such as `--context-dir`, place it under the runner's
`<group-root>/.gitlab-workspace/runtime/tmp` directory.

Use `$codebase-wiki` for Wiki maintenance, queries, functional exploration,
static code audit, ADR, Synthesis, BA/SA/SD, NotebookLM export and archaeology.
Normal queries are Wiki-first; source-first branches follow the Skill's router.
A selected concrete Query follow-up carries its one confirmation through the
bounded update/save and checks. Full Ingest uses the scanner inventory and
per-file coverage ledger; omissions, blocked files or drift remain incomplete.
Preserve user-authored Wiki content, synchronize `wiki/index.md` and append
`wiki/log.md` for durable updates. Raw sources remain read-only during Wiki work.

Use `$merge-reviewer` or `$release-reviewer` with exactly one Repo and explicit
base/head branches. For a new or resumed review first use the installed
`$model-routing` Skill with `effort=auto` (or this request's explicit low, medium,
high, xhigh or max). It binds one native capture, selects GPT-6 Luna from frozen
changes and dispatches the selected effort. An already-routed reviewer continuation
uses the saved request, draft and checkpoint directly; it never routes recursively.
Auto may checkpoint and strictly raise effort; manual effort stays fixed. In the
workbench the host controls model/effort per turn; direct Skills use one reviewer
child at a time. Preserve missing evidence and stop if the exact model/effort is
unavailable. Routing records do not establish semantic coverage.
 Load that installed Skill's rules, then use its own
`scripts/review_session.py`: `start`, necessary ordered `step` batches, `check`,
then `finish`. Save request ID, runtime, draft and artifact paths. After context
compression use `status` and its remaining work to resume the same frozen review;
use `cancel` with the same ID to abandon it. The two tools keep independent
runtime markers, job schemas, drafts and caches; route by the selected tool.

The first helper freezes base/head and fresh local peer HEADs within the declared
VSCode workspace, including its saved `.code-workspace`. Local branches, peer
HEADs, preview and copying require zero network calls; frozen review stays offline.
MergeReviewer may share in-flight synchronization or complete results younger than
300 seconds; ReleaseReviewer fetches explicit remote inputs independently. Stop
on failure without stale-ref fallback. New versions require `start --refresh`.
Group roots default to `.review-runtime/` for Merge and `.release-review-runtime/`
for Release. Single-Repo roots require an external `--runtime-root`; the workbench
uses `gitlabWorkspace.reviewRuntimePath` and a separate `release-reviewer/` child
for Release. Keep runtime outside every Git Repo.

The Skill agent applies Codex Code Review criteria to the Code Diff and follows
fixed evidence to necessary contracts and direct/indirect consumers. Merge keeps
`merge-reviewer-workspace-result/v3`, P0-P3 findings and pending confirmations.
Release keeps `ReleaseReviewDraft/v3`, direct P0/P1 blockers, evidence gaps and new
deployment dependencies; compare resource use with the entry Repo's fixed base.
Use each Skill's own evidence and result contract; helper success does not complete
semantic review. `check` gathers authoring gaps without Git; exit 3 repairs the same
frozen draft and exit 2 stops. `finish` validates evidence and saves publication
before cleanup, then safely returns that existing report when retried.

Write one Markdown report under the selected Repo's `review-reports/`, titled
`合併審查: {Repo}` for Merge or `上版檢查: {Repo}` for Release. Keep incomplete
coverage visible. Release includes an editable manual Checklist while fixed
report content stays intact. Existing reports and manual checklist entries survive
Skills updates and rollback. MR handoff supplies editable branch candidates;
posting a report remains a separate user-authorized action.

Both reviewer reports use exactly these five H2 headings, in order: `審查結論`,
`問題總攬`, `問題詳情（工程師參考）`, `範圍與限制`, `技術審查紀錄（工程師參考）`.
Problem details show name, impact, operation scenario and suggested action, then trigger,
technical explanation, impact scope, engineering fix and fixed evidence. New drafts use
Merge `report_layout=engineering-review/v1` or Release `report_layout=engineering-review/v2`
and complete that Skill's engineering fields, including Release expected/actual.
Comparison and coverage records belong in the technical section; Release dependencies
and the editable Checklist belong in scope and limitations.

Use `$commit-reviewer` for staged Commit drafts or MR readiness checks on one explicit Repo. Follow its native `inspect`, analysis, `verify`/`report` workflow and preserve snapshot IDs, full SHAs and real developer confirmations. Commit mode reads staged changes only and stays offline. MR mode fetches only the selected remote target; ambiguous remotes need an explicit choice. Run it with the shared helper runner and a fresh `<workspace>/.commit-reviewer-runtime/<unique>` evidence directory. Exit 3 from report means a saved report still has failures, gaps or pending confirmation. Use the current Codex model settings. Present the draft for the developer to copy; Stage, Commit, Rebase, Push and MR creation remain developer actions.
