"""WorkflowKit installed-only syntax bridge; native evidence rules still apply."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import subprocess
import sys

BUNDLE_SHA256 = '693acd4b68c4564aedade62436ecf96eb4792b946927e6d00bf50f3b0489e0c6'

def rewrite(tool, context, manifest, requests):
    root = Path(__file__).resolve().parents[3] / "gitlab-workspace-kit/scripts/syntax-context"
    for item in (root, *root.parents):
        info = item.lstat()
        if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
            raise ValueError("Unsafe WorkflowKit syntax path")
    raw = (root / "bundle.json").read_bytes()
    if hashlib.sha256(raw).hexdigest() != BUNDLE_SHA256:
        raise ValueError("WorkflowKit syntax bundle changed; verify installation")
    bundle = json.loads(raw)
    expected_files = set(bundle["files"]) | {"bundle.json"}
    for candidate in root.rglob("*"):
        info = candidate.lstat()
        if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
            raise ValueError("Unsafe syntax asset")
        if candidate.is_file() and candidate.relative_to(root).as_posix() not in expected_files:
            raise ValueError("Unexpected syntax asset; verify installation")
    for name, digest in bundle["files"].items():
        relative = Path(name)
        if relative.is_absolute() or ".." in relative.parts or "\\" in name or ":" in name:
            raise ValueError("Unsafe syntax asset")
        asset = root / relative
        for item in (asset, *asset.parents):
            info = item.lstat()
            if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
                raise ValueError("Unsafe syntax asset")
        if hashlib.sha256(asset.read_bytes()).hexdigest() != digest:
            raise ValueError("WorkflowKit syntax asset changed; verify installation")
    selected = os.environ.get("WORKFLOW_KIT_SYNTAX_CONTEXT", json.loads((root / "acceptance.json").read_text(encoding="utf-8"))["default_mode"])
    if selected not in ("auto", "off"):
        raise ValueError("WORKFLOW_KIT_SYNTAX_CONTEXT must be auto or off")
    if selected == "off":
        return requests
    spec = importlib.util.spec_from_file_location("_workflow_kit_syntax_core", root / "engine.py")
    core = importlib.util.module_from_spec(spec)
    exec(compile((root / "engine.py").read_bytes(), str(root / "engine.py"), "exec"), core.__dict__)
    if not core.supported():
        sys.stderr.write("WorkflowKit syntax: unsupported runtime; retaining original reads.\n")
        return requests
    if not any(row.get("op", row.get("action")) == "read" and "line_start" not in row
               and Path(row.get("path", "")).suffix.lower() in core.EXTENSIONS for row in requests):
        return requests
    repo_ids = {row["repo"] for row in requests if isinstance(row.get("repo"), str)}
    projected = {**manifest, "repositories": [row for row in manifest["repositories"] if row["id"] in repo_ids]}
    data = json.dumps({"context": str(context), "manifest": projected, "requests": requests}, ensure_ascii=False).encode("utf-8")
    if len(data) > core.MAX_PLAN_INPUT_BYTES:
        sys.stderr.write("WorkflowKit syntax: catalog budget; retaining original reads.\n")
        return requests
    try:
        process = subprocess.run([sys.executable, "-I", "-B", str(root / "cli.py"), "plan",
                                  "--review-tool", tool, "--native-scripts", str(Path(__file__).parent),
                                  "--expected-engine-sha256", BUNDLE_SHA256],
                                 input=data, capture_output=True, timeout=30)
    except subprocess.TimeoutExpired:
        sys.stderr.write("WorkflowKit syntax: planner deadline; retaining original reads.\n")
        return requests
    if process.returncode == 2:
        raise ValueError(process.stderr.decode("utf-8", errors="replace"))
    if process.returncode != 0:
        sys.stderr.write("WorkflowKit syntax: planner unavailable; retaining original reads.\n")
        return requests
    plan = json.loads(process.stdout)
    if plan.get("engine_sha256") != BUNDLE_SHA256 or plan.get("schema") != "SyntaxReadPlan/v1":
        raise ValueError("Invalid syntax read plan identity")
    states = {}
    for item in plan["files"]:
        states[item["status"]] = states.get(item["status"], 0) + 1
    sys.stderr.write("WorkflowKit syntax: " + json.dumps({"changed_reads": plan["changed_reads"], "states": states}) + "\n")
    # Store only syntax metadata in the runner-owned sibling, never the source tree.
    runtime = os.environ.get("WORKFLOW_KIT_SYNTAX_RUNTIME")
    if runtime:
        directory = Path(os.path.abspath(runtime))
        if any((item / ".git").exists() for item in (directory, *directory.parents)):
            sys.stderr.write("WorkflowKit syntax: metadata cache disabled inside Git.\n")
        else:
            try:
                for item in (directory, *directory.parents):
                    if not item.exists() and not item.is_symlink():
                        continue
                    info = item.lstat()
                    if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
                        raise ValueError("Unsafe syntax runtime")
                directory.mkdir(parents=True, exist_ok=True)
                target = directory / (hashlib.sha256(str(Path(context).resolve()).encode()).hexdigest() + ".json")
                if target.is_symlink():
                    raise ValueError("Unsafe syntax metadata file")
                if not target.exists():
                    with target.open("x", encoding="utf-8") as stream:
                        json.dump(plan, stream, ensure_ascii=False)
            except OSError:
                sys.stderr.write("WorkflowKit syntax: optional metadata cache unavailable.\n")
    return plan["requests"]
